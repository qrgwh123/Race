/*
 * Camera.c
 *
 *  Created on: Mar 28, 2024
 *      Author: guo
 */

#include "zf_common_headfile.h"
#include "Identify.h"
#include "Roundabout.h"

#define IMAGE_BLACK 0x00
#define IMAGE_WHITE 0xFF
#define STARTING_POINT_FIND_PRECISION 8

int My_Adapt_Threshold(uint8*image,uint16 width, uint16 height);
void Gain_Magic_Two_Value_Image(void);
void Magic_Two_Value_Image_Init(void);
void Magic_L_R_Line_Init(void);
void Labyrinth_Find_L_R_Magic_Line(uint8 i, uint8 j);
void Magic_Change_Original_Line(void);
void Original_Change_Final_Line(void);
void Show_L_R_Line(void);
void Final_Change_Midcourt_Line(void);
void Draw_Midcourt_Line(void);
void Var_Init(void);
bool Frame_Not_Lost(uint8 i, uint8 j);
uint8 Starting_Point_Find_Pro(uint8 i);

uint8 Enable_Patching(void);
void Equivalent_Corner_Point_Init(void);
void Equivalent_Corner_Point_L_R_Init(void);
void Find_Equivalent_Corner_Point_Left(void);
void Find_Equivalent_Corner_Point_Right(void);
void Least_Square_Method_Gain_Left_K_B(void);
void Least_Square_Method_Gain_Right_K_B(void);
void Fitting_A_Straight_Line_Left_Change_Final_Line(void);
void Fitting_A_Straight_Line_Right_Change_Final_Line(void);
void Search_Corner_Points_Left(void);
void Search_Corner_Points_Right(void);
void Show_Equivalent_Corner_Point(void);
void Drow_Temp_Final_Line(void);
uint8 Prospect_Faraway(void);

uint8 threshould;
uint8 Magic_Two_Value_Image[MT9V03X_H + 2][MT9V03X_W + 2];
uint8 Magic_L_Line[MT9V03X_H + 2], Magic_R_Line[MT9V03X_H + 2];
uint8 Original_L_Line[MT9V03X_H], Final_L_Line[MT9V03X_H];
uint8 Original_R_Line[MT9V03X_H], Final_R_Line[MT9V03X_H];
uint8 L_Break = 0, R_Break = 0;
uint8 L_Lost = 0, R_Lost = 0;
uint8 Midcourt_Line[MT9V03X_H];

uint8 Frame_1 = 0, Frame_2 = 0;

uint8 L_Far_Lost = 0, L_Near_Lost = 0;
uint8 R_Far_Lost = 0, R_Near_Lost = 0;

uint8 Starting_Point_Find_J = 0;

uint8 L_Lost_Point_Number_Min = 255, L_Lost_Point_Number_Max = 0;
uint8 R_Lost_Point_Number_Min = 255, R_Lost_Point_Number_Max = 0;

double Stand_Left_K = -1.6, Stand_Left_B = 20;
double Stand_Right_K = 1.8, Stand_Right_B = -40;

uint8 Equivalent_Corner_Point_Left[10];
uint8 Equivalent_Corner_Point_Right[10];

uint8 Equivalent_Corner_Point_L_R[4];

double Virtual_Midcourt_K = 0, Virtual_Midcourt_B = 0;

void Camera_Init(void)
{
    ips114_init();
    ips114_set_dir(IPS114_PORTAIT);
    while(mt9v03x_init());
    Magic_Two_Value_Image_Init();
}

void Camera_Next_Image(void)
{
    if(mt9v03x_finish_flag == 1)
    {
        threshould = My_Adapt_Threshold(mt9v03x_image[0],MT9V03X_W,MT9V03X_H);
        ips114_show_gray_image(0, 0, mt9v03x_image[0], MT9V03X_W, MT9V03X_H, MT9V03X_W, MT9V03X_H, threshould);

        Gain_Magic_Two_Value_Image();
        Labyrinth_Find_L_R_Magic_Line(MT9V03X_H - 1 + 1,Starting_Point_Find_Pro(MT9V03X_H - 1) + 1);

        Starting_Point_Find_J = Starting_Point_Find_Pro(MT9V03X_H - 1) + 1;

        Magic_Change_Original_Line();
        Original_Change_Final_Line();
        Final_Change_Midcourt_Line();

        Draw_Midcourt_Line();

        //Prospect_Faraway();

        mt9v03x_finish_flag = 0;
    }
}

int My_Adapt_Threshold(uint8*image,uint16 width, uint16 height)   //����㷨��ע�������ֵ��һ��Ҫ��ԭͼ��
{
    #define GrayScale 256
    int pixelCount[GrayScale];
    float pixelPro[GrayScale];
    int i, j;
    int pixelSum = width * height/4;
    int  threshold = 0;
    uint8* data = image;  //ָ���������ݵ�ָ��
    for (i = 0; i < GrayScale; i++)
    {
        pixelCount[i] = 0;
        pixelPro[i] = 0;
    }
    uint32 gray_sum=0;
    for (i = 0; i < height; i+=2)//ͳ�ƻҶȼ���ÿ������������ͼ���еĸ���
    {
        for (j = 0; j <width; j+=2)
        {
            pixelCount[(int)data[i * width + j]]++;  //����ǰ�ĵ������ֵ��Ϊ����������±�
            gray_sum+=(int)data[i * width + j];       //�Ҷ�ֵ�ܺ�
        }
    }
    for (i = 0; i < GrayScale; i++) //����ÿ������ֵ�ĵ�������ͼ���еı���
    {
        pixelPro[i] = (float)pixelCount[i] / pixelSum;
    }
    float w0, w1, u0tmp, u1tmp, u0, u1, u, deltaTmp, deltaMax = 0;
    w0 = w1 = u0tmp = u1tmp = u0 = u1 = u = deltaTmp = 0;
    for (j = 0; j < GrayScale; j++)//�����Ҷȼ�[0,255]
    {
        w0 += pixelPro[j];  //��������ÿ���Ҷ�ֵ�����ص���ռ����֮��   ���������ֵı���
        u0tmp += j * pixelPro[j];  //�������� ÿ���Ҷ�ֵ�ĵ�ı��� *�Ҷ�ֵ
        w1=1-w0;
        u1tmp=gray_sum/pixelSum-u0tmp;
        u0 = u0tmp / w0;              //����ƽ���Ҷ�
        u1 = u1tmp / w1;              //ǰ��ƽ���Ҷ�
        u = u0tmp + u1tmp;            //ȫ��ƽ���Ҷ�
        deltaTmp = w0 * pow((u0 - u), 2) + w1 * pow((u1 - u), 2);//ƽ��
        if (deltaTmp > deltaMax)
        {
            deltaMax = deltaTmp;//�����䷽�
            threshold = j;
        }
        if (deltaTmp < deltaMax)
        {
            break;
        }
    }
    if(threshold>255)
        threshold=255;
    if(threshold<0)
        threshold=0;
  return threshold;
}

void Gain_Magic_Two_Value_Image(void)
{
    for(uint8 i = 1; i < MT9V03X_H + 2 - 1; i++)
    {
        for(uint8 j = 1; j < MT9V03X_W + 2 - 1; j++)
        {
            if(mt9v03x_image[i - 1][j - 1] > threshould)
                Magic_Two_Value_Image[i][j] = IMAGE_WHITE;
            else
                Magic_Two_Value_Image[i][j] = IMAGE_BLACK;
        }
    }
}

void Magic_Two_Value_Image_Init(void)
{
    for(uint8 i = 0; i < MT9V03X_H + 2; i++)
    {
        for(uint8 j = 0; j < MT9V03X_W + 2; j++)
        {
            Magic_Two_Value_Image[i][j] = IMAGE_BLACK;
        }
    }
}
void Labyrinth_Find_L_R_Magic_Line(uint8 i, uint8 j)
{
    if(!Frame_Not_Lost(i,j))
        return;
    Magic_L_R_Line_Init();
    uint8 Direction = 3;
    int Count = 520;
    uint8 I = i;
    uint8 J = j;
    while(Count > 0)
    {
        if(Direction == 0)
        {
            if(Magic_Two_Value_Image[i - 1][j] == IMAGE_BLACK)
            {
                Direction = (Direction + 1) % 4;
            }else if(Magic_Two_Value_Image[i - 1][j - 1] == IMAGE_BLACK)
            {
                Count--;
                i--;
                Magic_L_Line[i] = Magic_L_Line[i] > j ? j : Magic_L_Line[i];
            }else
            {
                Count--;
                i--, j--;
                Magic_L_Line[i] = Magic_L_Line[i] > j ? j : Magic_L_Line[i];
                Direction = Direction == 0 ? 3 : (Direction - 1) % 4;
            }
        }else if(Direction == 1)
        {
            if(Magic_Two_Value_Image[i][j + 1] == IMAGE_BLACK)
            {
                Direction = (Direction + 1) % 4;
            }else if(Magic_Two_Value_Image[i - 1][j + 1] == IMAGE_BLACK)
            {
                Count--;
                j++;
                Magic_L_Line[i] = Magic_L_Line[i] > j ? j : Magic_L_Line[i];
            }else
            {
                Count--;
                i--, j++;
                Magic_L_Line[i] = Magic_L_Line[i] > j ? j : Magic_L_Line[i];
                Direction = Direction == 0 ? 3 : (Direction - 1) % 4;
            }
        }else if(Direction == 2)
        {
            if(Magic_Two_Value_Image[i + 1][j] == IMAGE_BLACK)
            {
                Direction = (Direction + 1) % 4;
            }else if(Magic_Two_Value_Image[i + 1][j + 1] == IMAGE_BLACK)
            {
                Count--;
                i++;
                Magic_L_Line[i] = Magic_L_Line[i] > j ? j : Magic_L_Line[i];
            }else
            {
                Count--;
                i++, j++;
                Magic_L_Line[i] = Magic_L_Line[i] > j ? j : Magic_L_Line[i];
                Direction = Direction == 0 ? 3 : (Direction - 1) % 4;
            }
        }else if(Direction == 3)
        {
            if(Magic_Two_Value_Image[i][j - 1] == IMAGE_BLACK)
            {
                Direction = (Direction + 1) % 4;
            }else if(Magic_Two_Value_Image[i + 1][j - 1] == IMAGE_BLACK)
            {
                Count--;
                j--;
                Magic_L_Line[i] = Magic_L_Line[i] > j ? j : Magic_L_Line[i];
            }else
            {
                Count--;
                i++, j--;
                Magic_L_Line[i] = Magic_L_Line[i] > j ? j : Magic_L_Line[i];
                Direction = Direction == 0 ? 3 : (Direction - 1) % 4;
            }
        }
    }
    Direction = 3;
    Count = 520;
    i = I;
    j = J;
    while(Count > 0)
    {
        if(Direction == 0)
        {
            if(Magic_Two_Value_Image[i - 1][j] == IMAGE_BLACK)
            {
                Direction = (Direction + 1) % 4;
            }else if(Magic_Two_Value_Image[i - 1][j + 1] == IMAGE_BLACK)
            {
                Count--;
                i--;
                Magic_R_Line[i] = Magic_R_Line[i] < j ? j : Magic_R_Line[i];
            }else
            {
                Count--;
                i--, j++;
                Magic_R_Line[i] = Magic_R_Line[i] < j ? j : Magic_R_Line[i];
                Direction = Direction == 0 ? 3 : (Direction - 1) % 4;
            }
        }else if(Direction == 1)
        {
            if(Magic_Two_Value_Image[i][j - 1] == IMAGE_BLACK)
            {
                Direction = (Direction + 1) % 4;
            }else if(Magic_Two_Value_Image[i - 1][j - 1] == IMAGE_BLACK)
            {
                Count--;
                j--;
                Magic_R_Line[i] = Magic_R_Line[i] < j ? j : Magic_R_Line[i];
            }else
            {
                Count--;
                i--, j--;
                Magic_R_Line[i] = Magic_R_Line[i] < j ? j : Magic_R_Line[i];
                Direction = Direction == 0 ? 3 : (Direction - 1) % 4;
            }
        }else if(Direction == 2)
        {
            if(Magic_Two_Value_Image[i + 1][j] == IMAGE_BLACK)
            {
                Direction = (Direction + 1) % 4;
            }else if(Magic_Two_Value_Image[i + 1][j - 1] == IMAGE_BLACK)
            {
                Count--;
                i++;
                Magic_R_Line[i] = Magic_R_Line[i] < j ? j : Magic_R_Line[i];
            }else
            {
                Count--;
                i++, j--;
                Magic_R_Line[i] = Magic_R_Line[i] < j ? j : Magic_R_Line[i];
                Direction = Direction == 0 ? 3 : (Direction - 1) % 4;
            }
        }else if(Direction == 3)
        {
            if(Magic_Two_Value_Image[i][j + 1] == IMAGE_BLACK)
            {
                Direction = (Direction + 1) % 4;
            }else if(Magic_Two_Value_Image[i + 1][j + 1] == IMAGE_BLACK)
            {
                Count--;
                j++;
                Magic_R_Line[i] = Magic_R_Line[i] < j ? j : Magic_R_Line[i];
            }else
            {
                Count--;
                i++, j++;
                Magic_R_Line[i] = Magic_R_Line[i] < j ? j : Magic_R_Line[i];
                Direction = Direction == 0 ? 3 : (Direction - 1) % 4;
            }
        }
    }
}

void Show_L_R_Line(void)
{
    for(uint8 i = 0; i < MT9V03X_H; i++)
    {
        if(Original_L_Line[i] != 255)
        {
            ips114_draw_point(Original_L_Line[i], i, RGB565_GREEN);
            ips114_draw_point(Original_L_Line[i] + 1, i, RGB565_GREEN);
        }
        if(Original_R_Line[i] != 0)
        {
            ips114_draw_point(Original_R_Line[i], i, RGB565_RED);
            ips114_draw_point(Original_R_Line[i] - 1, i, RGB565_RED);
        }
    }
}

void Draw_Midcourt_Line(void)
{
    for(uint8 i = 1; i < MT9V03X_H - 1; i++)
    {
        if(Midcourt_Line[i] == 0)
        {
            continue;
        }
        ips114_draw_point(Midcourt_Line[i], i, RGB565_BLUE);
        ips114_draw_point(Midcourt_Line[i] + 1, i, RGB565_BLUE);
    }
}

void Magic_L_R_Line_Init(void)
{
    for(uint8 i = 0; i < MT9V03X_H + 2; i++)
    {
        Magic_L_Line[i] = 255;
        Magic_R_Line[i] = 0;
    }
}

void Magic_Change_Original_Line(void)
{
    for(uint8 i = 1; i < MT9V03X_H + 2 - 1; i++)
    {
        if(Magic_L_Line[i] == 255)
        {
            Original_L_Line[i - 1] = Magic_L_Line[i];
        }else
        {
            Original_L_Line[i - 1] = Magic_L_Line[i] - 1;
        }
        if(Magic_R_Line[i] == 0)
        {
            Original_R_Line[i - 1] = Magic_R_Line[i];
        }else
        {
            Original_R_Line[i - 1] = Magic_R_Line[i] - 1;
        }
    }
}

void Original_Change_Final_Line(void)
{
    Var_Init();
    for(uint8 i = 0; i < MT9V03X_H; i++)
    {
        if(Original_L_Line[i] == 0)
        {
            if(L_Lost_Point_Number_Min == 255)
            {
                L_Lost_Point_Number_Min = i;
            }else
            {
                L_Lost_Point_Number_Max = i;
            }

            if(i >= 0 && i < 40)
            {
                L_Far_Lost++;
            }else if(i >= 80 && i < MT9V03X_H)
            {
                L_Near_Lost++;
            }
            L_Lost++;
        }else
        {
            Final_L_Line[i] = Original_L_Line[i];
        }
    }
    for(uint8 i = 0; i < MT9V03X_H; i++)
    {
        if(Original_R_Line[i] == MT9V03X_W - 1)
        {
            if(R_Lost_Point_Number_Min == 255)
            {
                R_Lost_Point_Number_Min = i;
            }else
            {
                R_Lost_Point_Number_Max = i;
            }

            if(i >= 0 && i < 40)
            {
                R_Far_Lost++;
            }else if(i >= 80 && i < MT9V03X_H)
            {
                R_Near_Lost++;
            }
            R_Lost++;
        }else
        {
            Final_R_Line[i] = Original_R_Line[i];
        }
    }

}

void Final_Change_Midcourt_Line(void)
{
    for(int i = 0; i < MT9V03X_H; i++)
    {
        if(Original_L_Line[i] == 255 && Original_R_Line[i] == 0)
        {
            Midcourt_Line[i] = 0;
        }else
        {
            Midcourt_Line[i] = (Original_L_Line[i] / 2 + Original_R_Line[i] / 2);
        }
    }

    Enable_Patching();
    Show_Equivalent_Corner_Point();

    if(Identify_Track_Selection == 1 && (Identify_Track_Status == 0 || Identify_Track_Status == 1))
    {
        Drow_Temp_Final_Line();
        for(uint8 i = 0; i < MT9V03X_H; i++)
        {
            if(Midcourt_Line[i] != 0)
            {
                if(Original_L_Line[i] == 0 || Original_R_Line[i] == MT9V03X_W - 1)
                {
                    Midcourt_Line[i] = Final_L_Line[i] / 2 + Final_R_Line[i] / 2;

                }
            }
        }
    }

    if(Identify_Track_Selection == 3)
    {
        if(Identify_Track_Status == 0 && (Roundabout_Flag == 0 || Roundabout_Flag == 1))
        {
            Roundabout_Loop_Entry_Adding_Line_Right();
            for(uint8 i = 0; i < MT9V03X_H; i++)
            {
                if(Midcourt_Line[i] != 0)
                {
                    Midcourt_Line[i] = Original_L_Line[i] / 2 + Final_R_Line[i] / 2;
                }
            }
        }else if(Identify_Track_Status == 0 && Roundabout_Flag == 2)
        {
            Roundabout_Loop_Entry_Bracing_Wire_Right();
            for(uint8 i = 0; i < MT9V03X_H; i++)
            {
                if(Midcourt_Line[i] != 0)
                {
                    Midcourt_Line[i] = Final_L_Line[i] / 2 + Original_R_Line[i] / 2;
                }
            }
        }else if(Identify_Track_Status == 1 && (Roundabout_Flag == 3 || Roundabout_Flag == 12))
        {
            Roundabout_Out_Of_The_Virtual_Loop_Bracing_Wire_Right();
            for(uint8 i = 0; i < MT9V03X_H; i++)
            {
                if(Midcourt_Line[i] != 0)
                {
                    Midcourt_Line[i] = Final_L_Line[i] / 2 + Original_R_Line[i] / 2;
                }
            }
        }else if(Identify_Track_Status == 1 && Roundabout_Flag == 6)
        {
            Roundabout_Out_Of_The_Loop_Adding_Line_Right();
            for(uint8 i = 0; i < MT9V03X_H; i++)
            {
                if(Midcourt_Line[i] != 0)
                {
                    Midcourt_Line[i] = Original_L_Line[i] / 2 + Final_R_Line[i] / 2;
                }
            }
        }
    }

    if(Identify_Track_Selection == 5)
    {
        if(Identify_Track_Status == 0 && (Left_Roundabout_Flag == 0 || Left_Roundabout_Flag == 1))
        {
            Roundabout_Loop_Entry_Adding_Line_Left();
            for(uint8 i = 0; i < MT9V03X_H; i++)
            {
                if(Midcourt_Line[i] != 0)
                {
                    Midcourt_Line[i] = Final_L_Line[i] / 2 + Original_R_Line[i] / 2;
                }
            }
        }else if(Identify_Track_Status == 0 && Left_Roundabout_Flag == 2)
        {
            Roundabout_Loop_Entry_Bracing_Wire_Left();
            for(uint8 i = 0; i < MT9V03X_H; i++)
            {
                if(Midcourt_Line[i] != 0)
                {
                    Midcourt_Line[i] = Original_L_Line[i] / 2 + Final_R_Line[i] / 2;
                }
            }
        }else if(Identify_Track_Status == 1 && (Left_Roundabout_Flag == 3 || Left_Roundabout_Flag == 12))
        {
            Roundabout_Out_Of_The_Virtual_Loop_Bracing_Wire_Left();
            for(uint8 i = 0; i < MT9V03X_H; i++)
            {
                if(Midcourt_Line[i] != 0)
                {
                    Midcourt_Line[i] = Original_L_Line[i] / 2 + Final_R_Line[i] / 2;
                }
            }
        }else if(Identify_Track_Status == 1 && Left_Roundabout_Flag == 6)
        {
            Roundabout_Out_Of_The_Loop_Adding_Line_Left();
            for(uint8 i = 0; i < MT9V03X_H; i++)
            {
                if(Midcourt_Line[i] != 0)
                {
                    Midcourt_Line[i] = Final_L_Line[i] / 2 + Original_R_Line[i] / 2;
                }
            }
        }
    }
}

bool Frame_Not_Lost(uint8 i, uint8 j)
{
    if(Magic_Two_Value_Image[i][j] == IMAGE_BLACK)
    {
        Frame_1++;
        return false;
    }
    else if(Magic_Two_Value_Image[i - 1][j] == IMAGE_BLACK && Magic_Two_Value_Image[i + 1][j] == IMAGE_BLACK && Magic_Two_Value_Image[i][j - 1] == IMAGE_BLACK && Magic_Two_Value_Image[i][j + 1] == IMAGE_BLACK)
    {
        Frame_2++;
        return false;
    }
    return true;
}

void Var_Init(void)
{
    L_Break = 0, R_Break = 0;
    L_Lost = 0, R_Lost = 0;
    L_Far_Lost = 0, L_Near_Lost = 0;
    R_Far_Lost = 0, R_Near_Lost = 0;
    L_Lost_Point_Number_Min = 255, L_Lost_Point_Number_Max = 0;
    R_Lost_Point_Number_Min = 255, R_Lost_Point_Number_Max = 0;
}

uint8 Starting_Point_Find_Pro(uint8 i)
{
    uint8 j = MT9V03X_W / 2, jl,jr;
    if(mt9v03x_image[i][j] > threshould)
        return j;
    if(mt9v03x_image[i][0] > threshould)
        return 60;
    if(mt9v03x_image[i][187] > threshould)
        return 130;
    if(mt9v03x_image[i][50] > threshould)
        return 50;
    if(mt9v03x_image[i][130] > threshould)
        return 140;
    jl = j, jr = j;
    while(jl > STARTING_POINT_FIND_PRECISION + 1 && jr < MT9V03X_W - STARTING_POINT_FIND_PRECISION - 1)
    {
        jl -= STARTING_POINT_FIND_PRECISION;
        jr += STARTING_POINT_FIND_PRECISION;
        if(mt9v03x_image[i][jl] > threshould)
            return jl;
        if(mt9v03x_image[i][jr] > threshould)
            return jr;
    }
    return j;
}

void Equivalent_Corner_Point_Init(void)
{
    for(uint8 i = 0; i < 10; i++)
    {
        Equivalent_Corner_Point_Left[i] = 255;
        Equivalent_Corner_Point_Right[i] = 255;
    }
}

void Equivalent_Corner_Point_L_R_Init(void)
{
    for(uint8 i = 0; i < 4; i++)
    {
        Equivalent_Corner_Point_L_R[i] = 0;
    }
}

void Find_Equivalent_Corner_Point_Left(void)
{
    uint8 Count = 0;
    for(uint8 i = MT9V03X_H - 3; i >= 10; i--)
    {
        if(Count >= 10)
        {
            break;
        }
        if(Original_L_Line[i] == 255 || Original_L_Line[i] == 0)
        {
            continue;
        }
        if(Original_L_Line[i] - Original_L_Line[i + 1] >= 0
                && Original_L_Line[i] - Original_L_Line[i + 1] <= 1
                && Original_L_Line[i] - Original_L_Line[i + 2] >= 0
                && Original_L_Line[i] - Original_L_Line[i + 2] <= 2
                && Original_L_Line[i - 1] - Original_L_Line[i] >= 0
                && Original_L_Line[i - 1] - Original_L_Line[i] <= 1
                && Original_L_Line[i - 2] - Original_L_Line[i] >= 0
                && Original_L_Line[i - 2] - Original_L_Line[i] <= 2)
        {
            Equivalent_Corner_Point_Left[Count++] = i;
        }
    }
}

void Find_Equivalent_Corner_Point_Right(void)
{
    uint8 Count = 0;
    for(uint8 i = MT9V03X_H - 3; i >= 10; i--)
    {
        if(Count >= 10)
        {
            break;
        }
        if(Original_R_Line[i] == 0 || Original_R_Line[i] == MT9V03X_W - 1)
        {
            continue;
        }
        if(Original_R_Line[i] - Original_R_Line[i + 1] <= 0
                && Original_R_Line[i] - Original_R_Line[i + 1] >= -1
                && Original_R_Line[i] - Original_R_Line[i + 2] <= 0
                && Original_R_Line[i] - Original_R_Line[i + 2] >= -2
                && Original_R_Line[i - 1] - Original_R_Line[i] <= 0
                && Original_R_Line[i - 1] - Original_R_Line[i] >= -1
                && Original_R_Line[i - 2] - Original_R_Line[i] <= 0
                && Original_R_Line[i - 2] - Original_R_Line[i] >= -2)
        {
            Equivalent_Corner_Point_Right[Count++] = i;
        }
    }
}

void Least_Square_Method_Gain_Left_K_B(void)
{
    double Sum_X = 0, Sum_Y = 0, Sum_X_Y = 0, Sum_X_X = 0;

    double Left_K = Stand_Left_K, Left_B = Stand_Left_B;

    uint8 Count = 10;

    if(Equivalent_Corner_Point_Left[9] == 255)
    {
        return;
    }

    for(uint8 i = 0; i < Count; i++)
    {
        Sum_X += Original_L_Line[Equivalent_Corner_Point_Left[i]];
        Sum_Y += Equivalent_Corner_Point_Left[i];
        Sum_X_X += Original_L_Line[Equivalent_Corner_Point_Left[i]] * Original_L_Line[Equivalent_Corner_Point_Left[i]];
        Sum_X_Y += Original_L_Line[Equivalent_Corner_Point_Left[i]] * Equivalent_Corner_Point_Left[i];
    }

    uint8 N = Count;

    if((N * Sum_X_X - Sum_X * Sum_X) && N)
    {
        Stand_Left_K = (N * Sum_X_Y - Sum_X * Sum_Y) / (N * Sum_X_X - Sum_X * Sum_X);
        Stand_Left_B = (Sum_Y - (Stand_Left_K) * Sum_X) / N;
    }

    if(Stand_Left_K > 0 || Stand_Left_B < 0)
    {
        Stand_Left_K = Left_K;
        Stand_Left_B = Left_B;
    }
}

void Least_Square_Method_Gain_Right_K_B(void)
{
    double Sum_X = 0, Sum_Y = 0, Sum_X_Y = 0, Sum_X_X = 0;

    double Right_K = Stand_Right_K, Right_B = Stand_Right_B;

    uint8 Count = 10;

    if(Equivalent_Corner_Point_Right[9] == 255)
    {
        return;
    }

    for(uint8 i = 0; i < Count; i++)
    {
        Sum_X += Original_R_Line[Equivalent_Corner_Point_Right[i]];
        Sum_Y += Equivalent_Corner_Point_Right[i];
        Sum_X_X += Original_R_Line[Equivalent_Corner_Point_Right[i]] * Original_R_Line[Equivalent_Corner_Point_Right[i]];
        Sum_X_Y += Original_R_Line[Equivalent_Corner_Point_Right[i]] * Equivalent_Corner_Point_Right[i];
    }

    uint8 N = Count;

    if((N * Sum_X_X - Sum_X * Sum_X) && N)
    {
        Stand_Right_K = (N * Sum_X_Y - Sum_X * Sum_Y) / (N * Sum_X_X - Sum_X * Sum_X);
        Stand_Right_B = (Sum_Y - (Stand_Right_K) * Sum_X) / N;
    }

    if(Stand_Right_K < 0 || Stand_Right_B > 0)
    {
        Stand_Right_K = Right_K;
        Stand_Right_B = Right_B;
    }
}

void Fitting_A_Straight_Line_Left_Change_Final_Line(void)
{
    if(Stand_Left_K == 0)
    {
        double Temp = 0;
        for(uint8 i = 0; i < 10; i++)
        {
            Temp += Original_L_Line[Equivalent_Corner_Point_Left[i]];
        }
        Temp /= 10;
        for(uint8 i = 10; i < MT9V03X_H; i++)
        {
            Final_L_Line[i] = Temp;
        }
    }else
    {
        for(uint8 i = 10; i < MT9V03X_H; i++)
        {
            Final_L_Line[i] = (i - Stand_Left_B) / Stand_Left_K;
            if(Final_L_Line[i] < 0)
            {
                Final_L_Line[i] = 0;
            }else if(Final_L_Line[i] > MT9V03X_W - 1)
            {
                Final_L_Line[i] = MT9V03X_W - 1;
            }
        }
    }
}

void Fitting_A_Straight_Line_Right_Change_Final_Line(void)
{
    if(Stand_Right_K == 0)
    {
        double Temp = 0;
        for(uint8 i = 0; i < 10; i++)
        {
            Temp += Original_R_Line[Equivalent_Corner_Point_Right[i]];
        }
        Temp /= 10;
        for(uint8 i = 10; i < MT9V03X_H; i++)
        {
            Final_R_Line[i] = Temp;
        }
    }else
    {
        for(uint8 i = 10; i < MT9V03X_H; i++)
        {
            Final_R_Line[i] = (i - Stand_Right_B) / Stand_Right_K;
            if(Final_R_Line[i] < 0)
            {
                Final_R_Line[i] = 0;
            }else if(Final_R_Line[i] > MT9V03X_W - 1)
            {
                Final_R_Line[i] = MT9V03X_W - 1;
            }
        }
    }
}

void Search_Corner_Points_Left(void)
{
    for(uint8 i = MT9V03X_H - 10; i >= 10; i--)
    {
        if(Original_L_Line[i] == 0 || Original_L_Line[i] == 255)
        {
            continue;
        }
        if(Original_L_Line[i] - Original_L_Line[i + 1] >= 0
                && Original_L_Line[i] - Original_L_Line[i + 2] >= 0
                && Original_L_Line[i] - Original_L_Line[i + 3] >= 0
                && Original_L_Line[i] - Original_L_Line[i + 4] >= 0
                && Original_L_Line[i] - Original_L_Line[i + 1] <= 1
                && Original_L_Line[i] - Original_L_Line[i + 2] <= 2
                && Original_L_Line[i] - Original_L_Line[i + 3] <= 3
                && Original_L_Line[i] - Original_L_Line[i + 4] <= 4
                && Original_L_Line[i] - Original_L_Line[i - 1] >= 1
                && Original_L_Line[i] - Original_L_Line[i - 2] >= 3
                && Original_L_Line[i] - Original_L_Line[i - 3] >= 5
                && Original_L_Line[i] - Original_L_Line[i - 4] >= 7
                && Original_L_Line[i - 10] == 0
                && Original_L_Line[i - 11] == 0
                && Original_L_Line[i - 12] == 0
                && Original_L_Line[i - 13] == 0)
        {
            L_Break++;
            Equivalent_Corner_Point_L_R[0] = i;
            break;
        }
    }
    for(uint8 i = 10; i < MT9V03X_H - 10; i++)
    {
        if(Original_L_Line[i] == 0 || Original_L_Line[i] == 255)
        {
            continue;
        }
        if(Original_L_Line[i] - Original_L_Line[i - 1] <= 0
                && Original_L_Line[i] - Original_L_Line[i - 2] <= 0
                && Original_L_Line[i] - Original_L_Line[i - 3] <= 0
                && Original_L_Line[i] - Original_L_Line[i - 4] <= 0
                && Original_L_Line[i] - Original_L_Line[i - 1] >= -1
                && Original_L_Line[i] - Original_L_Line[i - 2] >= -2
                && Original_L_Line[i] - Original_L_Line[i - 3] >= -3
                && Original_L_Line[i] - Original_L_Line[i - 4] >= -4
                && Original_L_Line[i] - Original_L_Line[i + 1] >= 1
                && Original_L_Line[i] - Original_L_Line[i + 2] >= 3
                && Original_L_Line[i] - Original_L_Line[i + 3] >= 5
                && Original_L_Line[i] - Original_L_Line[i + 4] >= 7
                && Original_L_Line[i + 10] == 0
                && Original_L_Line[i + 11] == 0
                && Original_L_Line[i + 12] == 0
                && Original_L_Line[i + 13] == 0)
        {
            L_Break++;
            Equivalent_Corner_Point_L_R[1] = i;
            break;
        }
    }
}

void Search_Corner_Points_Right(void)
{
    for(uint8 i = MT9V03X_H - 10; i >= 10; i--)
    {
        if(Original_R_Line[i] == MT9V03X_W - 1 || Original_R_Line[i] == 0)
        {
            continue;
        }
        if(Original_R_Line[i] - Original_R_Line[i + 1] <= 0
                && Original_R_Line[i] - Original_R_Line[i + 2] <= 0
                && Original_R_Line[i] - Original_R_Line[i + 3] <= 0
                && Original_R_Line[i] - Original_R_Line[i + 4] <= 0
                && Original_R_Line[i] - Original_R_Line[i + 1] >= -1
                && Original_R_Line[i] - Original_R_Line[i + 2] >= -2
                && Original_R_Line[i] - Original_R_Line[i + 3] >= -3
                && Original_R_Line[i] - Original_R_Line[i + 4] >= -4
                && Original_R_Line[i] - Original_R_Line[i - 1] <= -1
                && Original_R_Line[i] - Original_R_Line[i - 2] <= -3
                && Original_R_Line[i] - Original_R_Line[i - 3] <= -5
                && Original_R_Line[i] - Original_R_Line[i - 4] <= -7
                && Original_R_Line[i - 10] == 187
                && Original_R_Line[i - 11] == 187
                && Original_R_Line[i - 12] == 187
                && Original_R_Line[i - 13] == 187)
        {
            R_Break++;
            Equivalent_Corner_Point_L_R[2] = i;
            break;
        }
    }
    for(uint8 i = 10; i < MT9V03X_H - 10; i++)
    {
        if(Original_R_Line[i] == MT9V03X_W - 1 || Original_R_Line[i] == 0)
        {
            continue;
        }
        if(Original_R_Line[i] - Original_R_Line[i - 1] >= 0
                && Original_R_Line[i] - Original_R_Line[i - 2] >= 0
                && Original_R_Line[i] - Original_R_Line[i - 3] >= 0
                && Original_R_Line[i] - Original_R_Line[i - 4] >= 0
                && Original_R_Line[i] - Original_R_Line[i - 1] <= 1
                && Original_R_Line[i] - Original_R_Line[i - 2] <= 2
                && Original_R_Line[i] - Original_R_Line[i - 3] <= 3
                && Original_R_Line[i] - Original_R_Line[i - 4] <= 4
                && Original_R_Line[i] - Original_R_Line[i + 1] <= -1
                && Original_R_Line[i] - Original_R_Line[i + 2] <= -3
                && Original_R_Line[i] - Original_R_Line[i + 3] <= -5
                && Original_R_Line[i] - Original_R_Line[i + 4] <= -7
                && Original_R_Line[i + 10] == 187
                && Original_R_Line[i + 11] == 187
                && Original_R_Line[i + 12] == 187
                && Original_R_Line[i + 13] == 187)
        {
            R_Break++;
            Equivalent_Corner_Point_L_R[3] = i;
            break;
        }
    }
}

void Show_Equivalent_Corner_Point(void)
{
    for(uint8 i = 10; i < MT9V03X_W - 10; i++)
    {
        if(Equivalent_Corner_Point_L_R[0] != 0)
        {
            ips114_draw_point(i, Equivalent_Corner_Point_L_R[0], RGB565_RED);
        }
        if(Equivalent_Corner_Point_L_R[1] != 0)
        {
            ips114_draw_point(i, Equivalent_Corner_Point_L_R[1], RGB565_RED);
        }
        if(Equivalent_Corner_Point_L_R[2] != 0)
        {
            ips114_draw_point(i, Equivalent_Corner_Point_L_R[2], RGB565_GREEN);
        }
        if(Equivalent_Corner_Point_L_R[3] != 0)
        {
            ips114_draw_point(i, Equivalent_Corner_Point_L_R[3], RGB565_GREEN);
        }
    }
}

void Drow_Temp_Final_Line(void)
{
    for(int i = 10; i < MT9V03X_H; i++)
    {
        if((Final_L_Line[i] + 1) >= 0 && (Final_L_Line[i] + 1) < MT9V03X_W)
        {
            ips114_draw_point(Final_L_Line[i], i, RGB565_RED);
            ips114_draw_point(Final_L_Line[i] + 1, i, RGB565_RED);
        }

        if((Final_R_Line[i] - 1) >= 0 && (Final_R_Line[i] - 1) < MT9V03X_W)
        {
            ips114_draw_point(Final_R_Line[i], i, RGB565_GREEN);
            ips114_draw_point(Final_R_Line[i] - 1, i, RGB565_GREEN);
        }
    }
}

uint8 Enable_Patching(void)
{
    Equivalent_Corner_Point_Init();
    Equivalent_Corner_Point_L_R_Init();
    Find_Equivalent_Corner_Point_Left();
    Find_Equivalent_Corner_Point_Right();
    Least_Square_Method_Gain_Left_K_B();
    Least_Square_Method_Gain_Right_K_B();
    Fitting_A_Straight_Line_Left_Change_Final_Line();
    Fitting_A_Straight_Line_Right_Change_Final_Line();
    Search_Corner_Points_Left();
    Search_Corner_Points_Right();
    return 1;
}

uint8 Prospect_Faraway(void)
{
    uint8 Virtual_Midcourt_Line[120];

    double Sum_X = 0, Sum_Y = 0, Sum_X_Y = 0, Sum_X_X = 0;

    uint8 Count = 20;

    for(uint8 i = 5; i < Count + 5; i++)
    {
        Sum_X += Midcourt_Line[119 - i];
        Sum_Y += 119 - i;
        Sum_X_X += Midcourt_Line[119 - i] * Midcourt_Line[119 - i];
        Sum_X_Y += (119 - i) * Midcourt_Line[119 - i];
    }

    uint8 N = Count;

    if((N * Sum_X_X - Sum_X * Sum_X) && N)
    {
        Virtual_Midcourt_K = (N * Sum_X_Y - Sum_X * Sum_Y) / (N * Sum_X_X - Sum_X * Sum_X);
        Virtual_Midcourt_B = (Sum_Y - (Virtual_Midcourt_K) * Sum_X) / N;
    }

    if(Virtual_Midcourt_K == 0)
    {
        double Temp = 0;
        for(uint8 i = 0; i < 10; i++)
        {
            Temp += Midcourt_Line[119 - i];
        }
        Temp /= 10;
        for(uint8 i = 0; i < MT9V03X_H; i++)
        {
            Virtual_Midcourt_Line[i] = Temp;
        }
    }else
    {
        for(uint8 i = 0; i < MT9V03X_H; i++)
        {
            Virtual_Midcourt_Line[i] = (i - Virtual_Midcourt_B) / Virtual_Midcourt_K;
            if(Virtual_Midcourt_Line[i] < 0)
            {
                Virtual_Midcourt_Line[i] = 0;
            }else if(Virtual_Midcourt_Line[i] > MT9V03X_W - 1)
            {
                Virtual_Midcourt_Line[i] = MT9V03X_W - 1;
            }
        }
    }

    for(int i = 0; i < MT9V03X_H; i++)
    {
        if((Virtual_Midcourt_Line[i] + 1) >= 0 && (Virtual_Midcourt_Line[i] + 1) < MT9V03X_W)
        {
            ips114_draw_point(Virtual_Midcourt_Line[i], i, RGB565_RED);
            ips114_draw_point(Virtual_Midcourt_Line[i] + 1, i, RGB565_RED);
        }
    }
    return 1;
}

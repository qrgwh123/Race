/*
 * Speed.c
 *
 *  Created on: Apr 1, 2024
 *      Author: guo
 */

#include "zf_common_headfile.h"

int Speed = 0;

void Speed_Init(void)
{
    encoder_dir_init(TIM9_ENCOEDER,TIM9_ENCOEDER_MAP3_CH1_D9,TIM9_ENCOEDER_MAP3_CH2_D11);
}

void Speed_Control(void)
{
    static int16 Speed_Count = 0, Speed_Temp = 0;
    Speed_Count++;
    Speed_Temp -= encoder_get_count(TIM9_ENCOEDER);
    encoder_clear_count(TIM9_ENCOEDER);
    if(Speed_Count < 2)
        return;
    Speed = Speed_Temp / 2;
    Speed_Count = 0;
    Speed_Temp = 0;
}

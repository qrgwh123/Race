/*
 * Camera.h
 *
 *  Created on: Mar 28, 2024
 *      Author: guo
 */

#ifndef CAMERA_H_
#define CAMERA_H_

extern uint8 L_Break;
extern uint8 R_Break;
extern uint8 L_Lost;
extern uint8 R_Lost;
extern uint8 Original_L_Line[MT9V03X_H];
extern uint8 Original_R_Line[MT9V03X_H];

extern uint8 Magic_L_Line[MT9V03X_H + 2];
extern uint8 Magic_R_Line[MT9V03X_H + 2];

extern uint8 Midcourt_Line[MT9V03X_H];

extern uint8 Frame_1;
extern uint8 Frame_2;

extern uint8 L_Far_Lost, L_Near_Lost;
extern uint8 R_Far_Lost, R_Near_Lost;

extern uint8 Starting_Point_Find_J;

extern uint8 L_Lost_Point_Number_Min, L_Lost_Point_Number_Max;
extern uint8 R_Lost_Point_Number_Min, R_Lost_Point_Number_Max;

extern double Stand_Left_K, Stand_Left_B;
extern double Stand_Right_K, Stand_Right_B;

extern uint8 Equivalent_Corner_Point_Left[10];
extern uint8 Equivalent_Corner_Point_Right[10];

extern uint8 Equivalent_Corner_Point_L_R[4];

extern uint8 Final_L_Line[MT9V03X_H], Final_R_Line[MT9V03X_H];

extern uint8 threshould;

extern double Virtual_Midcourt_K, Virtual_Midcourt_B;

void Camera_Init(void);
void Camera_Next_Image(void);

#endif /* CAMERA_H_ */

/*
 * Acc_Gyro.h
 *
 *  Created on: Apr 8, 2024
 *      Author: guo
 */

#ifndef ACC_GYRO_H_
#define ACC_GYRO_H_

extern float Gyro_Z;

void Acc_Gyro_Init(void);
void Acc_Gyro_Gain(void);

#endif /* ACC_GYRO_H_ */

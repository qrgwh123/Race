/*
 * Key.h
 *
 *  Created on: Apr 8, 2024
 *      Author: guo
 */

#ifndef KEY_H_
#define KEY_H_

extern uint8 Key_Number;

#define KEY_UP C5
#define KEY_LEFT A0
#define KEY_RIGHT A2
#define KEY_DOWM A1
#define KEY_MIDDLE A3

#define KEY_NUMBER_UP 1
#define KEY_NUMBER_LEFT 2
#define KEY_NUMBER_RIGHT 3
#define KEY_NUMBER_DOWM 4
#define KEY_NUMBER_MIDDLE 5

void Key_Init(void);
void Key_Test_Duty_Control(void);

#endif /* KEY_H_ */

/*
 * Identify.c
 *
 *  Created on: Mar 30, 2024
 *      Author: guo
 */

#include "zf_common_headfile.h"
#include "Camera.h"
#include "Identify.h"
#include "PID.h"
#include "Roundabout.h"
#include "Speed.h"

void Gain_Direction_Power_Control(void);
void Identify_Var_Init(void);
void Gain_Selection_And_Status(void);
uint8 Roundabout_Find_Right_Corner(void);
uint8 Left_Roundabout_Find_Left_Corner(void);
uint8 Enter_Left_Roundabout_Prevent_Misjudgment(void);
uint8 Enter_Right_Roundabout_Prevent_Misjudgment(void);
uint8 Roundabout_First_Find_Corner(void);
uint8 Roundabout_First_Find_Corner_Left(void);
uint8 Find_Roundabout_Right_Corner_Pro(void);
uint8 Enter_The_Ring_Pull_The_Line_Leave_Right(void);
uint8 Enter_The_Ring_Pull_The_Line_Leave_Left(void);
uint8 Whether_Zebra_Crossing(void);
uint8 Cross_Recognition_Optimization_Success(void);
uint8 R_Break_Two_CROS(void);
uint8 L_Break_Two_CROS(void);
uint8 Upper_Lost_Line(void);
uint8 Start_Avoid_Obstacles(void);
uint8 S_Bend_Recognition_Optimization(void);
uint8 Avoid_Obstacles_Left_Pro(void);
uint8 Avoid_Obstacles_Right_Pro(void);

int L_L = 0, L_R = 0, R_L = 0, R_R = 0, L = 0, R = 0;

int L_L_Upper = 0, L_L_Below = 0;
int L_R_Upper = 0, L_R_Below = 0;
int R_L_Upper = 0, R_L_Below = 0;
int R_R_Upper = 0, R_R_Below = 0;

TRACK_IDENTIFY_t Track_Identify_Date;

uint8 Identify_Cross_Flag = 0;

uint8 Identify_Track_Selection = 0, Identify_Track_Status = 0;
uint8 Identify_Track_Probe = 0;
uint8 Identify_Prev_Track = 0;
uint8 Identify_Allow_Number = 0;

uint8 Roundabout_Flag = 0;
uint8 Left_Roundabout_Flag = 0;

uint8 L_B_Flag = 0;

int Encoder_Integral_Max = 0;

int Temp_L_L_CROS = 0, Temp_L_R_CROS = 0;
int Temp_R_L_CROS = 0, Temp_R_R_CROS = 0;
uint8 Count_1 = 0;
uint8 Count_2 = 0;

int AO_Count = 0;
int AO_Count_Uppre = 0;
uint8 S_Bend_Left = 0;
uint8 S_Bend_Right = 0;
uint8 Stockpile[10];
uint8 Count_S_Bend = 0;

uint8 Left_Roundabout_Identify_Number = 0;
uint8 Right_Roundabout_Identify_Number = 0;
uint8 Left_Avoid_Obstacles_Identify_Number = 0;
uint8 Right_Avoid_Obstacles_Identify_Number = 0;

extern uint8 Kernel_Variable;

void Identify_Track_Init(void)
{
    TRACK_IDENTIFY_DATE_Init_Var(&Track_Identify_Date);
}

void Gain_Direction_Power_Control(void)
{
    uint8 k = 10;
    for(uint8 i = 0; i < MT9V03X_H; i++)
    {
        if(Original_L_Line[i] != 255 && Original_R_Line[i] != 0)
        {
            k = i;
            break;
        }
    }
    for(uint8 i = MT9V03X_H - 1 - 1; i > k; i--)
    {
        if(Original_L_Line[i] - Original_L_Line[i + 1] > 0 && Original_L_Line[i] != 255)
        {
            L_R += Original_L_Line[i] - Original_L_Line[i + 1];
            if(i >= 60)
            {
                L_R_Below += Original_L_Line[i] - Original_L_Line[i + 1];
            }else
            {
                L_R_Upper += Original_L_Line[i] - Original_L_Line[i + 1];
            }
        }else if(Original_L_Line[i] != 255)
        {
            L_L += Original_L_Line[i] - Original_L_Line[i + 1];
            if(i >= 60)
            {
                L_L_Below += Original_L_Line[i] - Original_L_Line[i + 1];
            }else
            {
                L_L_Upper += Original_L_Line[i] - Original_L_Line[i + 1];
            }
        }
        if(Original_R_Line[i] - Original_R_Line[i + 1] > 0 && Original_R_Line[i] != 0)
        {
            R_R += Original_R_Line[i] - Original_R_Line[i + 1];
            if(i >= 60)
            {
                R_R_Below += Original_R_Line[i] - Original_R_Line[i + 1];
            }else
            {
                R_R_Upper += Original_R_Line[i] - Original_R_Line[i + 1];
            }
        }else if(Original_R_Line[i] != 0)
        {
            R_L += Original_R_Line[i] - Original_R_Line[i + 1];
            if(i >= 60)
            {
                R_L_Below += Original_R_Line[i] - Original_R_Line[i + 1];
            }else
            {
                R_L_Upper += Original_R_Line[i] - Original_R_Line[i + 1];
            }
        }
    }
    L = L_L + L_R;
    R = R_L + R_R;
}

void Identify_Var_Init(void)
{
    L_L = 0;
    L_R = 0;
    R_L = 0;
    R_R = 0;
    L = 0;
    R = 0;
    L_L_Upper = 0, L_L_Below = 0;
    L_R_Upper = 0, L_R_Below = 0;
    R_L_Upper = 0, R_L_Below = 0;
    R_R_Upper = 0, R_R_Below = 0;
}

void TRACK_IDENTIFY_DATE_Init_Var(TRACK_IDENTIFY_t *Track_Identify)
{
    Track_Identify->Track_Selection = Track_NULL;
    Track_Identify->Track_Status = End;
    Track_Identify->Prev_Track = Prev_NULL;
    Track_Identify->Prev_Status = Prev_NULL;
    Track_Identify->Probe = Probe_NULL;

    Track_Identify->Track_data[Straightaway].Allow_Become_Straightaway_Min = 255;
    Track_Identify->Track_data[Straightaway].Allow_Become_Cross_Min = 5;
    Track_Identify->Track_data[Straightaway].Allow_Become_S_Bend_Min = 10;
    Track_Identify->Track_data[Straightaway].Allow_Become_Roundabout_Min = 5;
    Track_Identify->Track_data[Straightaway].Allow_Become_NULL_Min = 5;
    Track_Identify->Track_data[Straightaway].Allow_Become_Left_Roundabout_Min = 5;
    Track_Identify->Track_data[Straightaway].Allow_Become_Left_Avoid_Obstacles_Min = 5;
    Track_Identify->Track_data[Straightaway].Allow_Become_Right_Avoid_Obstacles_Min = 5;
    Track_Identify->Track_data[Straightaway].Allow_Become_Zebra_Crossing_Min = 1;

    Track_Identify->Track_data[Cross].Allow_Become_Straightaway_Min = 10;
    Track_Identify->Track_data[Cross].Allow_Become_Cross_Min = 255;
    Track_Identify->Track_data[Cross].Allow_Become_S_Bend_Min = 10;
    Track_Identify->Track_data[Cross].Allow_Become_Roundabout_Min = 5;
    Track_Identify->Track_data[Cross].Allow_Become_NULL_Min = 5;
    Track_Identify->Track_data[Cross].Allow_Become_Left_Roundabout_Min = 5;
    Track_Identify->Track_data[Cross].Allow_Become_Left_Avoid_Obstacles_Min = 5;
    Track_Identify->Track_data[Cross].Allow_Become_Right_Avoid_Obstacles_Min = 5;
    Track_Identify->Track_data[Cross].Allow_Become_Zebra_Crossing_Min = 5;

    Track_Identify->Track_data[S_Bend].Allow_Become_Straightaway_Min = 10;
    Track_Identify->Track_data[S_Bend].Allow_Become_Cross_Min = 5;
    Track_Identify->Track_data[S_Bend].Allow_Become_S_Bend_Min = 255;
    Track_Identify->Track_data[S_Bend].Allow_Become_Roundabout_Min = 5;
    Track_Identify->Track_data[S_Bend].Allow_Become_NULL_Min = 5;
    Track_Identify->Track_data[S_Bend].Allow_Become_Left_Roundabout_Min = 5;
    Track_Identify->Track_data[S_Bend].Allow_Become_Left_Avoid_Obstacles_Min = 5;
    Track_Identify->Track_data[S_Bend].Allow_Become_Right_Avoid_Obstacles_Min = 5;
    Track_Identify->Track_data[S_Bend].Allow_Become_Zebra_Crossing_Min = 5;

    Track_Identify->Track_data[Roundabout].Allow_Become_Straightaway_Min = 10;
    Track_Identify->Track_data[Roundabout].Allow_Become_Cross_Min = 5;
    Track_Identify->Track_data[Roundabout].Allow_Become_S_Bend_Min = 10;
    Track_Identify->Track_data[Roundabout].Allow_Become_Roundabout_Min = 255;
    Track_Identify->Track_data[Roundabout].Allow_Become_NULL_Min = 5;
    Track_Identify->Track_data[Roundabout].Allow_Become_Left_Roundabout_Min = 5;
    Track_Identify->Track_data[Roundabout].Allow_Become_Left_Avoid_Obstacles_Min = 5;
    Track_Identify->Track_data[Roundabout].Allow_Become_Right_Avoid_Obstacles_Min = 5;
    Track_Identify->Track_data[Roundabout].Allow_Become_Zebra_Crossing_Min = 5;

    Track_Identify->Track_data[Track_NULL].Allow_Become_Straightaway_Min = 10;
    Track_Identify->Track_data[Track_NULL].Allow_Become_Cross_Min = 5;
    Track_Identify->Track_data[Track_NULL].Allow_Become_S_Bend_Min = 10;
    Track_Identify->Track_data[Track_NULL].Allow_Become_Roundabout_Min = 5;
    Track_Identify->Track_data[Track_NULL].Allow_Become_NULL_Min = 255;
    Track_Identify->Track_data[Track_NULL].Allow_Become_Left_Roundabout_Min = 5;
    Track_Identify->Track_data[Track_NULL].Allow_Become_Left_Avoid_Obstacles_Min = 5;
    Track_Identify->Track_data[Track_NULL].Allow_Become_Right_Avoid_Obstacles_Min = 5;
    Track_Identify->Track_data[Track_NULL].Allow_Become_Zebra_Crossing_Min = 1;

    Track_Identify->Track_data[Left_Roundabout].Allow_Become_Straightaway_Min = 20;
    Track_Identify->Track_data[Left_Roundabout].Allow_Become_Cross_Min = 5;
    Track_Identify->Track_data[Left_Roundabout].Allow_Become_S_Bend_Min = 20;
    Track_Identify->Track_data[Left_Roundabout].Allow_Become_Roundabout_Min = 10;
    Track_Identify->Track_data[Left_Roundabout].Allow_Become_NULL_Min = 5;
    Track_Identify->Track_data[Left_Roundabout].Allow_Become_Left_Roundabout_Min = 255;
    Track_Identify->Track_data[Left_Roundabout].Allow_Become_Left_Avoid_Obstacles_Min = 5;
    Track_Identify->Track_data[Left_Roundabout].Allow_Become_Right_Avoid_Obstacles_Min = 5;
    Track_Identify->Track_data[Left_Roundabout].Allow_Become_Zebra_Crossing_Min = 5;

    Track_Identify->Track_data[Left_Avoid_Obstacles].Allow_Become_Straightaway_Min = 20;
    Track_Identify->Track_data[Left_Avoid_Obstacles].Allow_Become_Cross_Min = 5;
    Track_Identify->Track_data[Left_Avoid_Obstacles].Allow_Become_S_Bend_Min = 20;
    Track_Identify->Track_data[Left_Avoid_Obstacles].Allow_Become_Roundabout_Min = 10;
    Track_Identify->Track_data[Left_Avoid_Obstacles].Allow_Become_NULL_Min = 5;
    Track_Identify->Track_data[Left_Avoid_Obstacles].Allow_Become_Left_Roundabout_Min = 5;
    Track_Identify->Track_data[Left_Avoid_Obstacles].Allow_Become_Left_Avoid_Obstacles_Min = 255;
    Track_Identify->Track_data[Left_Avoid_Obstacles].Allow_Become_Right_Avoid_Obstacles_Min = 5;
    Track_Identify->Track_data[Left_Avoid_Obstacles].Allow_Become_Zebra_Crossing_Min = 5;

    Track_Identify->Track_data[Right_Avoid_Obstacles].Allow_Become_Straightaway_Min = 20;
    Track_Identify->Track_data[Right_Avoid_Obstacles].Allow_Become_Cross_Min = 5;
    Track_Identify->Track_data[Right_Avoid_Obstacles].Allow_Become_S_Bend_Min = 20;
    Track_Identify->Track_data[Right_Avoid_Obstacles].Allow_Become_Roundabout_Min = 5;
    Track_Identify->Track_data[Right_Avoid_Obstacles].Allow_Become_NULL_Min = 5;
    Track_Identify->Track_data[Right_Avoid_Obstacles].Allow_Become_Left_Roundabout_Min = 5;
    Track_Identify->Track_data[Right_Avoid_Obstacles].Allow_Become_Left_Avoid_Obstacles_Min = 5;
    Track_Identify->Track_data[Right_Avoid_Obstacles].Allow_Become_Right_Avoid_Obstacles_Min = 255;
    Track_Identify->Track_data[Right_Avoid_Obstacles].Allow_Become_Zebra_Crossing_Min = 5;

    Track_Identify->Track_data[Zebra_Crossing].Allow_Become_Straightaway_Min = 5;
    Track_Identify->Track_data[Zebra_Crossing].Allow_Become_Cross_Min = 5;
    Track_Identify->Track_data[Zebra_Crossing].Allow_Become_S_Bend_Min = 5;
    Track_Identify->Track_data[Zebra_Crossing].Allow_Become_Roundabout_Min = 5;
    Track_Identify->Track_data[Zebra_Crossing].Allow_Become_NULL_Min = 5;
    Track_Identify->Track_data[Zebra_Crossing].Allow_Become_Left_Roundabout_Min = 5;
    Track_Identify->Track_data[Zebra_Crossing].Allow_Become_Left_Avoid_Obstacles_Min = 5;
    Track_Identify->Track_data[Zebra_Crossing].Allow_Become_Right_Avoid_Obstacles_Min = 5;
    Track_Identify->Track_data[Zebra_Crossing].Allow_Become_Zebra_Crossing_Min = 255;

    Track_Identify->Allow_Become_Straightaway = 0;
    Track_Identify->Allow_Become_Cross = 0;
    Track_Identify->Allow_Become_S_Bend = 0;
    Track_Identify->Allow_Become_Roundabout = 0;
    Track_Identify->Allow_Become_NULL = 0;
    Track_Identify->Allow_Become_Left_Roundabout = 0;
    Track_Identify->Allow_Become_Left_Avoid_Obstacles = 0;
    Track_Identify->Allow_Become_Right_Avoid_Obstacles = 0;
    Track_Identify->Allow_Become_Zebra_Crossing = 0;
}

void TRACK_IDENTIFY_DATE_Update(TRACK_IDENTIFY_t *Track_Identify)
{
    Identify_Var_Init();

    Gain_Direction_Power_Control();

    TRACK_IDENTIFY_DATE_Examine(&Track_Identify_Date);

    TRACK_IDENTIFY_DATE_Change_Status(&Track_Identify_Date);

    Gain_Selection_And_Status();
}

void TRACK_IDENTIFY_DATE_Examine(TRACK_IDENTIFY_t *Track_Identify)
{
    Track_Identify->Probe =  TRACK_IDENTIFY_DATE_Identify_Track(&Track_Identify_Date);

    if(Track_Identify->Probe == Probe_NULL)
    {
        if(Track_Identify->Track_Status == End)
        {
            Track_Identify->Allow_Become_NULL++;
            Identify_Allow_Number++;
        }
    }else if(Track_Identify->Probe == Probe_Straightaway)
    {
        if(Track_Identify->Track_Status == End)
        {
            Track_Identify->Allow_Become_Straightaway++;
            Identify_Allow_Number++;
        }
    }else if(Track_Identify->Probe == Probe_Cross)
    {
        if(Track_Identify->Track_Status == End)
        {
            Track_Identify->Allow_Become_Cross++;
            Identify_Allow_Number++;
        }
    }else if(Track_Identify->Probe == Probe_S_Bend)
    {
        if(Track_Identify->Track_Status == End)
        {
            Track_Identify->Allow_Become_S_Bend++;
            Identify_Allow_Number++;
        }
    }else if(Track_Identify->Probe == Probe_Roundabout)
    {
        if(Track_Identify->Track_Status == End)
        {
            Track_Identify->Allow_Become_Roundabout++;
            Identify_Allow_Number++;
        }
    }else if(Track_Identify->Probe == Probe_Left_Roundabout)
    {
        if(Track_Identify->Track_Status == End)
        {
            Track_Identify->Allow_Become_Left_Roundabout++;
            Identify_Allow_Number++;
        }
    }else if(Track_Identify->Probe == Probe_Left_Avoid_Obstacles)
    {
        if(Track_Identify->Track_Status == End)
        {
            Track_Identify->Allow_Become_Left_Avoid_Obstacles++;
            Identify_Allow_Number++;
        }
    }else if(Track_Identify->Probe == Probe_Right_Avoid_Obstacles)
    {
        if(Track_Identify->Track_Status == End)
        {
            Track_Identify->Allow_Become_Right_Avoid_Obstacles++;
            Identify_Allow_Number++;
        }
    }else if(Track_Identify->Probe == Probe_Zebra_Crossing)
    {
        if(Track_Identify->Track_Status == End)
        {
            Track_Identify->Allow_Become_Zebra_Crossing++;
            Identify_Allow_Number++;
        }
    }

    if(Track_Identify->Track_Status == End)
    {
        if(Track_Identify->Allow_Become_Straightaway >= Track_Identify->Track_data[Track_Identify->Track_Selection].Allow_Become_Straightaway_Min)
        {
            TRACK_IDENTIFY_DATE_Change_Track(&Track_Identify_Date);
        }else if(Track_Identify->Allow_Become_Cross >= Track_Identify->Track_data[Track_Identify->Track_Selection].Allow_Become_Cross_Min)
        {
            TRACK_IDENTIFY_DATE_Change_Track(&Track_Identify_Date);
        }else if(Track_Identify->Allow_Become_S_Bend >= Track_Identify->Track_data[Track_Identify->Track_Selection].Allow_Become_S_Bend_Min)
        {
            TRACK_IDENTIFY_DATE_Change_Track(&Track_Identify_Date);
        }else if(Track_Identify->Allow_Become_Roundabout >= Track_Identify->Track_data[Track_Identify->Track_Selection].Allow_Become_Roundabout_Min)
        {
            TRACK_IDENTIFY_DATE_Change_Track(&Track_Identify_Date);
        }else if(Track_Identify->Allow_Become_NULL >= Track_Identify->Track_data[Track_Identify->Track_Selection].Allow_Become_NULL_Min)
        {
            TRACK_IDENTIFY_DATE_Change_Track(&Track_Identify_Date);
        }else if(Track_Identify->Allow_Become_Left_Roundabout >= Track_Identify->Track_data[Track_Identify->Track_Selection].Allow_Become_Left_Roundabout_Min)
        {
            TRACK_IDENTIFY_DATE_Change_Track(&Track_Identify_Date);
        }else if(Track_Identify->Allow_Become_Left_Avoid_Obstacles >= Track_Identify->Track_data[Track_Identify->Track_Selection].Allow_Become_Left_Avoid_Obstacles_Min)
        {
            TRACK_IDENTIFY_DATE_Change_Track(&Track_Identify_Date);
        }else if(Track_Identify->Allow_Become_Right_Avoid_Obstacles >= Track_Identify->Track_data[Track_Identify->Track_Selection].Allow_Become_Right_Avoid_Obstacles_Min)
        {
            TRACK_IDENTIFY_DATE_Change_Track(&Track_Identify_Date);
        }else if(Track_Identify->Allow_Become_Zebra_Crossing >= Track_Identify->Track_data[Track_Identify->Track_Selection].Allow_Become_Zebra_Crossing_Min)
        {
            TRACK_IDENTIFY_DATE_Change_Track(&Track_Identify_Date);
        }
    }else if(Track_Identify->Track_Status != End)
    {

    }
}
void TRACK_IDENTIFY_DATE_Change_Track(TRACK_IDENTIFY_t *Track_Identify)
{
    Track_Identify->Prev_Track = Track_Identify->Track_Selection;
    Track_Identify->Track_Selection = Track_Identify->Probe;

    if(Track_Identify->Probe == Probe_Straightaway || Track_Identify->Probe == Probe_NULL)
    {
        Track_Identify->Track_Status = End;
    }else
    {
        Track_Identify->Track_Status = Start;
    }

    Track_Identify->Allow_Become_Straightaway = 0;
    Track_Identify->Allow_Become_Cross = 0;
    Track_Identify->Allow_Become_S_Bend = 0;
    Track_Identify->Allow_Become_Roundabout = 0;
    Track_Identify->Allow_Become_NULL = 0;
    Track_Identify->Allow_Become_Left_Roundabout = 0;
    Track_Identify->Allow_Become_Left_Avoid_Obstacles = 0;
    Track_Identify->Allow_Become_Right_Avoid_Obstacles = 0;
    Track_Identify->Allow_Become_Zebra_Crossing = 0;
    Identify_Allow_Number = 0;

    if(Track_Identify->Track_Selection == Zebra_Crossing)
    {
        Kernel_Variable++;
    }
}

void TRACK_IDENTIFY_DATE_Change_Status(TRACK_IDENTIFY_t *Track_Identify)
{
    if(Track_Identify->Track_Selection == Straightaway || Track_Identify->Track_Selection == Track_NULL)
    {
        return;
    }else
    {
        TRACK_IDENTIFY_DATE_Identify_Status(&Track_Identify_Date);
    }
}

enum Return_Track TRACK_IDENTIFY_DATE_Identify_Track(TRACK_IDENTIFY_t *Track_Identify)
{
    if(Whether_Zebra_Crossing())
    {
        return Return_Zebra_Crossing;
    }
    if(L_L > -5 && R_R < 5 && L_Far_Lost == 0 && R_Far_Lost == 0 && L_Lost - L_Near_Lost == 0 && R_Lost - R_Near_Lost == 0)
    {
        if(!(abs(Original_L_Line[0] - 94) < 50 && abs(Original_R_Line[0] - 94) < 50))
        {
            return Return_NULL;
        }
        if(L_R_Upper < 50 && L_R_Below < 50 && R_L_Upper > -50 && R_L_Below > -50)
        {
            return Return_Straightaway;
        }
    }
    //
    if(L_L > -5 && R_R < 5 && L_Far_Lost < 20 && R_Far_Lost < 20 && L_Lost - L_Near_Lost == 0 && R_Lost - R_Near_Lost == 0)
    {
        if(!(abs(Original_L_Line[0] - 94) < 100 && abs(Original_R_Line[0] - 94) < 100))
        {
            return Return_NULL;
        }
        if(L_R_Upper < 60 && L_R_Below < 60 && R_L_Upper > -60 && R_L_Below > -60)
        {
            return Return_Straightaway;
        }
    }
    //
    S_Bend_Recognition_Optimization();
//    if((abs(L_L) + abs(R_R) > 10) && L_Far_Lost == 0 && R_Far_Lost == 0 && L_L != 0 && R_R != 0 && abs(L_R) < 130 && abs(R_L) < 130 && Original_L_Line[0] != 255)
//    {
//        if(S_Bend_Left + S_Bend_Right >= 3 && S_Bend_Left >= 1 && S_Bend_Right >= 1)
//        {
//            Count_S_Bend = 1;
//            return Return_S_Bend;
//        }
//    }
    if(abs(94 - Original_L_Line[0]) < 50 && abs(Original_R_Line[0] - 94) < 50)
    {
        if(S_Bend_Left >= 1 && S_Bend_Right >= 1)
        {
            if(L_Lost - L_Near_Lost == 0 && R_Lost - R_Near_Lost == 0)
            {
                if(L_R < 100 && R_L > -100 && L_L != 0 && R_R != 0)
                {
                    return Return_S_Bend;
                }
            }
        }
    }
    if(((L_Break >= 1 && R_Break >= 1) || L_Break == 2 || R_Break == 2) && ((L_R > 90 && L_L < - 25) || (R_R > 25 && R_L < -90)))
    {
        if(abs((L_Lost - L_Far_Lost - L_Near_Lost) - (R_Lost - R_Far_Lost - R_Near_Lost)) <= 20)
        {
            if(L_Lost - L_Far_Lost - L_Near_Lost >= 10 && R_Lost - R_Far_Lost - R_Near_Lost >= 10)
            {
                return Return_Cross;
            }
        }
    }
    //
    if(L_Break >= 1 && R_Break >= 1)
    {
        if(Original_L_Line[0] != 255 && Original_R_Line[0] != 0)
        {
            if(Cross_Recognition_Optimization_Success())
            {
                if(L_Far_Lost >= 10 && R_Far_Lost >= 10 && abs(L_Far_Lost - R_Far_Lost) <= 20)
                {
                    if(L_L < -35 && R_R > 35)
                    {
                        return Return_Cross;
                    }
                }
                if(L_Lost >= 20 && R_Lost >= 20 && abs(L_Lost - R_Lost) < 20)
                {
                    if(L_L < -20 && R_R > 20)
                    {
                        return Return_Cross;
                    }
                }
                if(L_Lost - L_Far_Lost - L_Near_Lost == 40 && R_Lost - R_Far_Lost - R_Near_Lost == 40)
                {
                    if(L_L < -5 && R_R > 5)
                    {
                        return Return_Cross;
                    }

                }
            }
        }
        if(L_Near_Lost == 40 && R_Near_Lost == 40)
        {
            return Return_Cross;
        }
    }
    if(R_Break == 2)
    {
        if(L_Lost - L_Near_Lost >= 15 && R_Lost - R_Near_Lost >= 15)
        {
            if(abs((L_Lost - L_Near_Lost) - (R_Lost - R_Near_Lost)) < 25)
            {
                if(R_Break_Two_CROS())
                {
                    return Return_Cross;
                }
            }
        }
    }
    if(L_Break == 2)
    {
        if(L_Lost - L_Near_Lost >= 15 && R_Lost - R_Near_Lost >= 15)
        {
            if(abs((L_Lost - L_Near_Lost) - (R_Lost - R_Near_Lost)) < 25)
            {
                if(L_Break_Two_CROS())
                {
                    return Return_Cross;
                }
            }
        }
    }
    //
    if(Right_Roundabout_Identify_Number != 0)
    {
        if(L_Lost - L_Near_Lost == 0 && L_L_Below > -15 && L_R_Upper < 50 && abs(L_L) < 5 && abs(L_R) < 100)
        {
            if(Original_L_Line[0] != 255 && L_Far_Lost == 0 && (R_Lost - R_Far_Lost - R_Near_Lost >= 10 || R_Far_Lost >= 25))
            {
                if(Enter_Right_Roundabout_Prevent_Misjudgment())
                {
                    return Return_Roundabout;
                }
            }
        }
    }

    if(Left_Roundabout_Identify_Number != 0)
    {
        if(R_Lost - R_Near_Lost == 0 && abs(R_R) <= 5 && abs(R_L) < 100)
        {
            if(Original_L_Line[0] != 255 && R_Far_Lost ==0 && (L_Lost - L_Far_Lost - L_Near_Lost >= 10 || L_Far_Lost >= 25))
            {
                if(Enter_Left_Roundabout_Prevent_Misjudgment())
                {
    //                for(uint8 i = 10; i < 100; i++)
    //                {
    //                    ips114_draw_point(Original_L_Line[L_B_Flag], i, RGB565_GREEN);
    //                    ips114_draw_point(Original_L_Line[L_B_Flag] - 1, i, RGB565_GREEN);
    //                }
                    return Return_Left_Roundabout;
                }
            }
        }
    }
    Start_Avoid_Obstacles();
    //
//    if(abs(AO_Count) > 10 && abs(AO_Count_Uppre) > 5 && abs(AO_Count) < 30 && abs(AO_Count_Uppre) < 20)
//    {
//        if(L_Lost - L_Far_Lost - L_Near_Lost == 0 && R_Lost - R_Far_Lost - R_Near_Lost == 0)
//        {
//            if(AO_Count > 0 && AO_Count_Uppre < 0)
//            {
//                return Return_Right_Avoid_Obstacles;
//            }else if(AO_Count < 0 && AO_Count_Uppre > 0)
//            {
//                return Return_Left_Avoid_Obstacles;
//            }
//        }
//    }
    if((abs(94 - Original_L_Line[0]) < 50 && abs(Original_R_Line[0] - 94) < 50) || Original_R_Line[0] - Original_L_Line[0] < 50)
    {
        if(L_R < 100 && R_L > -100 && S_Bend_Left == 0 && S_Bend_Right == 0)
        {
            if(L_L > -20 && R_R < 5 && Avoid_Obstacles_Left_Pro() && R_R_Upper == 0 && Left_Avoid_Obstacles_Identify_Number != 0)
            {
                return Return_Left_Avoid_Obstacles;
            }else if(L_L > -5 && R_R < 20 && Avoid_Obstacles_Right_Pro() && L_L_Upper == 0 && Right_Avoid_Obstacles_Identify_Number != 0)
            {
                return Return_Right_Avoid_Obstacles;
            }
        }
    }
    //
    /*if(Original_L_Line[0] != 255 && abs(L_L) + abs(L_R) < 100 && abs(R_L) + abs(R_R) < 100 && L_Far_Lost == 0 && R_Far_Lost == 0)
    {
        if(abs(R_R) < 5 && L_L < -10 && L_L > -30 && abs(R_L) < 100 && abs(L_R) < 100 && L_R_Below < 40 && L_R_Below > -5 && R_L_Below < 5 && R_L_Below > -40)
        {
            if(L_L_Upper > -25 && L_L_Upper < 5 && L_R_Upper > -5 && L_R_Upper < 55)
            {
                if(R_L_Upper > -45 && R_L_Upper < 5 && R_R_Upper < 5 && R_R_Upper > -5)
                {
                    return Return_Left_Avoid_Obstacles;
                }
            }
        }
        if(abs(L_L) < 5 && R_R > 10 && R_R < 30 && abs(L_R) < 100 && abs(R_L) < 100 && L_R_Below < 40 && L_R_Below > -5 && R_L_Below < 5 && R_L_Below > -40)
        {
            if(L_L_Upper > -5 && L_L_Upper < 5 && L_R_Upper > -5 && L_R_Upper < 45)
            {
                if(R_L_Upper < 5 && R_L_Upper > -55 && R_R_Upper > -5 && R_R_Upper < 25)
                {
                    return Return_Right_Avoid_Obstacles;
                }
            }
        }
    }*/
    return Return_NULL;
}

uint8 TRACK_IDENTIFY_DATE_Identify_Status(TRACK_IDENTIFY_t *Track_Identify)
{
    Track_Identify->Prev_Status = Track_Identify->Track_Status;
    if(Track_Identify->Track_Selection == Cross)
    {
        if(Track_Identify->Track_Status == Start)
        {
            if(Identify_Cross_Flag == 0)
            {
                if(L_Near_Lost >= 20 && R_Near_Lost >= 20)
                {
                    Identify_Cross_Flag = 1;
                }
            }else if(Identify_Cross_Flag == 1)
            {
                if(L_Near_Lost < 5 || R_Near_Lost < 5)
                {
                    Identify_Cross_Flag = 0;
                    //Track_Identify->Track_Status = Process;
                    Track_Identify->Track_Status = End;
                }
            }
        }else if(Track_Identify->Track_Status == Process)
        {
            if(Identify_Cross_Flag == 0)
            {
                if(L_Near_Lost >= 35 && R_Near_Lost >= 35)
                {
                    Identify_Cross_Flag = 1;
                }
            }else if(Identify_Cross_Flag == 1)
            {
                if(L_Near_Lost < 5 || R_Near_Lost < 5 || Original_L_Line[0] == 255)
                {
                    Identify_Cross_Flag = 0;
                    Track_Identify->Track_Status = End;
                }
            }
        }
    }else if(Track_Identify->Track_Selection == S_Bend)
    {
        if(Track_Identify->Track_Status == Start)
        {
            if(L_L == 0 && R_R == 0)
            {
                Track_Identify->Track_Status = End;
            }else if(L_Lost - L_Near_Lost >= 5 || R_Lost - R_Near_Lost >= 5 || Original_L_Line[0] == 255)
            {
                Track_Identify->Track_Status = End;
            }
        }
    }else if(Track_Identify->Track_Selection == Roundabout)
    {
        if(Track_Identify->Track_Status == Start)
        {
            if(R_Near_Lost >= 35 && Roundabout_Flag == 0)
            {
                Roundabout_Flag = 1;
            }
            if(R_Near_Lost <= 5 && Roundabout_Flag == 1)
            {
                Roundabout_Flag = 2;
            }
//            if(Find_Roundabout_Right_Corner_Pro() && Roundabout_Flag == 0)
//            {
//                Roundabout_Flag = 2;
//            }
//            if((Enter_The_Ring_Pull_The_Line_Leave_Right()) && Original_L_Line[0] == 255 && Roundabout_Flag == 2 && L_R > 100 && L_Near_Lost <= 35 && Assist_Right_Roundabout_Zero_End())
//            {
//                Track_Identify->Track_Status = Process;
//            }
            if(L_Near_Lost < 20 && Roundabout_Flag == 2 && L_Lost - L_Near_Lost == 0 && Original_L_Line[0] == 255)
            {
                Track_Identify->Track_Status = Process;
            }
        }else if(Track_Identify->Track_Status == Process)
        {
            if(Roundabout_First_Find_Corner() && Roundabout_Flag == 2)
            {
                Roundabout_Flag = 3;
            }
            if(Original_L_Line[9] == 255 && L_Lost - L_Far_Lost - L_Near_Lost >= 20 && Roundabout_Flag == 3 && R_Lost - R_Far_Lost - R_Near_Lost >= 20)
            {
                Roundabout_Flag = 12;
            }
            if(Original_L_Line[0] != 255 && Roundabout_Flag == 12)
            {
                if(L_Lost < 5 || Roundabout_Find_Right_Corner())
                {
                    Roundabout_Flag = 6;
                }
            }
            if(Roundabout_Flag == 6 && R_Lost - R_Far_Lost - R_Near_Lost == 0)
            {
                Roundabout_Flag = 0;
                Temp_Corner = 100;
                Temp_Value = 0;
                Right_Roundabout_Identify_Number--;
                Track_Identify->Track_Status = End;
            }
        }
    }else if(Track_Identify->Track_Selection == Left_Roundabout)
    {
        if(Track_Identify->Track_Status == Start)
        {
            if(L_Near_Lost >= 35 && Left_Roundabout_Flag == 0)
            {
                Left_Roundabout_Flag = 1;
            }
            if(L_Near_Lost <= 5 && Left_Roundabout_Flag == 1)
            {
                Left_Roundabout_Flag = 2;
            }
//            if((R_Near_Lost < 10 || Enter_The_Ring_Pull_The_Line_Leave_Left()) && Original_L_Line[0] == 255 && Left_Roundabout_Flag == 2 && R_Near_Lost <= 35 && Assist_Left_Roundabout_Zero_End())
//            {
//                Track_Identify->Track_Status = Process;
//            }
            if(R_Near_Lost < 20 && Original_L_Line[0] == 255 && Left_Roundabout_Flag == 2 && R_Lost - R_Near_Lost == 0)
            {
                Track_Identify->Track_Status = Process;
            }
        }else if(Track_Identify->Track_Status == Process)
        {
            if(Roundabout_First_Find_Corner_Left() && Left_Roundabout_Flag == 2)
            {
                Left_Roundabout_Flag = 3;
            }
            if(Original_L_Line[9] == 255 && R_Lost - R_Far_Lost - R_Near_Lost >= 20 && Left_Roundabout_Flag == 3 && L_Lost - L_Far_Lost - L_Near_Lost >= 20)
            {
                Left_Roundabout_Flag = 12;
            }
            if(Original_L_Line[0] != 255 && Left_Roundabout_Flag == 12)
            {
                if(R_Lost - R_Far_Lost < 10 || Left_Roundabout_Find_Left_Corner())
                {
                    Left_Roundabout_Flag = 6;
                }
            }
            if(Left_Roundabout_Flag == 6 && L_Lost - L_Far_Lost - L_Near_Lost == 0)
            {
                Left_Roundabout_Flag = 0;
                Temp_Corner_Left = 88;
                Temp_Value_Left = 0;
                Left_Roundabout_Identify_Number--;
                Track_Identify->Track_Status = End;
            }
        }
    }else if(Track_Identify->Track_Selection == Left_Avoid_Obstacles)
    {
        if(Track_Identify->Track_Status == Start)
        {
            Encoder_Integral_Max += Speed;
            if(Encoder_Integral_Max > 5000)
            {
                Encoder_Integral_Max = 0;
                Left_Avoid_Obstacles_Identify_Number--;
                Track_Identify->Track_Status = End;
            }
        }
    }else if(Track_Identify->Track_Selection == Right_Avoid_Obstacles)
    {
        if(Track_Identify->Track_Status == Start)
        {
            Encoder_Integral_Max += Speed;
            if(Encoder_Integral_Max > 5000)
            {
                Encoder_Integral_Max = 0;
                Right_Avoid_Obstacles_Identify_Number--;
                Track_Identify->Track_Status = End;
            }
        }
    }else if(Track_Identify->Track_Selection == Zebra_Crossing)
    {
        if(Track_Identify->Track_Status == Start)
        {
            Encoder_Integral_Max += Speed;
            if(Encoder_Integral_Max > 5000)
            {
                Encoder_Integral_Max = 0;
                Track_Identify->Track_Status = End;
            }
        }
    }
    return 0;
}

void Gain_Selection_And_Status(void)
{
    Identify_Track_Selection = (uint8)Track_Identify_Date.Track_Selection;
    Identify_Track_Status = (uint8)Track_Identify_Date.Track_Status;
    Identify_Track_Probe = (uint8)Track_Identify_Date.Probe;
    Identify_Prev_Track = (uint8)Track_Identify_Date.Prev_Track;
}

void Identify_Track_Update(void)
{
    TRACK_IDENTIFY_DATE_Update(&Track_Identify_Date);
}

uint8 Roundabout_Find_Right_Corner(void)
{
    for(uint8 i = 5; i < MT9V03X_H - 5; i++)
    {
        if(Original_R_Line[i] == MT9V03X_W - 1 || Original_R_Line[i] == 0)
        {
            continue;
        }
        if(Original_R_Line[i] - Original_R_Line[i - 1] >= 0 &&
                Original_R_Line[i] - Original_R_Line[i - 2] >= 0 &&
                Original_R_Line[i] - Original_R_Line[i - 3] >= 0 &&
                Original_R_Line[i] - Original_R_Line[i - 4] >= 0 &&
                Original_R_Line[i] - Original_R_Line[i + 1] <= -1 &&
                Original_R_Line[i] - Original_R_Line[i + 2] <= -3 &&
                Original_R_Line[i] - Original_R_Line[i + 3] <= -5 &&
                Original_R_Line[i] - Original_R_Line[i + 4] <= -7 &&
                Original_R_Line[i + 5] == MT9V03X_W - 1 &&
                Original_R_Line[i + 6] == MT9V03X_W - 1)
        {
            return 1;
        }
    }
    return 0;
}

uint8 Left_Roundabout_Find_Left_Corner(void)
{
    for(uint8 i = 5; i < MT9V03X_H - 5; i++)
    {
        if(Original_L_Line[i] == 0 || Original_L_Line[i] == 255)
        {
            continue;
        }
        if(Original_L_Line[i] - Original_L_Line[i - 1] <= 0
                && Original_L_Line[i] - Original_L_Line[i - 2] <= 0
                && Original_L_Line[i] - Original_L_Line[i - 3] <= 0
                && Original_L_Line[i] - Original_L_Line[i - 4] <= 0
                && Original_L_Line[i] - Original_L_Line[i + 1] >= 1
                && Original_L_Line[i] - Original_L_Line[i + 2] >= 3
                && Original_L_Line[i] - Original_L_Line[i + 3] >= 5
                && Original_L_Line[i] - Original_L_Line[i + 4] >= 7
                && Original_L_Line[i + 5] == 0
                && Original_L_Line[i + 6] == 0)
        {
            return 1;
        }
    }
    return 0;
}

uint8 Enter_Left_Roundabout_Prevent_Misjudgment(void)
{
    for(uint8 i = MT9V03X_H - 12; i > 5; i--)
    {
        if(Original_L_Line[i] == 255)
        {
            continue;
        }
        if(Original_L_Line[i] == 0)
        {
            break;
        }
        if(Original_L_Line[i] - Original_L_Line[i + 1] >= 0 &&
                Original_L_Line[i] - Original_L_Line[i + 2] >= 0 &&
                Original_L_Line[i] - Original_L_Line[i + 3] >= 0 &&
                Original_L_Line[i] - Original_L_Line[i + 4] >= 0 &&
                Original_L_Line[i - 3] == 0 &&
                Original_L_Line[i - 4] == 0 &&
                Original_L_Line[i - 5] == 0 &&
                Original_L_Line[i - 6] == 0)
        {
            return 1;
        }
    }
    return 0;
}

uint8 Enter_Right_Roundabout_Prevent_Misjudgment(void)
{
    for(uint8 i = MT9V03X_H - 12; i > 5; i--)
    {
        if(Original_R_Line[i] == 0)
        {
            continue;
        }
        if(Original_R_Line[i] == MT9V03X_W - 1)
        {
            break;
        }
        if(Original_R_Line[i] - Original_R_Line[i + 1] <= 0 &&
                Original_R_Line[i] - Original_R_Line[i + 2] <= 0 &&
                Original_R_Line[i] - Original_R_Line[i + 3] <= 0 &&
                Original_R_Line[i] - Original_R_Line[i + 4] <= 0 &&
                Original_R_Line[i - 1] == MT9V03X_W - 1 &&
                Original_R_Line[i - 2] == MT9V03X_W - 1 &&
                Original_R_Line[i - 3] == MT9V03X_W - 1 &&
                Original_R_Line[i - 4] == MT9V03X_W - 1)
        {
            return 1;
        }
    }
    return 0;
}

uint8 Roundabout_First_Find_Corner(void)
{
    for(uint8 i = MT9V03X_H - 20; i >= 20; i--)
    {
        if(Original_L_Line[i] == 0 || Original_L_Line[i] == 255)
        {
            continue;
        }
        if(Original_L_Line[i] - Original_L_Line[i + 1] >= 0
                && Original_L_Line[i] - Original_L_Line[i + 2] >= 0
                && Original_L_Line[i] - Original_L_Line[i + 3] >= 0
                && Original_L_Line[i] - Original_L_Line[i + 4] >= 0
                && Original_L_Line[i] - Original_L_Line[i - 1] >= 0
                && Original_L_Line[i] - Original_L_Line[i - 2] >= 0
                && Original_L_Line[i] - Original_L_Line[i - 3] >= 0
                && Original_L_Line[i] - Original_L_Line[i - 4] >= 0)
        {
            return 1;
        }
    }
    return 0;
}

uint8 Find_Roundabout_Right_Corner_Pro(void)
{
    for(uint8 i =5; i < MT9V03X_H; i++)
    {
        if(Original_R_Line[i] == 0 || Original_R_Line[i] == MT9V03X_W - 1)
        {
            continue;
        }
        if(Original_R_Line[i] - Original_R_Line[i - 1] >= 0
                && Original_R_Line[i] - Original_R_Line[i - 2] >= 0
                && Original_R_Line[i] - Original_R_Line[i - 3] >= 0
                && Original_R_Line[i] - Original_R_Line[i - 4] >= 0
                && Original_R_Line[i] - Original_R_Line[i - 1] <= 1
                && Original_R_Line[i] - Original_R_Line[i - 2] <= 2
                && Original_R_Line[i] - Original_R_Line[i - 3] <= 3
                && Original_R_Line[i] - Original_R_Line[i - 4] <= 4
                && Original_R_Line[i + 1] == MT9V03X_W - 1
                && Original_R_Line[i + 2] == MT9V03X_W - 1
                && Original_R_Line[i + 3] == MT9V03X_W - 1
                && Original_R_Line[i + 4] == MT9V03X_W - 1)
        {
            return 1;
        }
    }
    return 0;
}

uint8 Roundabout_First_Find_Corner_Left(void)
{
    for(uint8 i = MT9V03X_H - 20; i >= 20; i--)
    {
        if(Original_R_Line[i] == MT9V03X_W - 1 || Original_R_Line[i] == 0)
        {
            continue;
        }
        if(Original_R_Line[i] - Original_R_Line[i + 1] <= 0
                && Original_R_Line[i] - Original_R_Line[i + 2] <= 0
                && Original_R_Line[i] - Original_R_Line[i + 3] <= 0
                && Original_R_Line[i] - Original_R_Line[i + 4] <= 0
                && Original_R_Line[i] - Original_R_Line[i - 1] <= 0
                && Original_R_Line[i] - Original_R_Line[i - 2] <= 0
                && Original_R_Line[i] - Original_R_Line[i - 3] <= 0
                && Original_R_Line[i] - Original_R_Line[i - 4] <= 0)
        {
            return 1;
        }
    }
    return 0;
}

uint8 Enter_The_Ring_Pull_The_Line_Leave_Right(void)
{
    if(Original_L_Line[MT9V03X_H - 1] != 0 && Original_L_Line[0] == 255)
    {
        for(uint8 i = 0; i < MT9V03X_H; i++)
        {
            if(Original_L_Line[i] == 0)
            {
                return 0;
            }
        }
        return 1;
    }
    uint8 i;
    for(i = MT9V03X_H; i > 10; i--)
    {
        if(Original_L_Line[i - 1] != 0)
        {
            break;
        }
    }
    if(Original_L_Line[i - 1] - Original_L_Line[i] > 5)
    {
        return 0;
    }
    if(L_Far_Lost > 0)
    {
        return 0;
    }
    for(uint8 j = 0; j < i; j++)
    {
        if(Original_L_Line[j] == 0)
        {
            return 0;
        }
    }
    if(Original_L_Line[0] != 255)
    {
        return 0;
    }
    return 1;
}

uint8 Enter_The_Ring_Pull_The_Line_Leave_Left(void)
{
    if(Original_R_Line[MT9V03X_H - 1] != MT9V03X_W - 1 && Original_R_Line[0] == 0)
    {
        for(uint8 i = 0; i < MT9V03X_H; i++)
        {
            if(Original_R_Line[i] == MT9V03X_W - 1)
            {
                return 0;
            }
        }
        return 1;
    }
    uint8 i;
    for(i = MT9V03X_H; i > 10; i--)
    {
        if(Original_R_Line[i - 1] != MT9V03X_W - 1)
        {
            break;
        }
    }
    if(Original_R_Line[i - 1] - Original_R_Line[i] < -5)
    {
        return 0;
    }
    if(R_Far_Lost > 0)
    {
        return 0;
    }
    for(uint8 j = 0; j < i; j++)
    {
        if(Original_R_Line[j] == MT9V03X_W - 1)
        {
            return 0;
        }
    }
    if(Original_R_Line[0] != 0)
    {
        return 0;
    }
    return 1;
}

uint8 Whether_Zebra_Crossing(void)
{
    if(!(Identify_Track_Selection == 0 || Identify_Track_Selection == 4))
    {
        return 0;
    }
    Count_1 = 0;
    for(uint8 j = Original_L_Line[100] + 5; j < Original_R_Line[100] - 5; j++)
    {
        if(mt9v03x_image[100][j] < threshould && mt9v03x_image[100][j + 1] < threshould)
        {
            if(mt9v03x_image[100][j + 2] > threshould && mt9v03x_image[100][j + 3] > threshould)
            {
                Count_1++;
            }
        }
    }
    Count_2 = 0;
    for(uint8 j = Original_L_Line[112] + 5; j < Original_R_Line[112] - 5; j++)
    {
        if(mt9v03x_image[112][j] < threshould && mt9v03x_image[112][j + 1] < threshould)
        {
            if(mt9v03x_image[112][j + 2] > threshould && mt9v03x_image[112][j + 3] > threshould)
            {
                Count_2++;
            }
        }
    }
    if(Count_1 >= 2 || Count_2 >= 2)
    {
        return 1;
    }
    if(Original_L_Line[0] == 255 || Original_R_Line[0] == 0)
    {
        return 0;
    }
    for(uint8 i = 80; i < MT9V03X_H; i+=2)
    {
        uint8 Count = 0;
        for(uint8 j = Original_L_Line[i] + 5; j < Original_R_Line[i] - 5; j++)
        {
            if(mt9v03x_image[i][j] < threshould && mt9v03x_image[i][j + 1] < threshould)
            {
                if(mt9v03x_image[i][j + 2] > threshould && mt9v03x_image[i][j + 3] > threshould)
                {
                    Count++;
                    if(Count >= 2)
                    {
                        return 1;
                    }
                }
            }
        }
    }
    return 0;
}

uint8 Cross_Recognition_Optimization_Success(void)
{
    Temp_L_L_CROS = 0;
    Temp_L_R_CROS = 0;
    Temp_R_L_CROS = 0;
    Temp_R_R_CROS = 0;
    for(uint8 i = Equivalent_Corner_Point_L_R[0]; i < 100; i++)
    {
        if(Original_L_Line[i] == 0 || Original_L_Line[i] == 255)
        {
            continue;
        }
        if(Original_L_Line[i] - Original_L_Line[i + 1] > 0)
        {
            Temp_L_R_CROS += Original_L_Line[i] - Original_L_Line[i + 1];
        }else
        {
            Temp_L_L_CROS += Original_L_Line[i] - Original_L_Line[i + 1];
        }
    }
    for(uint8 i = Equivalent_Corner_Point_L_R[2]; i < 100; i++)
    {
        if(Original_R_Line[i] == MT9V03X_W - 1 || Original_R_Line[i] == 0)
        {
            continue;
        }
        if(Original_R_Line[i] - Original_R_Line[i + 1] > 0)
        {
            Temp_R_R_CROS += Original_R_Line[i] - Original_R_Line[i + 1];
        }else
        {
            Temp_R_L_CROS += Original_R_Line[i] - Original_R_Line[i + 1];
        }
    }
    if(Temp_L_L_CROS > -5 && Temp_L_R_CROS < 60 && Temp_R_L_CROS > -60 && Temp_R_R_CROS < 5)
    {
        return 1;
    }
    return 0;
}

uint8 R_Break_Two_CROS(void)
{
    int Temp_L_L = 0, Temp_L_R = 0;
    for(uint8 i = Equivalent_Corner_Point_L_R[2]; i < 100; i++)
    {
        if(Original_L_Line[i] == 0 || Original_L_Line[i] == 255)
        {
            continue;
        }
        if(Original_L_Line[i] - Original_L_Line[i + 1] > 0)
        {
            Temp_L_R += Original_L_Line[i] - Original_L_Line[i + 1];
        }else
        {
            Temp_L_L += Original_L_Line[i] - Original_L_Line[i + 1];
        }
    }
    int Temp_R_L = 0, Temp_R_R = 0;
    for(uint8 i = Equivalent_Corner_Point_L_R[2]; i < 100; i++)
    {
        if(Original_R_Line[i] == MT9V03X_W - 1 || Original_R_Line[i] == 0)
        {
            continue;
        }
        if(Original_R_Line[i] - Original_R_Line[i + 1] > 0)
        {
            Temp_R_R += Original_R_Line[i] - Original_R_Line[i + 1];
        }else
        {
            Temp_R_L += Original_R_Line[i] - Original_R_Line[i + 1];
        }
    }
    if(Temp_L_L > -5 && Temp_L_R < 60 && Temp_R_L > -60 && Temp_R_R < 5)
    {
        return 1;
    }
    return 0;
}

uint8 L_Break_Two_CROS(void)
{
    int Temp_L_L = 0, Temp_L_R = 0;
    for(uint8 i = Equivalent_Corner_Point_L_R[0]; i < 100; i++)
    {
        if(Original_L_Line[i] == 0 || Original_L_Line[i] == 255)
        {
            continue;
        }
        if(Original_L_Line[i] - Original_L_Line[i + 1] > 0)
        {
            Temp_L_R += Original_L_Line[i] - Original_L_Line[i + 1];
        }else
        {
            Temp_L_L += Original_L_Line[i] - Original_L_Line[i + 1];
        }
    }
    int Temp_R_L = 0, Temp_R_R = 0;
    for(uint8 i = Equivalent_Corner_Point_L_R[0]; i < 100; i++)
    {
        if(Original_R_Line[i] == MT9V03X_W - 1 || Original_R_Line[i] == 0)
        {
            continue;
        }
        if(Original_R_Line[i] - Original_R_Line[i + 1] > 0)
        {
            Temp_R_R += Original_R_Line[i] - Original_R_Line[i + 1];
        }else
        {
            Temp_R_L += Original_R_Line[i] - Original_R_Line[i + 1];
        }
    }
    if(Temp_L_L > -5 && Temp_L_R < 60 && Temp_R_L > -60 && Temp_R_R < 5)
    {
        return 1;
    }
    return 0;
}

uint8 Upper_Lost_Line(void)
{
    return 0;
}

uint8 Start_Avoid_Obstacles(void)
{
    int temp_Max = 0, temp_Upper_Max = 0;
    uint8 Position = 0;
    for(uint8 i = MT9V03X_H - 1; i > 40; i--)
    {
        int temp = 0;
        for(uint8 j = 0; j < 10; j++)
        {
            temp += Midcourt_Line[i - j] - Midcourt_Line[i - 1 - j];
        }
        if(abs(temp_Max) - abs(temp) < 0)
        {
            Position = i;
            temp_Max = temp;
        }
    }
    AO_Count_Uppre = 0;
    if(abs(temp_Max) > 10)
    {
        for(uint8 i = Position - 30; i > 20; i--)
        {
            int temp_Upper = 0;
            for(uint8 j = 0; j < 10; j++)
            {
                temp_Upper += Midcourt_Line[i - j] - Midcourt_Line[i - 1 - j];
            }
            if(abs(temp_Upper_Max) - abs(temp_Upper) < 0)
            {
                temp_Upper_Max = temp_Upper;
            }
        }
        AO_Count_Uppre = temp_Upper_Max;
    }
    AO_Count = temp_Max;
    return 0;
}

uint8 S_Bend_Recognition_Optimization(void)
{
    uint8 temp = 0;
    uint8 temp_r = 0;
    for(uint8 i = 0; i < 10; i++)
    {
        Stockpile[i] = 0;
    }
    int point = 0;
    uint8 temp_previous = 0;
    for(uint8 i = 5; i < MT9V03X_H - 5; i++)
    {
        if(Original_L_Line[i] == 0 || Original_L_Line[i] == 255)
        {
            continue;
        }
        if(Original_L_Line[i] - Original_L_Line[i + 1] == 0)
        {
            continue;
        }
        if(temp_previous == 0)
        {
            temp_previous = Original_L_Line[i] - Original_L_Line[i + 1] > 0 ? 1 : 2;
        }
        Stockpile[point++ % 10] = Original_L_Line[i] - Original_L_Line[i + 1] > 0 ? 1 : 2;
        uint8 temp_1 = 0, temp_2 = 0;
        for(uint8 i = 0; i < 10; i++)
        {
            if(Stockpile[i] == 1)
            {
                temp_1++;
            }else if(Stockpile[i] == 2)
            {
                temp_2++;
            }
        }
        if(temp_1 >= 6 && temp_previous == 2)
        {
            temp++;
            temp_previous = 1;
        }else if(temp_2 >= 6 && temp_previous == 1)
        {
            temp++;
            temp_previous = 2;
        }
    }
    for(uint8 i = 0; i < 10; i++)
    {
        Stockpile[i] = 0;
    }
    point = 0;
    temp_previous = 0;
    for(uint8 i = 5; i < MT9V03X_H - 5; i++)
    {
        if(Original_R_Line[i] == MT9V03X_W - 1 || Original_R_Line[i] == 0)
        {
            continue;
        }
        if(Original_R_Line[i] - Original_R_Line[i + 1] == 0)
        {
            continue;
        }
        if(temp_previous == 0)
        {
            temp_previous = Original_R_Line[i] - Original_R_Line[i + 1] > 0 ? 1 : 2;
        }
        Stockpile[point++ % 10] = Original_R_Line[i] - Original_R_Line[i + 1] > 0 ? 1 : 2;
        uint8 temp_1 = 0, temp_2 = 0;
        for(uint8 i = 0; i < 10; i++)
        {
            if(Stockpile[i] == 1)
            {
                temp_1++;
            }else if(Stockpile[i] == 2)
            {
                temp_2++;
            }
        }
        if(temp_1 >= 6 && temp_previous == 2)
        {
            temp_r++;
            temp_previous = 1;
        }else if(temp_2 >= 6 && temp_previous == 1)
        {
            temp_r++;
            temp_previous = 2;
        }
    }
    S_Bend_Left = temp;
    S_Bend_Right = temp_r;
    return 0;
}

uint8 Avoid_Obstacles_Left_Pro(void)
{
    for(uint8 i = 0; i < MT9V03X_H - 6; i++)
    {
        if(Original_L_Line[i] - Original_L_Line[i + 1] == 0 &&
                Original_L_Line[i] - Original_L_Line[i + 2] == 0 &&
                Original_L_Line[i] - Original_L_Line[i + 3] <= 1 &&
                Original_L_Line[i] - Original_L_Line[i + 4] <= 1 &&
                Original_L_Line[i] - Original_L_Line[i + 5] <= 1)
        {
            return 1;
        }
    }
    return 0;
}

uint8 Avoid_Obstacles_Right_Pro(void)
{
    for(uint8 i = 0; i < MT9V03X_H - 6; i++)
    {
        if(Original_R_Line[i] - Original_R_Line[i + 1] == 0 &&
                Original_R_Line[i] - Original_R_Line[i + 2] == 0 &&
                Original_R_Line[i] - Original_R_Line[i + 3] >= -1 &&
                Original_R_Line[i] - Original_R_Line[i + 4] >= -1 &&
                Original_R_Line[i] - Original_R_Line[i + 5] >= -1)
        {
            return 1;
        }
    }
    return 0;
}

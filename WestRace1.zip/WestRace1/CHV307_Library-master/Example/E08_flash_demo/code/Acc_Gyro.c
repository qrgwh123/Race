/*
 * Acc_Gyro.c
 *
 *  Created on: Apr 8, 2024
 *      Author: guo
 */

#include "zf_common_headfile.h"
#include "PID.h"

float Gyro_Z;

void Acc_Gyro_Init(void)
{
    mpu6050_init();
}

void Acc_Gyro_Gain(void)
{
    mpu6050_get_gyro();
    Gyro_Z = mpu6050_gyro_transition(mpu6050_gyro_z) * 2;
}




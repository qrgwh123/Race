/*
 * Motor.h
 *
 *  Created on: Apr 1, 2024
 *      Author: guo
 */

#ifndef MOTOR_H_
#define MOTOR_H_

extern int Test_L_R, Test_B_L, Test_B_R;
extern int Test_N_L, Test_N_R;

void Motor_Init(void);
void Motor_Control(void);
void Motor_Start_Protect(void);
void Motor_Test_Control(void);

#endif /* MOTOR_H_ */

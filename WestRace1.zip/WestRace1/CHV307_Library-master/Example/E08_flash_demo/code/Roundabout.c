/*
 * Roundabout.c
 *
 *  Created on: May 11, 2024
 *      Author: guo
 */

#include "zf_common_headfile.h"
#include "Camera.h"

double Roundabout_Left_K = -1.6, Roundabout_Left_B = 20;
double Roundabout_Right_K = 1.8, Roundabout_Right_B = -40;

uint8 Roundabout_Corner_Point_Left[10];
uint8 Roundabout_Corner_Point_Right[10];

uint8 Roundabout_Border[188];
uint8 Roundabout_Corner = 100;

uint8 Temp_Corner = 100;
uint8 Temp_Value = 0;

uint8 Temp_Corner_Left = 88;
uint8 Temp_Value_Left = 0;

void Roundabout_Loop_Entry_Adding_Line_Right(void)
{
    for(uint8 i = 0; i < 10; i++)
    {
        Roundabout_Corner_Point_Right[i] = 255;
    }

    uint8 Count = 0;
    for(uint8 i = MT9V03X_H - 3; i >= 10; i--)
    {
        if(Count >= 10)
        {
            break;
        }
        if(Original_R_Line[i] == MT9V03X_W - 1)
        {
            break;
        }
        if(Original_R_Line[i] == 0 || Original_R_Line[i] == MT9V03X_W - 1)
        {
            continue;
        }
        if(Original_R_Line[i] - Original_R_Line[i + 1] <= 0
                && Original_R_Line[i] - Original_R_Line[i + 1] >= -1
                && Original_R_Line[i] - Original_R_Line[i + 2] <= 0
                && Original_R_Line[i] - Original_R_Line[i + 2] >= -2
                && Original_R_Line[i - 1] - Original_R_Line[i] <= 0
                && Original_R_Line[i - 1] - Original_R_Line[i] >= -1
                && Original_R_Line[i - 2] - Original_R_Line[i] <= 0
                && Original_R_Line[i - 2] - Original_R_Line[i] >= -2)
        {
            Roundabout_Corner_Point_Right[Count++] = i;
        }
    }

    double Sum_X = 0, Sum_Y = 0, Sum_X_Y = 0, Sum_X_X = 0;

    double Right_K = Roundabout_Right_B, Right_B = Roundabout_Right_B;

    Count = 10;

    if(Roundabout_Corner_Point_Right[9] == 255)
    {
        goto out;
    }

    for(uint8 i = 0; i < Count; i++)
    {
        Sum_X += Original_R_Line[Roundabout_Corner_Point_Right[i]];
        Sum_Y += Roundabout_Corner_Point_Right[i];
        Sum_X_X += Original_R_Line[Roundabout_Corner_Point_Right[i]] * Original_R_Line[Roundabout_Corner_Point_Right[i]];
        Sum_X_Y += Original_R_Line[Roundabout_Corner_Point_Right[i]] * Roundabout_Corner_Point_Right[i];
    }

    uint8 N = Count;

    if((N * Sum_X_X - Sum_X * Sum_X) && N)
    {
        Roundabout_Right_K = (N * Sum_X_Y - Sum_X * Sum_Y) / (N * Sum_X_X - Sum_X * Sum_X);
        Roundabout_Right_B = (Sum_Y - (Roundabout_Right_K) * Sum_X) / N;
    }

    if(Roundabout_Right_K < 0 || Roundabout_Right_B > 0)
    {
        Roundabout_Right_K = Right_K;
        Roundabout_Right_B = Right_B;
    }

    out:

    if(Roundabout_Right_K == 0)
    {
        double Temp = 0;
        for(uint8 i = 0; i < 10; i++)
        {
            Temp += Original_R_Line[Roundabout_Corner_Point_Right[i]];
        }
        Temp /= 10;
        for(uint8 i = 10; i < MT9V03X_H; i++)
        {
            Final_R_Line[i] = Temp;
        }
    }else
    {
        for(uint8 i = 10; i < MT9V03X_H; i++)
        {
            Final_R_Line[i] = (i - Roundabout_Right_B) / Roundabout_Right_K;
            if(Final_R_Line[i] < 0)
            {
                Final_R_Line[i] = 0;
            }else if(Final_R_Line[i] > MT9V03X_W - 1)
            {
                Final_R_Line[i] = MT9V03X_W - 1;
            }
        }
    }

    for(int i = 10; i < MT9V03X_H; i++)
    {
        if((Final_R_Line[i] - 1) >= 0 && (Final_R_Line[i] - 1) < MT9V03X_W)
        {
            ips114_draw_point(Final_R_Line[i], i, RGB565_GREEN);
            ips114_draw_point(Final_R_Line[i] - 1, i, RGB565_GREEN);
        }
    }

}

void Roundabout_Loop_Entry_Bracing_Wire_Right(void)
{
    for(uint8 j = 0; j < MT9V03X_W; j++)
    {
        for(uint8 i = MT9V03X_H; i > 0; i--)
        {
            if(mt9v03x_image[i - 1][j] < threshould)
            {
                Roundabout_Border[j] = i;
                if(i == MT9V03X_H)
                {
                    Roundabout_Border[j] = 255;
                }
                break;
            }
        }
    }

    for(uint8 j = 10; j < MT9V03X_W - 10; j++)
    {
        if(Roundabout_Border[j] == 255 || Roundabout_Border[j] == 0)
        {
            continue;
        }
        if(Roundabout_Border[j] - Roundabout_Border[j - 1] >= 0 &&
                Roundabout_Border[j] - Roundabout_Border[j - 2] >= 1 &&
                Roundabout_Border[j] - Roundabout_Border[j - 3] >= 2 &&
                Roundabout_Border[j] - Roundabout_Border[j - 4] >= 3 &&
                Roundabout_Border[j] - Roundabout_Border[j - 5] >= 4 &&
                Roundabout_Border[j] - Roundabout_Border[j - 6] >= 5 &&
                Roundabout_Border[j] - Roundabout_Border[j - 7] >= 6 &&
                Roundabout_Border[j] - Roundabout_Border[j - 8] >= 7)
        {
            if(Roundabout_Border[j] - Roundabout_Border[j + 1] >= 0 &&
                Roundabout_Border[j] - Roundabout_Border[j + 2] >= 1 &&
                Roundabout_Border[j] - Roundabout_Border[j + 3] >= 2 &&
                Roundabout_Border[j] - Roundabout_Border[j + 4] >= 3 &&
                Roundabout_Border[j] - Roundabout_Border[j + 5] >= 4 &&
                Roundabout_Border[j] - Roundabout_Border[j + 6] >= 5 &&
                Roundabout_Border[j] - Roundabout_Border[j + 7] >= 6 &&
                Roundabout_Border[j] - Roundabout_Border[j + 8] >= 7)
            {
                Roundabout_Corner = j;
                break;
            }else if(abs(Roundabout_Border[j] - Roundabout_Border[j + 1]) <= 3 &&
                abs(Roundabout_Border[j] - Roundabout_Border[j + 2]) <= 3 &&
                abs(Roundabout_Border[j] - Roundabout_Border[j + 3]) <= 3 &&
                abs(Roundabout_Border[j] - Roundabout_Border[j + 4]) <= 3 &&
                abs(Roundabout_Border[j] - Roundabout_Border[j + 5]) <= 3 &&
                abs(Roundabout_Border[j] - Roundabout_Border[j + 6]) <= 3 &&
                abs(Roundabout_Border[j] - Roundabout_Border[j + 7]) <= 3 &&
                abs(Roundabout_Border[j] - Roundabout_Border[j + 8]) <= 3)
            {
                Roundabout_Corner = j;
                break;
            }
        }
    }

    if(Roundabout_Border[Roundabout_Corner] > Temp_Value)
    {
        Temp_Corner = Roundabout_Corner;
        Temp_Value = Roundabout_Border[Roundabout_Corner];
    }

    for(uint8 i = 20; i < 150; i++)
    {
        if(Temp_Value <  MT9V03X_H)
        {
            ips114_draw_point(i, Temp_Value, RGB565_RED);
        }
    }

    for(uint8 i = 0; i < 100; i++)
    {
        if(Temp_Corner >= 0 && Temp_Corner < MT9V03X_W)
        {
            ips114_draw_point(Temp_Corner, i, RGB565_RED);
        }
    }

    double Sum_X = 0, Sum_Y = 0, Sum_X_Y = 0, Sum_X_X = 0;

    //double Right_K = Roundabout_Right_K, Right_B = Roundabout_Right_B;

    Sum_X += Temp_Corner;
    Sum_Y += Temp_Value;
    Sum_X_X += Temp_Corner * Temp_Corner;
    Sum_X_Y += Temp_Corner * Temp_Value;

    Sum_X += 0;
    Sum_Y += 119;
    Sum_X_X += 0 * 0;
    Sum_X_Y += 0 * 119;

    uint8 N = 2;

    if((N * Sum_X_X - Sum_X * Sum_X) && N)
    {
        Roundabout_Right_K = (N * Sum_X_Y - Sum_X * Sum_Y) / (N * Sum_X_X - Sum_X * Sum_X);
        Roundabout_Right_B = (Sum_Y - (Roundabout_Right_K) * Sum_X) / N;
    }

    for(uint8 i = 10; i < MT9V03X_H; i++)
    {
        Final_L_Line[i] = (i - Roundabout_Right_B) / Roundabout_Right_K;
        if(Final_L_Line[i] < 0)
        {
            Final_L_Line[i] = 0;
        }else if(Final_L_Line[i] > MT9V03X_W - 1)
        {
            Final_L_Line[i] = MT9V03X_W - 1;
        }
    }

    for(int i = 10; i < MT9V03X_H; i++)
    {
        if((Final_L_Line[i] - 1) >= 0 && Final_L_Line[i] < MT9V03X_W)
        {
            ips114_draw_point(Final_L_Line[i], i, RGB565_RED);
            ips114_draw_point(Final_L_Line[i] - 1, i, RGB565_RED);
        }
    }
}

void Roundabout_Out_Of_The_Virtual_Loop_Bracing_Wire_Right(void)
{
    uint8 Temp_Corner = Roundabout_Corner;
    Roundabout_Corner = 255;
    for(uint8 i = MT9V03X_H - 20; i >= 20; i--)
    {
        if(Original_L_Line[i] == 0 || Original_L_Line[i] == 255)
        {
            continue;
        }
        if(Original_L_Line[i] - Original_L_Line[i + 1] >= 0
                && Original_L_Line[i] - Original_L_Line[i + 2] >= 0
                && Original_L_Line[i] - Original_L_Line[i + 3] >= 0
                && Original_L_Line[i] - Original_L_Line[i + 4] >= 0
                && Original_L_Line[i] - Original_L_Line[i - 1] >= 0
                && Original_L_Line[i] - Original_L_Line[i - 2] >= 0
                && Original_L_Line[i] - Original_L_Line[i - 3] >= 0
                && Original_L_Line[i] - Original_L_Line[i - 4] >= 0)
        {
            Roundabout_Corner = i;
            break;
        }
    }

    if(Roundabout_Corner == 255)
    {
        Roundabout_Corner = Temp_Corner;
    }

    for(uint8 i = 20; i < 150; i++)
    {
        if(Roundabout_Corner <  MT9V03X_W)
        {
            ips114_draw_point(i, Roundabout_Corner, RGB565_RED);
        }
    }

    for(uint8 i = 0; i < 100; i++)
    {
        if(Original_L_Line[Roundabout_Corner] >= 0 && Original_L_Line[Roundabout_Corner] < MT9V03X_W)
        {
            ips114_draw_point(Original_L_Line[Roundabout_Corner], i, RGB565_RED);
        }
    }

    double Sum_X = 0, Sum_Y = 0, Sum_X_Y = 0, Sum_X_X = 0;

    //double Right_K = Roundabout_Right_K, Right_B = Roundabout_Right_B;

    Sum_X += Original_L_Line[Roundabout_Corner];
    Sum_Y += Roundabout_Corner;
    Sum_X_X += Original_L_Line[Roundabout_Corner] * Original_L_Line[Roundabout_Corner];
    Sum_X_Y += Roundabout_Corner * Original_L_Line[Roundabout_Corner];

    Sum_X += 187;
    Sum_Y += 0;
    Sum_X_X += 187 * 187;
    Sum_X_Y += 187 * 0;

    uint8 N = 2;

    if((N * Sum_X_X - Sum_X * Sum_X) && N)
    {
        Roundabout_Right_K = (N * Sum_X_Y - Sum_X * Sum_Y) / (N * Sum_X_X - Sum_X * Sum_X);
        Roundabout_Right_B = (Sum_Y - (Roundabout_Right_K) * Sum_X) / N;
    }

    for(uint8 i = 10; i < MT9V03X_H; i++)
    {
        Final_L_Line[i] = (i - Roundabout_Right_B) / Roundabout_Right_K;
        if(Final_L_Line[i] < 0)
        {
            Final_L_Line[i] = 0;
        }else if(Final_L_Line[i] > MT9V03X_W - 1)
        {
            Final_L_Line[i] = MT9V03X_W - 1;
        }
    }

    for(int i = 10; i < MT9V03X_H; i++)
    {
        if((Final_L_Line[i] - 1) >= 0 && Final_L_Line[i] < MT9V03X_W)
        {
            ips114_draw_point(Final_L_Line[i], i, RGB565_RED);
            ips114_draw_point(Final_L_Line[i] - 1, i, RGB565_RED);
        }
    }

}

void Roundabout_Out_Of_The_Loop_Adding_Line_Right(void)
{
    for(uint8 i = 0; i < 10; i++)
    {
        Roundabout_Corner_Point_Right[i] = 255;
    }

    uint8 Count = 0;
    for(uint8 i = 5; i <= MT9V03X_H - 5; i++)
    {
        if(Count >= 10)
        {
            break;
        }
        if(Original_R_Line[i] == 0 || Original_R_Line[i] == MT9V03X_W - 1)
        {
            continue;
        }
        if(Original_R_Line[i] - Original_R_Line[i + 1] <= 0
                && Original_R_Line[i] - Original_R_Line[i + 1] >= -1
                && Original_R_Line[i] - Original_R_Line[i + 2] <= 0
                && Original_R_Line[i] - Original_R_Line[i + 2] >= -2
                && Original_R_Line[i - 1] - Original_R_Line[i] <= 0
                && Original_R_Line[i - 1] - Original_R_Line[i] >= -1
                && Original_R_Line[i - 2] - Original_R_Line[i] <= 0
                && Original_R_Line[i - 2] - Original_R_Line[i] >= -2)
        {
            Roundabout_Corner_Point_Right[Count++] = i;
        }
    }

    double Sum_X = 0, Sum_Y = 0, Sum_X_Y = 0, Sum_X_X = 0;

    double Right_K = Roundabout_Right_B, Right_B = Roundabout_Right_B;

    Count = 10;

    if(Roundabout_Corner_Point_Right[9] == 255)
    {
        goto out;
    }

    for(uint8 i = 0; i < Count; i++)
    {
        Sum_X += Original_R_Line[Roundabout_Corner_Point_Right[i]];
        Sum_Y += Roundabout_Corner_Point_Right[i];
        Sum_X_X += Original_R_Line[Roundabout_Corner_Point_Right[i]] * Original_R_Line[Roundabout_Corner_Point_Right[i]];
        Sum_X_Y += Original_R_Line[Roundabout_Corner_Point_Right[i]] * Roundabout_Corner_Point_Right[i];
    }

    uint8 N = Count;

    if((N * Sum_X_X - Sum_X * Sum_X) && N)
    {
        Roundabout_Right_K = (N * Sum_X_Y - Sum_X * Sum_Y) / (N * Sum_X_X - Sum_X * Sum_X);
        Roundabout_Right_B = (Sum_Y - (Roundabout_Right_K) * Sum_X) / N;
    }

    if(Roundabout_Right_K < 0 || Roundabout_Right_B > 0)
    {
        Roundabout_Right_K = Right_K;
        Roundabout_Right_B = Right_B;
    }

    out:

    if(R_Far_Lost >= 20)
    {
        for(uint8 i = 10; i < MT9V03X_H; i++)
        {
            Final_R_Line[i] = MT9V03X_W - 1;
        }
    }else if(Roundabout_Right_K == 0)
    {
        double Temp = 0;
        for(uint8 i = 0; i < 10; i++)
        {
            Temp += Original_R_Line[Roundabout_Corner_Point_Right[i]];
        }
        Temp /= 10;
        for(uint8 i = 10; i < MT9V03X_H; i++)
        {
            Final_R_Line[i] = Temp;
        }
    }else
    {
        for(uint8 i = 10; i < MT9V03X_H; i++)
        {
            Final_R_Line[i] = (i - Roundabout_Right_B) / Roundabout_Right_K;
            if(Final_R_Line[i] < 0)
            {
                Final_R_Line[i] = 0;
            }else if(Final_R_Line[i] > MT9V03X_W - 1)
            {
                Final_R_Line[i] = MT9V03X_W - 1;
            }
        }
    }

    for(int i = 10; i < MT9V03X_H; i++)
    {
        if((Final_R_Line[i] - 1) >= 0 && (Final_R_Line[i] - 1) < MT9V03X_W)
        {
            ips114_draw_point(Final_R_Line[i], i, RGB565_GREEN);
            ips114_draw_point(Final_R_Line[i] - 1, i, RGB565_GREEN);
        }
    }

}

void Roundabout_Loop_Entry_Adding_Line_Left(void)
{
    uint8 Keep_Flag = 0;
    for(uint8 i = 0; i < 10; i++)
    {
        Roundabout_Corner_Point_Left[i] = 255;
    }

    uint8 Count = 0;
    for(uint8 i = MT9V03X_H - 3; i >= 10; i--)
    {
        if(Count >= 10)
        {
            break;
        }
        if(Original_L_Line[i] == 0)
        {
            break;
        }
        if(Original_L_Line[i] == 255 || Original_L_Line[i] == 0)
        {
            continue;
        }
        if(Original_L_Line[i] - Original_L_Line[i + 1] >= 0
                && Original_L_Line[i] - Original_L_Line[i + 1] <= 1
                && Original_L_Line[i] - Original_L_Line[i + 2] >= 0
                && Original_L_Line[i] - Original_L_Line[i + 2] <= 2
                && Original_L_Line[i] - Original_L_Line[i - 1] >= -1
                && Original_L_Line[i] - Original_L_Line[i - 1] <= 0
                && Original_L_Line[i] - Original_L_Line[i - 2] >= -2
                && Original_L_Line[i] - Original_L_Line[i - 2] <= 0)
        {
            Roundabout_Corner_Point_Left[Count++] = i;
        }
    }

    double Sum_X = 0, Sum_Y = 0, Sum_X_Y = 0, Sum_X_X = 0;

    double Left_K = Roundabout_Left_K, Left_B = Roundabout_Left_B;

    Count = 10;

    if(Roundabout_Corner_Point_Left[9] == 255)
    {
        Keep_Flag = 1;
    }

    if(Keep_Flag == 0)
    {
        for(uint8 i = 0; i < Count; i++)
        {
            Sum_X += Original_L_Line[Roundabout_Corner_Point_Left[i]];
            Sum_Y += Roundabout_Corner_Point_Left[i];
            Sum_X_X += Original_L_Line[Roundabout_Corner_Point_Left[i]] * Original_L_Line[Roundabout_Corner_Point_Left[i]];
            Sum_X_Y += Original_L_Line[Roundabout_Corner_Point_Left[i]] * Roundabout_Corner_Point_Left[i];

        }

        uint8 N = Count;

        if((N * Sum_X_X - Sum_X * Sum_X) && N)
        {
            Roundabout_Left_K = (N * Sum_X_Y - Sum_X * Sum_Y) / (N * Sum_X_X - Sum_X * Sum_X);
            Roundabout_Left_B = (Sum_Y - (Roundabout_Left_K) * Sum_X) / N;
        }

        if(Roundabout_Left_K > 0 || Roundabout_Left_B < 0)
        {
            Roundabout_Left_K = Left_K;
            Roundabout_Left_B = Left_B;
        }

    }

    if(Roundabout_Left_K == 0)
    {
        double Temp = 0;
        for(uint8 i = 0; i < 10; i++)
        {
            Temp += Original_L_Line[Roundabout_Corner_Point_Left[i]];
        }
        Temp /= 10;
        for(uint8 i = 10; i < MT9V03X_H; i++)
        {
            Final_L_Line[i] = Temp;
        }
    }else
    {
        for(uint8 i = 10; i < MT9V03X_H; i++)
        {
            Final_L_Line[i] = (i - Roundabout_Left_B) / Roundabout_Left_K;
            if(Final_L_Line[i] < 0)
            {
                Final_L_Line[i] = 0;
            }else if(Final_L_Line[i] > MT9V03X_W - 1)
            {
                Final_L_Line[i] = MT9V03X_W - 1;
            }
        }
    }

    for(int i = 10; i < MT9V03X_H; i++)
    {
        if((Final_L_Line[i] - 1) >= 0 && (Final_L_Line[i] - 1) < MT9V03X_W)
        {
            ips114_draw_point(Final_L_Line[i], i, RGB565_GREEN);
            ips114_draw_point(Final_L_Line[i] - 1, i, RGB565_GREEN);
        }
    }

}

void Roundabout_Loop_Entry_Bracing_Wire_Left(void)
{
    for(uint8 j = 0; j < MT9V03X_W; j++)
    {
        for(uint8 i = MT9V03X_H; i > 0; i--)
        {
            if(mt9v03x_image[i - 1][j] < threshould)
            {
                Roundabout_Border[j] = i;
                if(i == MT9V03X_H)
                {
                    Roundabout_Border[j] = 255;
                }
                break;
            }
        }
    }

    for(uint8 j = 10; j < MT9V03X_W - 10; j++)
    {
        if(Roundabout_Border[j] == 255 || Roundabout_Border[j] == 0)
        {
            continue;
        }
        if(Roundabout_Border[j] - Roundabout_Border[j + 1] >= 0 &&
                Roundabout_Border[j] - Roundabout_Border[j + 2] >= 1 &&
                Roundabout_Border[j] - Roundabout_Border[j + 3] >= 2 &&
                Roundabout_Border[j] - Roundabout_Border[j + 4] >= 3 &&
                Roundabout_Border[j] - Roundabout_Border[j + 5] >= 4 &&
                Roundabout_Border[j] - Roundabout_Border[j + 6] >= 5 &&
                Roundabout_Border[j] - Roundabout_Border[j + 7] >= 6 &&
                Roundabout_Border[j] - Roundabout_Border[j + 8] >= 7)
        {
            if(Roundabout_Border[j] - Roundabout_Border[j - 1] >= 0 &&
                Roundabout_Border[j] - Roundabout_Border[j - 2] >= 1 &&
                Roundabout_Border[j] - Roundabout_Border[j - 3] >= 2 &&
                Roundabout_Border[j] - Roundabout_Border[j - 4] >= 3 &&
                Roundabout_Border[j] - Roundabout_Border[j - 5] >= 4 &&
                Roundabout_Border[j] - Roundabout_Border[j - 6] >= 5 &&
                Roundabout_Border[j] - Roundabout_Border[j - 7] >= 6 &&
                Roundabout_Border[j] - Roundabout_Border[j - 8] >= 7)
            {
                Roundabout_Corner = j;
                break;
            }else if(abs(Roundabout_Border[j] - Roundabout_Border[j - 1]) <= 3 &&
                abs(Roundabout_Border[j] - Roundabout_Border[j - 2]) <= 3 &&
                abs(Roundabout_Border[j] - Roundabout_Border[j - 3]) <= 3 &&
                abs(Roundabout_Border[j] - Roundabout_Border[j - 4]) <= 3 &&
                abs(Roundabout_Border[j] - Roundabout_Border[j - 5]) <= 3 &&
                abs(Roundabout_Border[j] - Roundabout_Border[j - 6]) <= 3 &&
                abs(Roundabout_Border[j] - Roundabout_Border[j - 7]) <= 3 &&
                abs(Roundabout_Border[j] - Roundabout_Border[j - 8]) <= 3)
            {
                Roundabout_Corner = j;
                break;
            }
        }
    }

    if(Roundabout_Border[Roundabout_Corner] > Temp_Value_Left)
    {
        Temp_Corner_Left = Roundabout_Corner;
        Temp_Value_Left = Roundabout_Border[Roundabout_Corner];
    }

    for(uint8 i = 20; i < 150; i++)
    {
        if(Temp_Value_Left <  MT9V03X_H)
        {
            ips114_draw_point(i, Temp_Value_Left, RGB565_RED);
        }
    }

    for(uint8 i = 0; i < 100; i++)
    {
        if(Temp_Corner_Left >= 0 && Temp_Corner_Left < MT9V03X_W)
        {
            ips114_draw_point(Temp_Corner_Left, i, RGB565_RED);
        }
    }

    double Sum_X = 0, Sum_Y = 0, Sum_X_Y = 0, Sum_X_X = 0;

    //double Right_K = Roundabout_Right_K, Right_B = Roundabout_Right_B;

    Sum_X += Temp_Corner_Left;
    Sum_Y += Temp_Value_Left;
    Sum_X_X += Temp_Corner_Left * Temp_Corner_Left;
    Sum_X_Y += Temp_Corner_Left * Temp_Value_Left;

    Sum_X += 187;
    Sum_Y += 119;
    Sum_X_X += 187 * 187;
    Sum_X_Y += 187 * 119;

    uint8 N = 2;

    if((N * Sum_X_X - Sum_X * Sum_X) && N)
    {
        Roundabout_Left_K = (N * Sum_X_Y - Sum_X * Sum_Y) / (N * Sum_X_X - Sum_X * Sum_X);
        Roundabout_Left_B = (Sum_Y - (Roundabout_Left_K) * Sum_X) / N;
    }

    for(uint8 i = 10; i < MT9V03X_H; i++)
    {
        Final_R_Line[i] = (i - Roundabout_Left_B) / Roundabout_Left_K;
        if(Final_R_Line[i] < 0)
        {
            Final_R_Line[i] = 0;
        }else if(Final_R_Line[i] > MT9V03X_W - 1)
        {
            Final_R_Line[i] = MT9V03X_W - 1;
        }
    }

    for(int i = 10; i < MT9V03X_H; i++)
    {
        if((Final_R_Line[i] - 1) >= 0 && Final_R_Line[i] < MT9V03X_W)
        {
            ips114_draw_point(Final_R_Line[i], i, RGB565_RED);
            ips114_draw_point(Final_R_Line[i] - 1, i, RGB565_RED);
        }
    }
}

void Roundabout_Out_Of_The_Virtual_Loop_Bracing_Wire_Left(void)
{
    uint8 Temp_Corner = Roundabout_Corner;
    Roundabout_Corner = 255;
    for(uint8 i = MT9V03X_H - 20; i >= 20; i--)
    {
        if(Original_R_Line[i] == MT9V03X_W - 1 || Original_R_Line[i] == 0)
        {
            continue;
        }
        if(Original_R_Line[i] - Original_R_Line[i + 1] <= 0
                && Original_R_Line[i] - Original_R_Line[i + 2] <= 0
                && Original_R_Line[i] - Original_R_Line[i + 3] <= 0
                && Original_R_Line[i] - Original_R_Line[i + 4] <= 0
                && Original_R_Line[i] - Original_R_Line[i - 1] <= 0
                && Original_R_Line[i] - Original_R_Line[i - 2] <= 0
                && Original_R_Line[i] - Original_R_Line[i - 3] <= 0
                && Original_R_Line[i] - Original_R_Line[i - 4] <= 0)
        {
            Roundabout_Corner = i;
            break;
        }
    }

    if(Roundabout_Corner == 255)
    {
        Roundabout_Corner = Temp_Corner;
    }

    for(uint8 i = 20; i < 150; i++)
    {
        if(Roundabout_Corner <  MT9V03X_H)
        {
            ips114_draw_point(i, Roundabout_Corner, RGB565_RED);
        }
    }

    for(uint8 i = 0; i < 100; i++)
    {
        if(Original_R_Line[Roundabout_Corner] >= 0 && Original_R_Line[Roundabout_Corner] < MT9V03X_W)
        {
            ips114_draw_point(Original_R_Line[Roundabout_Corner], i, RGB565_RED);
        }
    }

    double Sum_X = 0, Sum_Y = 0, Sum_X_Y = 0, Sum_X_X = 0;

    //double Right_K = Roundabout_Right_K, Right_B = Roundabout_Right_B;

    Sum_X += Original_R_Line[Roundabout_Corner];
    Sum_Y += Roundabout_Corner;
    Sum_X_X += Original_R_Line[Roundabout_Corner] * Original_R_Line[Roundabout_Corner];
    Sum_X_Y += Roundabout_Corner * Original_R_Line[Roundabout_Corner];

    Sum_X += 0;
    Sum_Y += 0;
    Sum_X_X += 0 * 0;
    Sum_X_Y += 0 * 0;

    uint8 N = 2;

    if((N * Sum_X_X - Sum_X * Sum_X) && N)
    {
        Roundabout_Left_K = (N * Sum_X_Y - Sum_X * Sum_Y) / (N * Sum_X_X - Sum_X * Sum_X);
        Roundabout_Left_B = (Sum_Y - (Roundabout_Left_K) * Sum_X) / N;
    }

    for(uint8 i = 10; i < MT9V03X_H; i++)
    {
        Final_R_Line[i] = (i - Roundabout_Left_B) / Roundabout_Left_K;
        if(Final_R_Line[i] < 0)
        {
            Final_R_Line[i] = 0;
        }else if(Final_R_Line[i] > MT9V03X_W - 1)
        {
            Final_R_Line[i] = MT9V03X_W - 1;
        }
    }

    for(int i = 10; i < MT9V03X_H; i++)
    {
        if((Final_R_Line[i] - 1) >= 0 && Final_R_Line[i] < MT9V03X_W)
        {
            ips114_draw_point(Final_R_Line[i], i, RGB565_RED);
            ips114_draw_point(Final_R_Line[i] - 1, i, RGB565_RED);
        }
    }

}

void Roundabout_Out_Of_The_Loop_Adding_Line_Left(void)
{
    uint8 Keep_Flag = 0;
    for(uint8 i = 0; i < 10; i++)
    {
        Roundabout_Corner_Point_Left[i] = 255;
    }
    uint8 j;
    for(j = MT9V03X_H - 5; j >= 5; j--)
    {
        if(Original_L_Line[j] == 0)
        {
            break;
        }
    }
    uint8 Count = 0;
    for(uint8 i = j - 5; i >= 5; i--)
    {
        if(Count >= 10)
        {
            break;
        }
        if(Original_L_Line[i] == 255 || Original_L_Line[i] == 0)
        {
            continue;
        }
        if(Original_L_Line[i] - Original_L_Line[i + 1] >= 0
                && Original_L_Line[i] - Original_L_Line[i + 1] <= 1
                && Original_L_Line[i] - Original_L_Line[i + 2] >= 0
                && Original_L_Line[i] - Original_L_Line[i + 2] <= 2
                && Original_L_Line[i] - Original_L_Line[i - 1] >= -1
                && Original_L_Line[i] - Original_L_Line[i - 1] <= 0
                && Original_L_Line[i] - Original_L_Line[i - 2] >= -2
                && Original_L_Line[i] - Original_L_Line[i - 2] <= 0)
        {
            Roundabout_Corner_Point_Left[Count++] = i;
        }
    }

    double Sum_X = 0, Sum_Y = 0, Sum_X_Y = 0, Sum_X_X = 0;

    double Left_K = Roundabout_Left_K, Left_B = Roundabout_Left_B;

    Count = 10;

    if(Roundabout_Corner_Point_Left[9] == 255)
    {
        Keep_Flag = 1;
    }

    if(Keep_Flag == 0)
    {
        for(uint8 i = 0; i < Count; i++)
        {
            Sum_X += Original_L_Line[Roundabout_Corner_Point_Left[i]];
            Sum_Y += Roundabout_Corner_Point_Left[i];
            Sum_X_X += Original_L_Line[Roundabout_Corner_Point_Left[i]] * Original_L_Line[Roundabout_Corner_Point_Left[i]];
            Sum_X_Y += Original_L_Line[Roundabout_Corner_Point_Left[i]] * Roundabout_Corner_Point_Left[i];

        }

        uint8 N = Count;

        if((N * Sum_X_X - Sum_X * Sum_X) && N)
        {
            Roundabout_Left_K = (N * Sum_X_Y - Sum_X * Sum_Y) / (N * Sum_X_X - Sum_X * Sum_X);
            Roundabout_Left_B = (Sum_Y - (Roundabout_Left_K) * Sum_X) / N;
        }

        if(Roundabout_Left_K > 0 || Roundabout_Left_B < 0)
        {
            Roundabout_Left_K = Left_K;
            Roundabout_Left_B = Left_B;
        }

    }

    if(Keep_Flag == 1)
    {
        for(uint8 i = 10; i < MT9V03X_H; i++)
        {
            Final_L_Line[i] = 80;
        }
    }else if(Roundabout_Left_K == 0)
    {
        double Temp = 0;
        for(uint8 i = 0; i < 10; i++)
        {
            Temp += Original_L_Line[Roundabout_Corner_Point_Left[i]];
        }
        Temp /= 10;
        for(uint8 i = 10; i < MT9V03X_H; i++)
        {
            Final_L_Line[i] = Temp;
        }
    }else
    {
        int temp = 0;
        for(uint8 i = 10; i < MT9V03X_H; i++)
        {
            temp = (i - Roundabout_Left_B) / Roundabout_Left_K;
            if(temp < 0)
            {
                Final_L_Line[i] = 0;
            }else if(temp > MT9V03X_W - 1)
            {
                Final_L_Line[i] = MT9V03X_W - 1;
            }else
            {
                Final_L_Line[i] = temp;
            }
        }
    }

    for(int i = 10; i < MT9V03X_H; i++)
    {
        if((Final_L_Line[i] - 1) >= 0 && (Final_L_Line[i] - 1) < MT9V03X_W)
        {
            ips114_draw_point(Final_L_Line[i], i, RGB565_GREEN);
            ips114_draw_point(Final_L_Line[i] - 1, i, RGB565_GREEN);
        }
    }

}

uint8 Assist_Right_Roundabout_Zero_End(void)
{
    uint8 X,Y;
    for(uint8 j = 0; j < MT9V03X_W; j++)
    {
        for(uint8 i = MT9V03X_H; i > 0; i--)
        {
            if(mt9v03x_image[i - 1][j] < threshould)
            {
                Roundabout_Border[j] = i;
                if(i == MT9V03X_H)
                {
                    Roundabout_Border[j] = 255;
                }
                break;
            }
        }
    }

    for(uint8 j = 10; j < MT9V03X_W - 10; j++)
    {
        if(Roundabout_Border[j] == 255 || Roundabout_Border[j] == 0)
        {
            continue;
        }
        if(Roundabout_Border[j] - Roundabout_Border[j - 1] >= 0 &&
                Roundabout_Border[j] - Roundabout_Border[j - 2] >= 1 &&
                Roundabout_Border[j] - Roundabout_Border[j - 3] >= 2 &&
                Roundabout_Border[j] - Roundabout_Border[j - 4] >= 3 &&
                Roundabout_Border[j] - Roundabout_Border[j - 5] >= 4 &&
                Roundabout_Border[j] - Roundabout_Border[j - 6] >= 5 &&
                Roundabout_Border[j] - Roundabout_Border[j - 7] >= 6 &&
                Roundabout_Border[j] - Roundabout_Border[j - 8] >= 7)
        {
            if(Roundabout_Border[j] - Roundabout_Border[j + 1] >= 0 &&
                Roundabout_Border[j] - Roundabout_Border[j + 2] >= 1 &&
                Roundabout_Border[j] - Roundabout_Border[j + 3] >= 2 &&
                Roundabout_Border[j] - Roundabout_Border[j + 4] >= 3 &&
                Roundabout_Border[j] - Roundabout_Border[j + 5] >= 4 &&
                Roundabout_Border[j] - Roundabout_Border[j + 6] >= 5 &&
                Roundabout_Border[j] - Roundabout_Border[j + 7] >= 6 &&
                Roundabout_Border[j] - Roundabout_Border[j + 8] >= 7)
            {
                X = j;
                break;
            }else if(abs(Roundabout_Border[j] - Roundabout_Border[j + 1]) <= 3 &&
                abs(Roundabout_Border[j] - Roundabout_Border[j + 2]) <= 3 &&
                abs(Roundabout_Border[j] - Roundabout_Border[j + 3]) <= 3 &&
                abs(Roundabout_Border[j] - Roundabout_Border[j + 4]) <= 3 &&
                abs(Roundabout_Border[j] - Roundabout_Border[j + 5]) <= 3 &&
                abs(Roundabout_Border[j] - Roundabout_Border[j + 6]) <= 3 &&
                abs(Roundabout_Border[j] - Roundabout_Border[j + 7]) <= 3 &&
                abs(Roundabout_Border[j] - Roundabout_Border[j + 8]) <= 3)
            {
                X = j;
                break;
            }
        }
    }
    Y = Roundabout_Border[X];
    uint8 i = Y, j = X;
    if(i > MT9V03X_H - 40 && j < 40)
    {
        return 1;
    }
    return 0;
}

uint8 Assist_Left_Roundabout_Zero_End(void)
{
    uint8 X,Y;
    for(uint8 j = 0; j < MT9V03X_W; j++)
    {
        for(uint8 i = MT9V03X_H; i > 0; i--)
        {
            if(mt9v03x_image[i - 1][j] < threshould)
            {
                Roundabout_Border[j] = i;
                if(i == MT9V03X_H)
                {
                    Roundabout_Border[j] = 255;
                }
                break;
            }
        }
    }

    for(uint8 j = 10; j < MT9V03X_W - 10; j++)
    {
        if(Roundabout_Border[j] == 255 || Roundabout_Border[j] == 0)
        {
            continue;
        }
        if(Roundabout_Border[j] - Roundabout_Border[j + 1] >= 0 &&
                Roundabout_Border[j] - Roundabout_Border[j + 2] >= 1 &&
                Roundabout_Border[j] - Roundabout_Border[j + 3] >= 2 &&
                Roundabout_Border[j] - Roundabout_Border[j + 4] >= 3 &&
                Roundabout_Border[j] - Roundabout_Border[j + 5] >= 4 &&
                Roundabout_Border[j] - Roundabout_Border[j + 6] >= 5 &&
                Roundabout_Border[j] - Roundabout_Border[j + 7] >= 6 &&
                Roundabout_Border[j] - Roundabout_Border[j + 8] >= 7)
        {
            if(Roundabout_Border[j] - Roundabout_Border[j - 1] >= 0 &&
                Roundabout_Border[j] - Roundabout_Border[j - 2] >= 1 &&
                Roundabout_Border[j] - Roundabout_Border[j - 3] >= 2 &&
                Roundabout_Border[j] - Roundabout_Border[j - 4] >= 3 &&
                Roundabout_Border[j] - Roundabout_Border[j - 5] >= 4 &&
                Roundabout_Border[j] - Roundabout_Border[j - 6] >= 5 &&
                Roundabout_Border[j] - Roundabout_Border[j - 7] >= 6 &&
                Roundabout_Border[j] - Roundabout_Border[j - 8] >= 7)
            {
                X = j;
                break;
            }else if(abs(Roundabout_Border[j] - Roundabout_Border[j - 1]) <= 3 &&
                abs(Roundabout_Border[j] - Roundabout_Border[j - 2]) <= 3 &&
                abs(Roundabout_Border[j] - Roundabout_Border[j - 3]) <= 3 &&
                abs(Roundabout_Border[j] - Roundabout_Border[j - 4]) <= 3 &&
                abs(Roundabout_Border[j] - Roundabout_Border[j - 5]) <= 3 &&
                abs(Roundabout_Border[j] - Roundabout_Border[j - 6]) <= 3 &&
                abs(Roundabout_Border[j] - Roundabout_Border[j - 7]) <= 3 &&
                abs(Roundabout_Border[j] - Roundabout_Border[j - 8]) <= 3)
            {
                X = j;
                break;
            }
        }
    }
    Y = Roundabout_Border[X];
    uint8 i = Y, j = X;
    if(i >= MT9V03X_H - 60 && j >= MT9V03X_W - 70)
    {
        return 1;
    }
    return 0;
}


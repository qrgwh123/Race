/*
 * Roundabout.h
 *
 *  Created on: May 11, 2024
 *      Author: guo
 */

#ifndef ROUNDABOUT_H_
#define ROUNDABOUT_H_

extern uint8 Roundabout_Corner;
extern uint8 Roundabout_Border[];
extern uint8 Temp_Corner;
extern uint8 Temp_Value;
extern uint8 Temp_Corner_Left;
extern uint8 Temp_Value_Left;
extern double Roundabout_Left_K, Roundabout_Left_B;

void Roundabout_Loop_Entry_Adding_Line_Right(void);
void Roundabout_Loop_Entry_Bracing_Wire_Right(void);
void Roundabout_Out_Of_The_Virtual_Loop_Bracing_Wire_Right(void);
void Roundabout_Out_Of_The_Loop_Adding_Line_Right(void);

uint8 Assist_Right_Roundabout_Zero_End(void);
uint8 Assist_Left_Roundabout_Zero_End(void);

void Roundabout_Loop_Entry_Adding_Line_Left(void);
void Roundabout_Loop_Entry_Bracing_Wire_Left(void);
void Roundabout_Out_Of_The_Virtual_Loop_Bracing_Wire_Left(void);
void Roundabout_Out_Of_The_Loop_Adding_Line_Left(void);

#endif /* ROUNDABOUT_H_ */

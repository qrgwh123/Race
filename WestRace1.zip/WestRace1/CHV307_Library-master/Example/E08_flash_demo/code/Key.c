/*
 * Key.c
 *
 *  Created on: Apr 8, 2024
 *      Author: guo
 */

#include "zf_common_headfile.h"
#include "Motor.h"
#include "Key.h"

uint8 Key_Number = 0;

void Key_Init(void)
{
    gpio_init(A0, GPI, 0, GPI_PULL_UP);
    gpio_init(A1, GPI, 0, GPI_PULL_UP);
    gpio_init(A2, GPI, 0, GPI_PULL_UP);
    gpio_init(A3, GPI, 0, GPI_PULL_UP);
    gpio_init(C5, GPI, 0, GPI_PULL_UP);
    gpio_init(B0, GPI, 0, GPI_PULL_UP);
    gpio_init(B1, GPI, 0, GPI_PULL_UP);
    gpio_init(E7, GPI, 0, GPI_PULL_UP);
    gpio_init(E9, GPI, 0, GPI_PULL_UP);
}

void Key_Test_Duty_Control(void)
{
    if(gpio_get_level(KEY_UP) == 0)
    {
        system_delay_ms(20);
        while(gpio_get_level(KEY_UP) == 0);
        system_delay_ms(20);
        Key_Number = KEY_NUMBER_UP;
    }
    if(gpio_get_level(KEY_DOWM) == 0)
    {
        system_delay_ms(20);
        while(gpio_get_level(KEY_DOWM) == 0);
        system_delay_ms(20);
        Key_Number = KEY_NUMBER_DOWM;
    }
    if(gpio_get_level(KEY_LEFT) == 0)
    {
        system_delay_ms(20);
        while(gpio_get_level(KEY_LEFT) == 0);
        system_delay_ms(20);
        Key_Number = KEY_NUMBER_LEFT;
    }
    if(gpio_get_level(KEY_RIGHT) == 0)
    {
        system_delay_ms(20);
        while(gpio_get_level(KEY_RIGHT) == 0);
        system_delay_ms(20);
        Key_Number = KEY_NUMBER_RIGHT;
    }
    if(gpio_get_level(KEY_MIDDLE) == 0)
    {
        system_delay_ms(20);
        while(gpio_get_level(KEY_MIDDLE) == 0);
        system_delay_ms(20);
        Key_Number = KEY_NUMBER_MIDDLE;
    }
}


/*
 * Speed.h
 *
 *  Created on: Apr 1, 2024
 *      Author: guo
 */

#ifndef SPEED_H_
#define SPEED_H_

extern int Speed;

void Speed_Init(void);
void Speed_Control(void);

#endif /* SPEED_H_ */

/*
 * Identify.h
 *
 *  Created on: Mar 30, 2024
 *      Author: guo
 */

#ifndef IDENTIFY_H_
#define IDENTIFY_H_

extern int L_L;
extern int L_R;
extern int R_L;
extern int R_R;
extern int L;
extern int R;
extern uint8 Identify_Track_Selection;
extern uint8 Identify_Track_Status;
extern uint8 Identify_Track_Probe;
extern uint8 Identify_Prev_Track;
extern uint8 Identify_Allow_Number;
extern uint8 Identify_Cross_Flag;

extern int L_L_Upper, L_L_Below;
extern int L_R_Upper, L_R_Below;
extern int R_L_Upper, R_L_Below;
extern int R_R_Upper, R_R_Below;

extern uint8 Roundabout_Flag;
extern uint8 Left_Roundabout_Flag;

extern uint8 L_B_Flag;
extern int Encoder_Integral_Max;

extern int Temp_L_L_CROS, Temp_L_R_CROS;
extern int Temp_R_L_CROS, Temp_R_R_CROS;
extern uint8 Count_1;
extern uint8 Count_2;
extern int AO_Count;
extern int AO_Count_Uppre;
extern uint8 S_Bend_Left;
extern uint8 S_Bend_Right;
extern uint8 Count_S_Bend;

extern uint8 Left_Roundabout_Identify_Number;
extern uint8 Right_Roundabout_Identify_Number;
extern uint8 Left_Avoid_Obstacles_Identify_Number;
extern uint8 Right_Avoid_Obstacles_Identify_Number;

enum Track_Selection
{
    Straightaway = 0,
    Cross = 1,
    S_Bend = 2,
    Roundabout = 3,
    Track_NULL = 4,
    Left_Roundabout = 5,
    Left_Avoid_Obstacles = 6,
    Right_Avoid_Obstacles = 7,
    Zebra_Crossing = 8
};

enum Track_Status
{
    Start = 0,
    Process = 1,
    End = 2
};

enum Prev_Track
{
    Prev_Straightaway = 0,
    Prev_Cross = 1,
    Prev_S_Bend = 2,
    Prev_Roundabout = 3,
    Prev_NULL = 4,
    Prev_Left_Roundabout = 5,
    Prev_Left_Avoid_Obstacles = 6,
    Prev_Right_Avoid_Obstacles = 7,
    Prev_Zebra_Crossing = 8
};

enum Prev_Status
{
    Prev_Start = 0,
    Prev_Process = 1,
    Prev_End = 2
};

enum Probe
{
    Probe_Straightaway = 0,
    Probe_Cross = 1,
    Probe_S_Bend = 2,
    Probe_Roundabout = 3,
    Probe_NULL = 4,
    Probe_Left_Roundabout = 5,
    Probe_Left_Avoid_Obstacles = 6,
    Probe_Right_Avoid_Obstacles = 7,
    Probe_Zebra_Crossing = 8
};

enum Return_Track
{
    Return_Straightaway = 0,
    Return_Cross = 1,
    Return_S_Bend = 2,
    Return_Roundabout = 3,
    Return_NULL = 4,
    Return_Left_Roundabout = 5,
    Return_Left_Avoid_Obstacles = 6,
    Return_Right_Avoid_Obstacles = 7,
    Return_Zebra_Crossing = 8
};

typedef struct
{
    uint8 Allow_Become_Straightaway_Min;
    uint8 Allow_Become_Cross_Min;
    uint8 Allow_Become_S_Bend_Min;
    uint8 Allow_Become_Roundabout_Min;
    uint8 Allow_Become_NULL_Min;
    uint8 Allow_Become_Left_Roundabout_Min;
    uint8 Allow_Become_Left_Avoid_Obstacles_Min;
    uint8 Allow_Become_Right_Avoid_Obstacles_Min;
    uint8 Allow_Become_Zebra_Crossing_Min;
}TRACK_DATE_t;

typedef struct
{
    uint8 Track_Selection;
    uint8 Track_Status;
    uint8 Prev_Track;
    uint8 Prev_Status;
    uint8 Probe;
    uint8 Allow_Become_Straightaway;
    uint8 Allow_Become_Cross;
    uint8 Allow_Become_S_Bend;
    uint8 Allow_Become_Roundabout;
    uint8 Allow_Become_NULL;
    uint8 Allow_Become_Left_Roundabout;
    uint8 Allow_Become_Left_Avoid_Obstacles;
    uint8 Allow_Become_Right_Avoid_Obstacles;
    uint8 Allow_Become_Zebra_Crossing;
    TRACK_DATE_t Track_data[8];
}TRACK_IDENTIFY_t;

void Identify_Track_Init(void);
void Identify_Track_Update(void);

void TRACK_IDENTIFY_DATE_Init_Var(TRACK_IDENTIFY_t *Track_Identify);
void TRACK_IDENTIFY_DATE_Update(TRACK_IDENTIFY_t *Track_Identify);
void TRACK_IDENTIFY_DATE_Examine(TRACK_IDENTIFY_t *Track_Identify);
void TRACK_IDENTIFY_DATE_Change_Track(TRACK_IDENTIFY_t *Track_Identify);
void TRACK_IDENTIFY_DATE_Change_Status(TRACK_IDENTIFY_t *Track_Identify);
enum Return_Track TRACK_IDENTIFY_DATE_Identify_Track(TRACK_IDENTIFY_t *Track_Identify);
uint8 TRACK_IDENTIFY_DATE_Identify_Status(TRACK_IDENTIFY_t *Track_Identify);

#endif /* IDENTIFY_H_ */

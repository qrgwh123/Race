/*
 * Buzzer.c
 *
 *  Created on: Jun 5, 2024
 *      Author: guo
 */

#include "zf_common_headfile.h"

void Buzzer_Init(void)
{
    gpio_init(E4, GPO, 0, GPO_PUSH_PULL);
}

void Buzzer_Control(void)
{

}

void Buzzer_On(void)
{
    gpio_set_level(E4, 1);
}

void Buzzer_Off(void)
{
    gpio_set_level(E4, 0);
}

/*
 * PID.h
 *
 *  Created on: Apr 1, 2024
 *      Author: guo
 */

#ifndef PID_H_
#define PID_H_

extern int Duty_L_R;
extern int Duty_B_L_R;
extern int Duty_B_L;
extern int Duty_B_R;
extern int Duty_N_L_R;
extern int Duty_N_L;
extern int Duty_N_R;
extern int GDPC_Straightaway;
extern int GDPC_Bend;
extern int A_Bend;
extern int GDPC_Left_Avoid_Obstacles, GDPC_Right_Avoid_Obstacles;
extern uint8 Extreme_Assistance_Start_Flag;

extern int Key_Up_Straightaway_Data;
extern int Key_Down_Cross_Data;
extern int Key_Left_S_Bend_Data;
extern int Key_Right_Roundabout_Data;
extern int Key_Middle_NULL_Track_Data;

extern int Straightaway_Speed_Pro_End;
extern int Cross_Speed_Pro_End;
extern int S_Bend_Speed_Pro_End;
extern int Roundabout_Speed_Pro_End;
extern int NULL_Track_Speed_Pro_End;

extern int Key_NULL_Track_Integral;

extern uint8 Break_Point_Number;
extern uint8 LARCMCLP_Number;

extern int8 DIFFERENCE_Value;

extern int Error;
extern int PrevError;

extern float MFPP, MFPI, MFLP, MFLI;

typedef struct{
    float Target;
    float Error;
    float PrevError;
    float I;
    float Integral_Max;
    float Integral_Min;
    float D;
    float Kp;
    float Ki;
    float Kd;
    float Out;
    float OutMax;
    float OutMin;
    float Real;
} PID_t;

typedef struct
{
    int Duty_L_R;
    int Duty_B_L;
    int Duty_B_R;
    int Duty_N_L;
    int Duty_N_R;
    int GDPC_Straightaway;
    int GDPC_Bend;
    int GDPC_Left_Avoid_Obstacles;
    int GDPC_Right_Avoid_Obstacles;
    int Speed;
    float Gyro_Z;

    int Prev_Duty_L_R;
    int Prev_Duty_B_L;
    int Prev_Duty_B_R;
    int Prev_Duty_N_L;
    int Prev_Duty_N_R;
    int Prev_GDPC_Straightaway;
    int Prev_GDPC_Bend;
    int Prev_GDPC_Left_Avoid_Obstacles;
    int Prev_GDPC_Right_Avoid_Obstacles;
    int Prev_Speed;
    float Prev_Gyro_Z;
}PREV_t;

void PID_Init(void);
void PID_Control(void);

void PID_Init_Var(PID_t *PID);
void PID_SetParam(PID_t *PID, float Kp, float Ki, float Kd);
void PID_SetThreshold(PID_t *PID, float OutMax, float OutMin);
void PID_SetTarget(PID_t *PID, float Target);
void PID_SetIntegral(PID_t *PID, float Integral_Max, float Integral_Min);
void PID_ReSetKi(PID_t *PID, float ReKi);
float PID_Update(PID_t *PID, float Real, float dt);

void PREV_Init_Var(PREV_t *Prev);
void PREV_Updata(PREV_t *Prev);

#endif /* PID_H_ */

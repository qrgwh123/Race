/*
 * PID.c
 *
 *  Created on: Apr 1, 2024
 *      Author: guo
 */

#include "zf_common_headfile.h"
#include "Camera.h"
#include "Identify.h"
#include "Speed.h"
#include "Acc_Gyro.h"
#include "PID.h"
#include "Roundabout.h"
#include "Buzzer.h"

int Gain_Direction_Power_Control_Straightaway(uint8 Start, uint8 End); //95 120
int Gain_Direction_Power_Control_Bend(uint8 Start); //70
int Gain_Direction_Power_Control_Left_Avoid_Obstacles(uint8 Start, uint8 End);
int Gain_Direction_Power_Control_Right_Avoid_Obstacles(uint8 Start, uint8 End);
void Gain_Duty(void);
void PID_Straightaway_Init(void);
void PID_Cross_Init(void);
void PID_S_Bend_Init(void);
void PID_Track_NULL_Init(void);
void PID_Roundabout_Init(void);
void Gyro_Z_Start_Not_Brush(void);
void L_R_And_B_L_R_Start_Not_Bruah_And_L_R_Brush(void);
void S_Bend_Start_Return_To_The_Center(void);
void Adjust_Not_Brush_To_Restore_Vehicle_Structural_Balance(void);
void Duty_Limitation(void);
void Extreme_Assistance(void);
void Extreme_Assistance_End(void);
void Re_Set_PID_All(void);
void Re_Set_PID_NULL_Track_Integral(void);
void Ultimate_Power_Distribution(void);
void Dynamic_Condition_PID(void);
uint8 Break_Point_NULL_Track(void);
uint8 Left_And_Right_Contact_Min_Coincidence_Line_Point(void);
void Limit_Difference_All_Track(void);
float Fuzzy_P(float E,float EC,uint8 choose);
void Show_Error_And_PrevError(void);

int Duty_L_R = 0, Duty_B_L_R = 0, Duty_N_L_R = 0;
int Duty_B_L = 0, Duty_B_R = 0, Duty_N_L = 0, Duty_N_R = 0;
int GDPC_Straightaway = 0, GDPC_Bend = 0;
int Average_Speed = 0,Average_Gyro_Z = 0;
int Average_GDPC_Straightaway = 0, Average_GDPC_Bend = 0;
int GDPC_Left_Avoid_Obstacles = 0, GDPC_Right_Avoid_Obstacles = 0;
int Average_GDPC_Left_Avoid_Obstacles = 0, Average_GDPC_Right_Avoid_Obstacles = 0;

PREV_t Prev;
PID_t Straightaway_Speed_Pid, Straightaway_GDPC_Straightaway_Pid;
PID_t Cross_Speed_Pid, Cross_GDPC_Straightaway_Pid, Cross_GDPC_Straightaway_Bend_Pid;
PID_t S_Bend_Speed_Pid, S_Bend_GDPC_Straightaway_Pid;
PID_t Track_NULL_Speed_Pid, Track_NULL_GDPC_Straightaway_Pid, Track_NULL_GDPC_Bend_Pid;
PID_t Roundabout_Speed_Pid, Roundabout_GDPC_Straightaway_Pid, Roundabout_GDPC_Bend_Pid;

int A_Bend = 0;

extern uint8 Kernel_Variable;

uint8 Extreme_Assistance_Start_Flag = 0;

int Key_Up_Straightaway_Data = 0;
int Key_Down_Cross_Data = 0;
int Key_Left_S_Bend_Data = 0;
int Key_Right_Roundabout_Data = 0;
int Key_Middle_NULL_Track_Data = 0;

int Straightaway_Speed_Pro_End = 0;
int Cross_Speed_Pro_End = 0;
int S_Bend_Speed_Pro_End = 0;
int Roundabout_Speed_Pro_End = 0;
int NULL_Track_Speed_Pro_End = 0;

int Key_NULL_Track_Integral = 0;

uint8 Break_Point_Number = 0;
uint8 LARCMCLP_Number = 0;
int8 DIFFERENCE_Value = 0;

#define PB  6
#define PM  5
#define PS  4
#define ZO  3
#define NS  2
#define NM  1
#define NB  0

float U=0;                            /*ƫ��,ƫ��΢���Լ����ֵ�ľ�ȷ��*/
float PF[2]={0},DF[2]={0},UF[4]={0};  /*ƫ��,ƫ��΢���Լ����ֵ��������*/
int Pn=0,Dn=0,Un[4]={0};
float t1=0,t2=0,t3=0,t4=0,temp1=0,temp2=0;

int Error = 0;
int PrevError = 0;

float MFPP = 0, MFPI = 0, MFLP = 0, MFLI = 0;

void PID_Init(void)
{
    PREV_Init_Var(&Prev);
    PID_Straightaway_Init();
    PID_Cross_Init();
    PID_S_Bend_Init();
    PID_Track_NULL_Init();
    PID_Roundabout_Init();
}

void PID_Control(void)
{
    GDPC_Straightaway = Gain_Direction_Power_Control_Straightaway(95, 120);
    GDPC_Bend = Gain_Direction_Power_Control_Bend(55);
    GDPC_Left_Avoid_Obstacles = Gain_Direction_Power_Control_Left_Avoid_Obstacles(95, 120);
    GDPC_Right_Avoid_Obstacles = Gain_Direction_Power_Control_Right_Avoid_Obstacles(95, 120);
    PREV_Updata(&Prev);
    Prev.GDPC_Straightaway = GDPC_Straightaway;
    Prev.GDPC_Bend = GDPC_Bend;
    Prev.GDPC_Left_Avoid_Obstacles = GDPC_Left_Avoid_Obstacles;
    Prev.GDPC_Right_Avoid_Obstacles = GDPC_Right_Avoid_Obstacles;
    Prev.Speed = Speed;
    Prev.Gyro_Z = Gyro_Z;
    Average_GDPC_Straightaway = (Prev.GDPC_Straightaway + Prev.Prev_GDPC_Straightaway) / 2;
    Average_GDPC_Bend = (Prev.GDPC_Bend + Prev.Prev_GDPC_Bend) / 2;
    Average_GDPC_Left_Avoid_Obstacles = (Prev.GDPC_Left_Avoid_Obstacles + Prev.Prev_GDPC_Left_Avoid_Obstacles) / 2;
    Average_GDPC_Right_Avoid_Obstacles = (Prev.GDPC_Right_Avoid_Obstacles + Prev.Prev_GDPC_Right_Avoid_Obstacles) / 2;
    Average_Speed = (Prev.Speed + Prev.Prev_Speed) / 2;
    Average_Gyro_Z = (Prev.Gyro_Z + Prev.Prev_Gyro_Z) / 2;
    Re_Set_PID_All();
    //Dynamic_Condition_PID();
    Show_Error_And_PrevError();
    if(Identify_Track_Selection == 0)
    {
        Prev.Duty_L_R = PID_Update(&Straightaway_GDPC_Straightaway_Pid, Average_GDPC_Straightaway, 1);
        Duty_B_L_R = PID_Update(&Straightaway_Speed_Pid, Average_Speed, 1);
        if(Duty_B_L_R > 0)
        {
            Prev.Duty_B_L = Duty_B_L_R;
            Prev.Duty_B_R = Duty_B_L_R;
            Duty_N_L_R = 80;
        }else
        {
            Prev.Duty_B_L = 0;
            Prev.Duty_B_R = 0;
            Duty_N_L_R = 80 + Duty_B_L_R;
        }
    }else if(Identify_Track_Selection == 1)
    {
        Prev.Duty_L_R = PID_Update(&Cross_GDPC_Straightaway_Pid, Average_GDPC_Straightaway, 1);
        Duty_B_L_R = PID_Update(&Cross_Speed_Pid, Average_Speed, 1);
        if(Identify_Track_Status == 0 || Identify_Track_Status == 2)
        {
            if(Duty_B_L_R > 0)
            {
                Prev.Duty_B_L = Duty_B_L_R;
                Prev.Duty_B_R = Duty_B_L_R;
                Duty_N_L_R = 80;
            }else
            {
                Prev.Duty_B_L = 0;
                Prev.Duty_B_R = 0;
                Duty_N_L_R = 80 + Duty_B_L_R;
            }
        }else if(Identify_Track_Status == 1)
        {
            if(abs(Average_GDPC_Bend) >= 10)
            {
                Prev.Duty_L_R = PID_Update(&Cross_GDPC_Straightaway_Bend_Pid, Average_GDPC_Straightaway, 1);
            }
            if(Duty_B_L_R > 0)
            {
                Prev.Duty_B_L = Duty_B_L_R;
                Prev.Duty_B_R = Duty_B_L_R;
                Duty_N_L_R = 85;
            }else
            {
                Prev.Duty_B_L = 0;
                Prev.Duty_B_R = 0;
                Duty_N_L_R = 85 + Duty_B_L_R;
            }
            if(R_Far_Lost > L_Far_Lost || (R_Lost - R_Far_Lost - R_Near_Lost) - (L_Lost - L_Far_Lost - L_Near_Lost) > 0)
            {
                if(Prev.Duty_L_R < 0)
                {
                    Prev.Duty_L_R *= 0.7;
                }
            }else
            {
                if(Prev.Duty_L_R > 0)
                {
                    Prev.Duty_L_R *= 0.7;
                }
            }
        }
    }else if(Identify_Track_Selection == 2)
    {
        Prev.Duty_L_R = PID_Update(&S_Bend_GDPC_Straightaway_Pid, Average_GDPC_Straightaway, 1);
        Duty_B_L_R = PID_Update(&S_Bend_Speed_Pid, Average_Speed, 1);
        if(Duty_B_L_R > 0)
        {
            Prev.Duty_B_L = Duty_B_L_R;
            Prev.Duty_B_R = Duty_B_L_R;
            Duty_N_L_R = 80;
        }else
        {
            Prev.Duty_B_L = 0;
            Prev.Duty_B_R = 0;
            Duty_N_L_R = 80 + Duty_B_L_R;
        }
        S_Bend_Start_Return_To_The_Center();
    }else if(Identify_Track_Selection == 4)
    {
        if(Original_L_Line[0] != 255)
        {
            PID_ReSetKi(&Track_NULL_GDPC_Straightaway_Pid, 0);
            PID_ReSetKi(&Track_NULL_GDPC_Bend_Pid, 0);
        }else
        {
            PID_ReSetKi(&Track_NULL_GDPC_Straightaway_Pid, 0.25);
            PID_ReSetKi(&Track_NULL_GDPC_Bend_Pid, 0.25);
        }

        //Ultimate_Power_Distribution();

        /*if(L_Lost - L_Far_Lost - L_Near_Lost == 0 && R_Lost - R_Far_Lost - R_Near_Lost == 0)
        {
            PID_SetTarget(&Track_NULL_Speed_Pid, 251);
        }else
        {
            PID_SetTarget(&Track_NULL_Speed_Pid, 170 + Key_Middle_NULL_Track_Data);//170
        }*/
        Prev.Duty_L_R = PID_Update(&Track_NULL_GDPC_Straightaway_Pid, Average_GDPC_Straightaway, 1);
        Duty_B_L_R = PID_Update(&Track_NULL_Speed_Pid, Average_Speed, 1);
        Prev.Duty_B_L = Duty_B_L_R;
        Prev.Duty_B_R = Duty_B_L_R;
        if(Duty_B_L_R > 0)
        {
            Prev.Duty_B_L = Duty_B_L_R;
            Prev.Duty_B_R = Duty_B_L_R;
            Duty_N_L_R = 80;
        }else
        {
            Prev.Duty_B_L = 0;
            Prev.Duty_B_R = 0;
            Duty_N_L_R = 80 + Duty_B_L_R;
        }
//        if(abs(Average_GDPC_Bend) >= 10)
//        {
//            if(Average_GDPC_Bend > 0)
//            {
//                Prev.Duty_B_L -= PID_Update(&Track_NULL_GDPC_Bend_Pid, Average_GDPC_Bend, 1);
//            }else
//            {
//                Prev.Duty_B_R += PID_Update(&Track_NULL_GDPC_Bend_Pid, Average_GDPC_Bend, 1);
//            }
//        }
        //
        //
        Prev.Duty_L_R -= PID_Update(&Track_NULL_GDPC_Bend_Pid, Average_GDPC_Bend, 1);
        //
        /*if(Speed > 170)
        {
            Prev.Duty_L_R -= PID_Update(&Track_NULL_GDPC_Bend_Pid, Average_GDPC_Bend, 1) * (1 + 0.0066 * (Speed - 170));
        }else
        {
            Prev.Duty_L_R -= PID_Update(&Track_NULL_GDPC_Bend_Pid, Average_GDPC_Bend, 1);
        }*/
//        if(abs(abs(GDPC_Bend) - abs(GDPC_Straightaway)) > 10)
//        {
//            Prev.Duty_L_R += GDPC_Bend * 1.33;
//        }else
//        {
//            Prev.Duty_L_R = Prev.Duty_L_R * 1.66 + GDPC_Bend;
//        }
        if(Prev.Gyro_Z > 50 && Prev.Prev_Gyro_Z < -50)
        {
            Prev.Duty_L_R = PID_Update(&Straightaway_GDPC_Straightaway_Pid, Average_GDPC_Straightaway, 1) * 0.5;
        }else if(Prev.Gyro_Z < -50 && Prev.Prev_Gyro_Z > 50)
        {
            Prev.Duty_L_R = PID_Update(&Straightaway_GDPC_Straightaway_Pid, Average_GDPC_Straightaway, 1) * 0.5;
        }
    }else if(Identify_Track_Selection == 3 || Identify_Track_Selection == 5)
    {
        //Prev.Duty_L_R = PID_Update(&Roundabout_GDPC_Straightaway_Pid, Average_GDPC_Straightaway, 1);
        if(Left_Roundabout_Flag == 1 || Roundabout_Flag == 1 || Left_Roundabout_Flag == 6 || Roundabout_Flag == 6 || Left_Roundabout_Flag == 0 || Roundabout_Flag == 0)
        {
            PID_ReSetKi(&Roundabout_GDPC_Straightaway_Pid, 0);
            PID_ReSetKi(&Roundabout_GDPC_Bend_Pid, 0);
        }else
        {
            PID_ReSetKi(&Roundabout_GDPC_Straightaway_Pid, 0.25);
            PID_ReSetKi(&Roundabout_GDPC_Bend_Pid, 0.25);
        }
        Prev.Duty_L_R = PID_Update(&Roundabout_GDPC_Straightaway_Pid, Average_GDPC_Straightaway, 1);
        Prev.Duty_L_R -= PID_Update(&Roundabout_GDPC_Bend_Pid, Average_GDPC_Bend, 1);

        //
        if(Left_Roundabout_Flag == 6 || Roundabout_Flag == 6)
        {
            PID_SetTarget(&Roundabout_Speed_Pid, 200);
        }
        if(Left_Roundabout_Flag == 12 || Roundabout_Flag == 12)
        {
            //Prev.Duty_L_R *= 1.5;

        }
        if(Identify_Track_Selection == 0 && (Left_Roundabout_Flag == 2 || Roundabout_Flag == 2))
        {
            //Prev.Duty_L_R *= 1.5;

        }
        if(Identify_Track_Status == 1 && (Left_Roundabout_Flag == 3 || Roundabout_Flag == 3))
        {
//            if(Prev.Duty_L_R >= 70)
//            {
//                Prev.Duty_L_R = 75;
//            }
//            if(Prev.Duty_L_R <= -70)
//            {
//                Prev.Duty_L_R = -75;
//            }
        }
        if(Identify_Track_Status == 1 && (Left_Roundabout_Flag == 2 || Roundabout_Flag == 2))
        {
            //Prev.Duty_L_R *= 1.5;
        }

        //
        Duty_B_L_R = PID_Update(&Roundabout_Speed_Pid, Average_Speed, 1);
        if(Duty_B_L_R > 0)
        {
            Prev.Duty_B_L = Duty_B_L_R;
            Prev.Duty_B_R = Duty_B_L_R;
            Duty_N_L_R = 80;
        }else
        {
            Prev.Duty_B_L = 0;
            Prev.Duty_B_R = 0;
            Duty_N_L_R = 80 + Duty_B_L_R;
        }
    }else if(Identify_Track_Selection == 6)
    {
        Prev.Duty_L_R = PID_Update(&Straightaway_GDPC_Straightaway_Pid, Average_GDPC_Right_Avoid_Obstacles, 1);
        Duty_B_L_R = PID_Update(&Track_NULL_Speed_Pid, Average_Speed, 1);
        if(Duty_B_L_R > 0)
        {
            Prev.Duty_B_L = Duty_B_L_R;
            Prev.Duty_B_R = Duty_B_L_R;//
            Duty_N_L_R = 100;
        }else
        {
            Prev.Duty_B_L = 0;
            Prev.Duty_B_R = 0;//
            Duty_N_L_R = 100 + Duty_B_L_R;
        }
        //Prev.Duty_B_L += abs(Prev.Duty_L_R);
        Prev.Duty_L_R *= 1.33;
    }else if(Identify_Track_Selection == 7)
    {
        Prev.Duty_L_R = PID_Update(&Straightaway_GDPC_Straightaway_Pid, Average_GDPC_Left_Avoid_Obstacles, 1);
        Duty_B_L_R = PID_Update(&Track_NULL_Speed_Pid, Average_Speed, 1);
        if(Duty_B_L_R > 0)
        {
            Prev.Duty_B_L = Duty_B_L_R;
            Prev.Duty_B_R = Duty_B_L_R;
            Duty_N_L_R = 100;
        }else
        {
            Prev.Duty_B_L = 0;
            Prev.Duty_B_R = 0;
            Duty_N_L_R = 100 + Duty_B_L_R;
        }
        //Prev.Duty_B_R += abs(Prev.Duty_L_R);
        Prev.Duty_L_R *= 1.33;
    }else if(Identify_Track_Selection == 8)
    {
        Prev.Duty_L_R = PID_Update(&Straightaway_GDPC_Straightaway_Pid, Average_GDPC_Straightaway, 1);
        if(Kernel_Variable == 0 || Kernel_Variable == 1)
        {
            Duty_B_L_R = PID_Update(&Straightaway_Speed_Pid, Average_Speed, 1);
        }else
        {
            Duty_B_L_R = PID_Update(&Track_NULL_Speed_Pid, Average_Speed, 1);
        }
        if(Duty_B_L_R > 0)
        {
            Prev.Duty_B_L = Duty_B_L_R;
            Prev.Duty_B_R = Duty_B_L_R;
            Duty_N_L_R = 80;
        }else
        {
            Prev.Duty_B_L = 0;
            Prev.Duty_B_R = 0;
            Duty_N_L_R = 80 + Duty_B_L_R;
        }
    }
    Gyro_Z_Start_Not_Brush();
    L_R_And_B_L_R_Start_Not_Bruah_And_L_R_Brush();
    Adjust_Not_Brush_To_Restore_Vehicle_Structural_Balance();
    Duty_Limitation();
//    Extreme_Assistance();
    if(Identify_Track_Selection == 4)
    {
        Extreme_Assistance();
        if(Extreme_Assistance_Start_Flag == 1)
        {
            Prev.Duty_L_R = 50;
            Prev.Duty_N_L = 100;
            Prev.Duty_N_R = 20;
            Prev.Duty_B_L = 0;
            Prev.Duty_B_R = 0;
        }else if(Extreme_Assistance_Start_Flag == 2)
        {
            Prev.Duty_L_R = -50;
            Prev.Duty_N_L = 20;
            Prev.Duty_N_R = 100;
            Prev.Duty_B_L = 0;
            Prev.Duty_B_R = 0;
        }
        Extreme_Assistance_End();
    }
    Gain_Duty();
    if(Kernel_Variable == 2 && Identify_Track_Selection != 8)
    {
        Duty_L_R = 0;
        Duty_B_L = 0;
        Duty_B_R = 0;
        Duty_N_L = 0;
        Duty_N_R = 0;
    }
}

int Gain_Direction_Power_Control_Straightaway(uint8 Start, uint8 End)
{
    int temp = 0;
    for(uint8 i = Start; i < End; i++)
    {
        temp += (94 - Midcourt_Line[i]);
    }
    return temp / (End - Start);
}

int Gain_Direction_Power_Control_Bend(uint8 Start)
{
    int temp = 0;
    for(uint8 i = MT9V03X_H - 1 - 1; i >= Start; i--)
    {
        if(Midcourt_Line[i] == 0)
        {
            break;
        }
        if(abs(Midcourt_Line[i] - Midcourt_Line[i + 1]) > 20)
        {
            break;
        }
        temp += Midcourt_Line[i] - Midcourt_Line[i + 1];
    }
    return temp;
}

int Gain_Direction_Power_Control_Left_Avoid_Obstacles(uint8 Start, uint8 End)
{
    int temp = 0;
    for(uint8 i = Start; i < End; i++)
    {
        //temp += (94 - Original_L_Line[i]);
        temp += (94 - ((Original_L_Line[i] * 3) / 4 + Original_R_Line[i] / 4));
    }
    return temp / (End - Start);
}

int Gain_Direction_Power_Control_Right_Avoid_Obstacles(uint8 Start, uint8 End)
{
    int temp = 0;
    for(uint8 i = Start; i < End; i++)
    {
        //temp += (94 - Original_R_Line[i]);
        temp += (94 - (Original_L_Line[i] / 4 + (Original_R_Line[i] * 3) / 4));
    }
    return temp / (End - Start);
}

void PID_Init_Var(PID_t *PID)
{
    PID->Target = 0;
    PID->Error = 0;
    PID->PrevError = 0;
    PID->I = 0;
    PID->Integral_Max = 0;
    PID->Integral_Min = 0;
    PID->D = 0;
    PID->Kp = 0;
    PID->Ki = 0;
    PID->Kd = 0;
    PID->Out = 0;
    PID->OutMax = 0;
    PID->OutMin = 0;
}

void PID_SetParam(PID_t *PID, float Kp, float Ki, float Kd)
{
    PID->Kp = Kp;
    PID->Ki = Ki;
    PID->Kd = Kd;
}

void PID_SetThreshold(PID_t *PID, float OutMax, float OutMin)
{
    PID->OutMax = OutMax;
    PID->OutMin = OutMin;
}

void PID_SetTarget(PID_t *PID, float Target)
{
    PID->Target = Target;
}

void PID_SetIntegral(PID_t *PID, float Integral_Max, float Integral_Min)
{
    PID->Integral_Max = Integral_Max;
    PID->Integral_Min = Integral_Min;
}

void PID_ReSetKi(PID_t *PID, float ReKi)
{
    PID->I = ReKi;
}

float PID_Update(PID_t *PID, float Real, float dt)
{
    PID->Real = Real;

    PID->PrevError = PID->Error;
    PID->Error = PID->Target - Real;

    PID->I += PID->Error * dt;

    if(PID->I > PID->Integral_Max)
    {
        PID->I = PID->Integral_Max;
    }else if(PID->I < PID->Integral_Min)
    {
        PID->I = PID->Integral_Min;
    }

    PID->D = (PID->Error - PID->PrevError) / dt;

    PID->Out = PID->Kp * PID->Error
             + PID->Ki * PID->I
             + PID->Kd * PID->D;

    if (PID->Out > PID->OutMax)
    {
        PID->Out = PID->OutMax;
    }
    else if (PID->Out < PID->OutMin)
    {
        PID->Out = PID->OutMin;
    }

    return PID->Out;
}

void PREV_Init_Var(PREV_t *Prev)
{
    Prev->Duty_L_R = 0;
    Prev->Duty_B_L = 0;
    Prev->Duty_B_R = 0;
    Prev->Duty_N_L = 0;
    Prev->Duty_N_R = 0;
    Prev->Speed = 0;
    Prev->Gyro_Z = 0;

    Prev->Prev_Duty_L_R = 0;
    Prev->Prev_Duty_B_L = 0;
    Prev->Prev_Duty_B_R = 0;
    Prev->Prev_Duty_N_L = 0;
    Prev->Prev_Duty_N_R = 0;
    Prev->Prev_Speed = 0;
    Prev->Prev_Gyro_Z = 0;
}

void PREV_Updata(PREV_t *Prev)
{
    Prev->Prev_Duty_L_R = Prev->Duty_L_R;
    Prev->Prev_Duty_B_L = Prev->Duty_B_L;
    Prev->Prev_Duty_B_R = Prev->Duty_B_R;
    Prev->Prev_Duty_N_L = Prev->Duty_N_L;
    Prev->Prev_Duty_N_R = Prev->Duty_N_R;
    Prev->Prev_GDPC_Straightaway = Prev->GDPC_Straightaway;
    Prev->Prev_GDPC_Bend = Prev->GDPC_Bend;
    Prev->Prev_GDPC_Left_Avoid_Obstacles = Prev->GDPC_Left_Avoid_Obstacles;
    Prev->Prev_GDPC_Right_Avoid_Obstacles = Prev->GDPC_Right_Avoid_Obstacles;
    Prev->Prev_Speed = Prev->Speed;
    Prev->Prev_Gyro_Z = Prev->Gyro_Z;
}

void Gain_Duty(void)
{
    Duty_L_R = (Prev.Duty_L_R + Prev.Prev_Duty_L_R) / 2;
    if(Duty_L_R > 30)
    {
        Duty_L_R *= 1.3;
    }
    Duty_B_L = (Prev.Duty_B_L + Prev.Prev_Duty_B_L) / 2;
    Duty_B_R = (Prev.Duty_B_R + Prev.Prev_Duty_B_R) / 2;
    Duty_N_L = (Prev.Duty_N_L + Prev.Prev_Duty_N_L) / 2;
    Duty_N_R = (Prev.Duty_N_R + Prev.Prev_Duty_N_R) / 2;
}

void PID_Straightaway_Init(void)
{
    PID_Init_Var(&Straightaway_Speed_Pid);
    PID_SetParam(&Straightaway_Speed_Pid, 2.3533, 1.3355, 0);//
    PID_SetTarget(&Straightaway_Speed_Pid, 170 + Key_Up_Straightaway_Data);//
    PID_SetIntegral(&Straightaway_Speed_Pid, 50, -50);
    PID_SetThreshold(&Straightaway_Speed_Pid, 100, -10);//80

    PID_Init_Var(&Straightaway_GDPC_Straightaway_Pid);
    PID_SetParam(&Straightaway_GDPC_Straightaway_Pid, 0.5, 0.25, 1);//
    PID_SetTarget(&Straightaway_GDPC_Straightaway_Pid, 0);
    PID_SetIntegral(&Straightaway_GDPC_Straightaway_Pid, 10, -10);
    PID_SetThreshold(&Straightaway_GDPC_Straightaway_Pid, 40, -40);
}

void PID_Cross_Init(void)
{
    PID_Init_Var(&Cross_Speed_Pid);
    PID_SetParam(&Cross_Speed_Pid, 1.7533, 0.3355, 0);//
    PID_SetTarget(&Cross_Speed_Pid, 175 + Key_Down_Cross_Data);//
    PID_SetIntegral(&Cross_Speed_Pid, 50, -50);
    PID_SetThreshold(&Cross_Speed_Pid, 100, -10);//70

    PID_Init_Var(&Cross_GDPC_Straightaway_Pid);
    PID_SetParam(&Cross_GDPC_Straightaway_Pid, 1, 0.25, 1);//
    PID_SetTarget(&Cross_GDPC_Straightaway_Pid, 0);
    PID_SetIntegral(&Cross_GDPC_Straightaway_Pid, 20, -20);
    PID_SetThreshold(&Cross_GDPC_Straightaway_Pid, 60, -60);

    PID_Init_Var(&Cross_GDPC_Straightaway_Bend_Pid);
    PID_SetParam(&Cross_GDPC_Straightaway_Bend_Pid, 0.5, 0.2, 1);
    PID_SetTarget(&Cross_GDPC_Straightaway_Bend_Pid, 0);
    PID_SetIntegral(&Cross_GDPC_Straightaway_Bend_Pid, 20, -20);
    PID_SetThreshold(&Cross_GDPC_Straightaway_Bend_Pid, 65, -65);//
}

void PID_S_Bend_Init(void)
{
    PID_Init_Var(&S_Bend_Speed_Pid);
    PID_SetParam(&S_Bend_Speed_Pid, 1.8633, 0.3355, 0);//
    PID_SetTarget(&S_Bend_Speed_Pid, 160 + Key_Left_S_Bend_Data);//
    PID_SetIntegral(&S_Bend_Speed_Pid, 50, -50);
    PID_SetThreshold(&S_Bend_Speed_Pid, 100, -10);//

    PID_Init_Var(&S_Bend_GDPC_Straightaway_Pid);
    PID_SetParam(&S_Bend_GDPC_Straightaway_Pid, 1, 0.5, 1);
    PID_SetTarget(&S_Bend_GDPC_Straightaway_Pid, 0);
    PID_SetIntegral(&S_Bend_GDPC_Straightaway_Pid, 10, 10);
    PID_SetThreshold(&S_Bend_GDPC_Straightaway_Pid, 40, -40);
}

void PID_Track_NULL_Init(void)
{
    PID_Init_Var(&Track_NULL_Speed_Pid);
    PID_SetParam(&Track_NULL_Speed_Pid, 1.6533, 0.4567, 0);//
    PID_SetTarget(&Track_NULL_Speed_Pid, 170 + Key_Middle_NULL_Track_Data);//
    PID_SetIntegral(&Track_NULL_Speed_Pid, 50, -50);
    PID_SetThreshold(&Track_NULL_Speed_Pid, 70, -10);//70 -10

    PID_Init_Var(&Track_NULL_GDPC_Straightaway_Pid);
    PID_SetParam(&Track_NULL_GDPC_Straightaway_Pid, 0.5, 0.50, 1);
    PID_SetTarget(&Track_NULL_GDPC_Straightaway_Pid, 0);
    PID_SetIntegral(&Track_NULL_GDPC_Straightaway_Pid, 50, -50);
    PID_SetThreshold(&Track_NULL_GDPC_Straightaway_Pid, 70, -70);

    PID_Init_Var(&Track_NULL_GDPC_Bend_Pid);
    PID_SetParam(&Track_NULL_GDPC_Bend_Pid, 0.5, 0.50, 1);
    PID_SetTarget(&Track_NULL_GDPC_Bend_Pid, 0);
    PID_SetIntegral(&Track_NULL_GDPC_Bend_Pid, 50, -50);
    PID_SetThreshold(&Track_NULL_GDPC_Bend_Pid, 70, -70);

    //
}

void PID_Roundabout_Init(void)
{
    PID_Init_Var(&Roundabout_Speed_Pid);
    PID_SetParam(&Roundabout_Speed_Pid, 1.6, 0.3355, 0);
    PID_SetTarget(&Roundabout_Speed_Pid, 160 + Key_Right_Roundabout_Data);
    PID_SetIntegral(&Roundabout_Speed_Pid, 50, -50);
    PID_SetThreshold(&Roundabout_Speed_Pid, 80, -10);//70 0

    PID_Init_Var(&Roundabout_GDPC_Straightaway_Pid);
    PID_SetParam(&Roundabout_GDPC_Straightaway_Pid, 0.5, 0.5, 1);
    PID_SetTarget(&Roundabout_GDPC_Straightaway_Pid, 0);
    PID_SetIntegral(&Roundabout_GDPC_Straightaway_Pid, 50, -50);
    PID_SetThreshold(&Roundabout_GDPC_Straightaway_Pid, 70, -70);

    PID_Init_Var(&Roundabout_GDPC_Bend_Pid);
    PID_SetParam(&Roundabout_GDPC_Bend_Pid, 0.5, 0.5, 1);
    PID_SetTarget(&Roundabout_GDPC_Bend_Pid, 0);
    PID_SetIntegral(&Roundabout_GDPC_Bend_Pid, 50, -50);
    PID_SetThreshold(&Roundabout_GDPC_Bend_Pid, 70, -70);
}

void Gyro_Z_Start_Not_Brush(void)
{
    Prev.Duty_N_L = Duty_N_L_R;
    Prev.Duty_N_R = Duty_N_L_R;
    //
    LARCMCLP_Number = Left_And_Right_Contact_Min_Coincidence_Line_Point();
    if(Prev.Gyro_Z > 100 && Prev.Prev_Gyro_Z > 100 && Original_L_Line[0] != 255)
    {
        if(Prev.Gyro_Z > 0)
        {
            Prev.Duty_N_R = Duty_N_L_R + Prev.Gyro_Z * 0.7;
        }else if(Prev.Gyro_Z < 0)
        {
            Prev.Duty_N_L = Duty_N_L_R - Prev.Gyro_Z * 0.7;
        }
//        Prev.Duty_N_L -= 20;
//        Prev.Duty_L_R -= 20;
        Prev.Duty_N_L -= 0.2 * LARCMCLP_Number;
        Prev.Duty_N_R -= 0.2 * LARCMCLP_Number;
        if(LARCMCLP_Number == 0 && abs(94 - Original_L_Line[0]) < 50 && abs(Original_R_Line[0] - 94) < 50)
        {
            uint8 Temp_Max = 0;
            Temp_Max = L_Near_Lost > R_Near_Lost ? L_Lost - L_Far_Lost : R_Lost - R_Far_Lost;
            Prev.Duty_N_L -= 0.25 * Temp_Max;
            Prev.Duty_N_R -= 0.25 * Temp_Max;
        }
    }else if(Prev.Gyro_Z < -100 && Prev.Prev_Gyro_Z < -100 && Original_L_Line[0] != 255)
    {
        if(Prev.Gyro_Z > 0)
        {
            Prev.Duty_N_R = Duty_N_L_R + Prev.Gyro_Z * 0.7;
        }else if(Prev.Gyro_Z < 0)
        {
            Prev.Duty_N_L = Duty_N_L_R - Prev.Gyro_Z * 0.7;
        }
//        Prev.Duty_N_L -= 20;
//        Prev.Duty_L_R -= 20;
        Prev.Duty_N_L -= 0.2 * LARCMCLP_Number;
        Prev.Duty_N_R -= 0.2 * LARCMCLP_Number;
        if(LARCMCLP_Number == 0 && abs(94 - Original_L_Line[0]) < 50 && abs(Original_R_Line[0] - 94) < 50)
        {
            uint8 Temp_Max = 0;
            Temp_Max = L_Near_Lost > R_Near_Lost ? L_Lost - L_Far_Lost : R_Lost - R_Far_Lost;
            Prev.Duty_N_L -= 0.25 * Temp_Max;
            Prev.Duty_N_R -= 0.25 * Temp_Max;
        }
    }
    //
    if(Identify_Track_Selection == 0 || Identify_Track_Selection == 6 || Identify_Track_Selection == 7)
    {
        if(Prev.Gyro_Z > 30)
        {
            Prev.Duty_N_R = Duty_N_L_R + Prev.Gyro_Z * 0.33;
        }else if(Prev.Gyro_Z < -30)
        {
            Prev.Duty_N_L = Duty_N_L_R - Prev.Gyro_Z * 0.33;
        }
    }else if(Identify_Track_Selection == 1)
    {
        if(Identify_Track_Status == 0 || Identify_Track_Status == 2)
        {
            if(Prev.Gyro_Z > 0)
            {
                Prev.Duty_N_R = Duty_N_L_R + Prev.Gyro_Z * 0.7;
            }else if(Prev.Gyro_Z < 0)
            {
                Prev.Duty_N_L = Duty_N_L_R - Prev.Gyro_Z * 0.7;
            }
        }
        if(Identify_Track_Status == 1)
        {
            if(abs(GDPC_Bend) >= 10)
            {
                if(Prev.Gyro_Z > 100)
                {
                    Prev.Duty_N_R = Duty_N_L_R + Prev.Gyro_Z * 0.33;
                }else if(Prev.Gyro_Z < -100)
                {
                    Prev.Duty_N_L = Duty_N_L_R - Prev.Gyro_Z * 0.33;
                }
            }else
            {
                if(Prev.Gyro_Z > 0)
                {
                    Prev.Duty_N_R = Duty_N_L_R + Prev.Gyro_Z * 1.0;
                }else if(Prev.Gyro_Z < 0)
                {
                    Prev.Duty_N_L = Duty_N_L_R - Prev.Gyro_Z * 1.0;
                }
            }
        }
    }else if(Identify_Track_Selection == 2)
    {
        if(Identify_Track_Status == 0)
        {
            if(Prev.Gyro_Z > 0)
            {
                Prev.Duty_N_R = Duty_N_L_R + Prev.Gyro_Z * 2;
            }else if(Prev.Gyro_Z < 0)
            {
                Prev.Duty_N_L = Duty_N_L_R - Prev.Gyro_Z * 2;
            }
        }
    }else if(Identify_Track_Selection == 4 || Identify_Track_Selection == 3 || Identify_Track_Selection == 5)
    {
        if(Identify_Track_Selection == 4)
        {
            if(abs(Average_GDPC_Bend) >= 15)
            {
                if(Prev.Gyro_Z > 100)
                {
                    Prev.Duty_N_R = Duty_N_L_R + Prev.Gyro_Z * 0.7;
                }else if(Prev.Gyro_Z < -100)
                {
                    Prev.Duty_N_L = Duty_N_L_R - Prev.Gyro_Z * 0.7;
                }
            }else if(abs(Average_GDPC_Bend) <= 15)
            {
                if(Prev.Gyro_Z > 0)
                {
                    Prev.Duty_N_R = Duty_N_L_R + Prev.Gyro_Z * 0.7;
                }else if(Prev.Gyro_Z < 0)
                {
                    Prev.Duty_N_L = Duty_N_L_R - Prev.Gyro_Z * 0.7;
                }
            }
        }else if(Identify_Track_Selection == 3)
        {
            if(abs(Average_GDPC_Bend) >= 15)
            {
                if(Prev.Gyro_Z > 100)
                {
                    Prev.Duty_N_R = Duty_N_L_R + Prev.Gyro_Z * 0.7;
                }else if(Prev.Gyro_Z < -100)
                {
                    Prev.Duty_N_L = Duty_N_L_R - Prev.Gyro_Z * 0.7;
                }
            }else if(abs(Average_GDPC_Bend) <= 15)
            {
                if(Prev.Gyro_Z > 0)
                {
                    Prev.Duty_N_R = Duty_N_L_R + Prev.Gyro_Z * 0.7;
                }else if(Prev.Gyro_Z < 0)
                {
                    Prev.Duty_N_L = Duty_N_L_R - Prev.Gyro_Z * 0.7;
                }
            }
        }else if(Identify_Track_Selection == 5)
        {
            if(abs(Average_GDPC_Bend) >= 15)
            {
                if(Prev.Gyro_Z > 75)
                {
                    Prev.Duty_N_R = Duty_N_L_R + Prev.Gyro_Z * 0.7;
                }else if(Prev.Gyro_Z < -75)
                {
                    Prev.Duty_N_L = Duty_N_L_R - Prev.Gyro_Z * 0.7;
                }
            }else if(abs(Average_GDPC_Bend) <= 15)
            {
                if(Prev.Gyro_Z > 0)
                {
                    Prev.Duty_N_R = Duty_N_L_R + Prev.Gyro_Z * 0.7;
                }else if(Prev.Gyro_Z < 0)
                {
                    Prev.Duty_N_L = Duty_N_L_R - Prev.Gyro_Z * 0.7;
                }
            }
        }
        if(Identify_Track_Selection == 3 || Identify_Track_Selection == 5)
        {
            if(Prev.Gyro_Z > 150 || Prev.Gyro_Z < -150)
            {
                Prev.Duty_N_R -= 10;
            }else if(Prev.Gyro_Z > 200 || Prev.Gyro_Z < -200)
            {
                Prev.Duty_N_L -= 20;
            }
        }
        if(Prev.Gyro_Z > 50 && Prev.Prev_Gyro_Z < -50)
        {
            if(Prev.Gyro_Z > 0)
            {
                Prev.Duty_N_R = Duty_N_L_R + Prev.Gyro_Z * 0.7;
            }else if(Prev.Gyro_Z < 0)
            {
                Prev.Duty_N_L = Duty_N_L_R - Prev.Gyro_Z * 0.7;
            }
        }else if(Prev.Gyro_Z < -50 && Prev.Prev_Gyro_Z > 50)
        {
            if(Prev.Gyro_Z > 0)
            {
                Prev.Duty_N_R = Duty_N_L_R + Prev.Gyro_Z * 0.7;
            }else if(Prev.Gyro_Z < 0)
            {
                Prev.Duty_N_L = Duty_N_L_R - Prev.Gyro_Z * 0.7;
            }
        }

    }

}

void L_R_And_B_L_R_Start_Not_Bruah_And_L_R_Brush(void)
{
    if(Identify_Track_Selection == 0 || Identify_Track_Selection == 2 || Identify_Track_Selection == 6 || Identify_Track_Selection == 7)
    {
        if(abs(Prev.Duty_L_R) > 10)
        {
            if(Prev.Gyro_Z > 0)
            {
                Prev.Duty_N_R = Duty_N_L_R + abs(Prev.Duty_L_R) * 0.33;
            }else
            {
                Prev.Duty_N_L = Duty_N_L_R + abs(Prev.Duty_L_R) * 0.33;
            }
        }
    }else if(Identify_Track_Selection == 1)
    {
        if(Identify_Track_Status == 0 || Identify_Track_Status == 2)
        {
            if(abs(Prev.Duty_L_R) > 10)
            {
                if(Prev.Gyro_Z > 0)
                {
                    Prev.Duty_N_R = Duty_N_L_R + abs(Prev.Duty_L_R) * 0.33;
                }else
                {
                    Prev.Duty_N_L = Duty_N_L_R + abs(Prev.Duty_L_R) * 0.33;
                }
            }
        }else if(Identify_Track_Status == 1 && abs(Average_GDPC_Bend) <= 10)
        {
            if(abs(Prev.Duty_L_R) > 10)
            {
                if(Prev.Gyro_Z > 0)
                {
                    Prev.Duty_N_R = Duty_N_L_R + abs(Prev.Duty_L_R) * 0.33;
                }else
                {
                    Prev.Duty_N_L = Duty_N_L_R + abs(Prev.Duty_L_R) * 0.33;
                }
            }
        }
    }else if(Identify_Track_Selection == 4 || Identify_Track_Selection == 5)
    {
        if(abs(Average_GDPC_Bend) >= 10)
        {
            if(abs(Prev.Duty_L_R) < 50)
            {
                if(Prev.Duty_B_L - Prev.Duty_B_R > 0)
                {
                    Prev.Duty_L_R = Prev.Duty_L_R + (Prev.Duty_B_L - Prev.Duty_B_R) * 1.5;
                }else
                {
                    Prev.Duty_L_R = Prev.Duty_L_R + (Prev.Duty_B_L - Prev.Duty_B_R) * 1.5;
                }
                if(Prev.Duty_L_R >= 50)
                {
                    Prev.Duty_L_R = 50;
                }else if(Prev.Duty_L_R <= -50)
                {
                    Prev.Duty_L_R = -50;
                }
            }
        }
    }
}

void Duty_Limitation(void)
{
    if(Identify_Track_Selection == 1)
    {
        if(Identify_Track_Status == 0 || Identify_Track_Status == 2)
        {
            if(Prev.Duty_L_R > Cross_GDPC_Straightaway_Pid.OutMax)
            {
                Prev.Duty_L_R = Cross_GDPC_Straightaway_Pid.OutMax;
            }else if(Prev.Duty_L_R < Cross_GDPC_Straightaway_Pid.OutMin)
            {
                Prev.Duty_L_R = Cross_GDPC_Straightaway_Pid.OutMin;
            }
        }else if(Identify_Track_Status == 1 && abs(Average_GDPC_Bend) < 10)
        {
            if(Prev.Duty_L_R > Cross_GDPC_Straightaway_Pid.OutMax)
            {
                Prev.Duty_L_R = Cross_GDPC_Straightaway_Pid.OutMax;
            }else if(Prev.Duty_L_R < Cross_GDPC_Straightaway_Pid.OutMin)
            {
                Prev.Duty_L_R = Cross_GDPC_Straightaway_Pid.OutMin;
            }
        }else if(Identify_Track_Selection == 1 && abs(Average_GDPC_Bend) >= 10)
        {
            if(Prev.Duty_L_R > Cross_GDPC_Straightaway_Bend_Pid.OutMax)
            {
                Prev.Duty_L_R = Cross_GDPC_Straightaway_Bend_Pid.OutMax;
            }else if(Prev.Duty_L_R < Cross_GDPC_Straightaway_Bend_Pid.OutMin)
            {
                Prev.Duty_L_R = Cross_GDPC_Straightaway_Bend_Pid.OutMin;
            }
        }
    }else if(Identify_Track_Selection == 4)
    {
        if(Prev.Duty_L_R > Track_NULL_GDPC_Straightaway_Pid.OutMax)
        {
            Prev.Duty_L_R = Track_NULL_GDPC_Straightaway_Pid.OutMax;
        }else if(Prev.Duty_L_R < Track_NULL_GDPC_Straightaway_Pid.OutMin)
        {
            Prev.Duty_L_R = Track_NULL_GDPC_Straightaway_Pid.OutMin;
        }
    }else if(Identify_Track_Selection == 3 || Identify_Track_Selection == 5)
    {
        if(Prev.Duty_L_R > Roundabout_GDPC_Straightaway_Pid.OutMax)
        {
            Prev.Duty_L_R = Roundabout_GDPC_Straightaway_Pid.OutMax;
        }else if(Prev.Duty_L_R < Roundabout_GDPC_Straightaway_Pid.OutMin)
        {
            Prev.Duty_L_R = Roundabout_GDPC_Straightaway_Pid.OutMin;
        }
    }
}

void S_Bend_Start_Return_To_The_Center(void)
{
    if(Original_L_Line[119] > 75)
    {
        Prev.Duty_L_R = 20 + Original_L_Line[119] - 90 + 10;
    }
    if(Original_R_Line[119] < 115)
    {
        Prev.Duty_L_R = -20 + Original_R_Line[119] - 100 - 10;
    }
}

void Adjust_Not_Brush_To_Restore_Vehicle_Structural_Balance(void)
{
    if(Identify_Track_Selection == 2)
    {
        //Prev.Duty_N_R += 10;
    }else if(Identify_Track_Selection == 1 && Identify_Track_Status == 1)
    {
        if(R_Far_Lost > L_Far_Lost || (R_Lost - R_Far_Lost - R_Near_Lost) - (L_Lost - L_Far_Lost - L_Near_Lost) > 0)
        {
            Prev.Duty_N_R += 10;
        }else
        {
            Prev.Duty_N_R += 15;
        }
        if(abs(Prev.Duty_L_R) > 20)
        {
            Prev.Duty_L_R *= 2.0;
            if(Prev.Duty_L_R > 50)
            {
                Prev.Duty_L_R = 50;
            }
            if(Prev.Duty_L_R < -50)
            {
                Prev.Duty_L_R = -50;
            }
        }
    }

    if(Identify_Track_Selection == 4)
    {
        if(abs(Prev.Duty_L_R) >= 60 && (Prev.Duty_N_L >= 70 || Prev.Duty_N_R >= 70))
        {
            Prev.Duty_N_L -= (abs(Prev.Duty_L_R) - 60) * 0.66;
            Prev.Duty_N_R -= (abs(Prev.Duty_L_R) - 60) * 0.66;
            if(Prev.Duty_N_L < 60)
            {
                Prev.Duty_N_L = 60;
            }
            if(Prev.Duty_N_R < 60)
            {
                Prev.Duty_N_R = 60;
            }
        }
    }

    if(Identify_Track_Selection == 3 || Identify_Track_Selection == 5)
    {
        if(abs(Prev.Duty_L_R) >= 60 && abs(Prev.Duty_L_R) <= 70)
        {
            Prev.Duty_N_L -= (abs(Prev.Duty_L_R) - 60) * 0.99;
            Prev.Duty_N_R -= (abs(Prev.Duty_L_R) - 60) * 0.99;
            if(Prev.Duty_N_L < 70)
            {
                Prev.Duty_N_L = 70;
            }
            if(Prev.Duty_N_R < 70)
            {
                Prev.Duty_N_R = 70;
            }
        }else if(abs(Prev.Duty_L_R) > 70)
        {
            Prev.Duty_N_L -= (abs(Prev.Duty_L_R) - 60) * 0.99;
            Prev.Duty_N_R -= (abs(Prev.Duty_L_R) - 60) * 0.99;
            if(Prev.Duty_N_L < 60)
            {
                Prev.Duty_N_L = 60;
            }
            if(Prev.Duty_N_R < 60)
            {
                Prev.Duty_N_R = 60;
            }
        }
    }

}

void Extreme_Assistance(void)
{
    if(Extreme_Assistance_Start_Flag != 0)
    {
        return;
    }
    int Temp_L = 0, Temp_R = 0;
    for(uint8 i = 105; i < MT9V03X_H; i++)
    {
        Temp_L += Original_L_Line[i];
        Temp_R += Original_R_Line[i];
    }
    Temp_L /= 15;
    Temp_R /= 15;
    if(Temp_L > 105)
    {
        Buzzer_On();
        Extreme_Assistance_Start_Flag = 1;
    }
    if(Temp_R < 85)
    {
        Buzzer_On();
        Extreme_Assistance_Start_Flag = 2;
    }
}

void Extreme_Assistance_End(void)
{
    if(Extreme_Assistance_Start_Flag == 0)
    {
        return;
    }
    if(Extreme_Assistance_Start_Flag == 1)
    {
        int Temp_L = 0;
        for(uint8 i = 105; i < MT9V03X_H; i++)
        {
            Temp_L += Original_L_Line[i];
        }
        Temp_L /= 15;
        if(Temp_L < 70)
        {
            Buzzer_Off();
            Extreme_Assistance_Start_Flag = 0;
        }
    }else if(Extreme_Assistance_Start_Flag == 2)
    {
        int Temp_R = 0;
        for(uint8 i = 105; i < MT9V03X_H; i++)
        {
            Temp_R += Original_R_Line[i];
        }
        Temp_R /= 15;
        if(Temp_R > 100)
        {
            Buzzer_Off();
            Extreme_Assistance_Start_Flag = 0;
        }
    }
}

void Re_Set_PID_All(void)
{
    PID_SetTarget(&Straightaway_Speed_Pid, 300 + Key_Up_Straightaway_Data);//330
    PID_SetTarget(&Cross_Speed_Pid, 280 + Key_Down_Cross_Data);//280
    PID_SetTarget(&S_Bend_Speed_Pid, 280 + Key_Left_S_Bend_Data);//160
    PID_SetTarget(&Roundabout_Speed_Pid, 230 + Key_Right_Roundabout_Data);//160
    PID_SetTarget(&Track_NULL_Speed_Pid, 200 + Key_Middle_NULL_Track_Data);//170
    if(Left_Roundabout_Identify_Number == 0 && Right_Roundabout_Identify_Number == 0)
    {
        if(Left_Avoid_Obstacles_Identify_Number == 0 && Right_Avoid_Obstacles_Identify_Number == 0)
        {
            PID_SetTarget(&Straightaway_Speed_Pid, 300 + Key_Up_Straightaway_Data + Straightaway_Speed_Pro_End);//330
            PID_SetTarget(&Cross_Speed_Pid, 280 + Key_Down_Cross_Data + Cross_Speed_Pro_End);//280
            PID_SetTarget(&S_Bend_Speed_Pid, 280 + Key_Left_S_Bend_Data + S_Bend_Speed_Pro_End);//160
            PID_SetTarget(&Roundabout_Speed_Pid, 230 + Key_Right_Roundabout_Data + Roundabout_Speed_Pro_End);//160
            PID_SetTarget(&Track_NULL_Speed_Pid, 200 + Key_Middle_NULL_Track_Data + NULL_Track_Speed_Pro_End);//170
        }
    }
    if(Identify_Track_Selection == 4)
    {
        MFPP = Fuzzy_P(Track_NULL_GDPC_Straightaway_Pid.Error, Track_NULL_GDPC_Straightaway_Pid.Error - Track_NULL_GDPC_Straightaway_Pid.PrevError,0);
        MFPI = Fuzzy_P(Track_NULL_GDPC_Straightaway_Pid.Error, Track_NULL_GDPC_Straightaway_Pid.Error - Track_NULL_GDPC_Straightaway_Pid.PrevError,2);
        MFLP = Fuzzy_P(Track_NULL_GDPC_Bend_Pid.Error, Track_NULL_GDPC_Bend_Pid.Error - Track_NULL_GDPC_Bend_Pid.PrevError,1);
        MFLI = Fuzzy_P(Track_NULL_GDPC_Bend_Pid.Error, Track_NULL_GDPC_Bend_Pid.Error - Track_NULL_GDPC_Bend_Pid.PrevError,3);
        MFPI = 0.66;
        MFLI = 0.66;
        PID_SetParam(&Track_NULL_GDPC_Straightaway_Pid, MFPP, MFPI, 1);
        PID_SetParam(&Track_NULL_GDPC_Bend_Pid, MFLP, MFLI, 1);
    }
    if(Identify_Track_Selection == 3 || Identify_Track_Selection == 5)
    {
        float temp1 = 0, temp2 = 0;
        temp1 = Fuzzy_P(Roundabout_GDPC_Straightaway_Pid.Error, Roundabout_GDPC_Straightaway_Pid.Error - Roundabout_GDPC_Straightaway_Pid.PrevError, 0);
        temp2 = Fuzzy_P(Roundabout_GDPC_Bend_Pid.Error, Roundabout_GDPC_Bend_Pid.Error - Roundabout_GDPC_Bend_Pid.PrevError, 1);
        PID_SetParam(&Roundabout_GDPC_Straightaway_Pid, temp1, 0.66, 1);
        PID_SetParam(&Roundabout_GDPC_Bend_Pid, temp2, 0.66, 1);
    }
}

void Re_Set_PID_NULL_Track_Integral(void)
{
    PID_SetThreshold(&Track_NULL_GDPC_Straightaway_Pid, 80 + Key_NULL_Track_Integral, -80 - Key_NULL_Track_Integral);
    PID_SetThreshold(&Track_NULL_GDPC_Bend_Pid, 80 + Key_NULL_Track_Integral, -80 - Key_NULL_Track_Integral);
}

void Ultimate_Power_Distribution(void)
{
    /*for(uint8 i = MT9V03X_H - 12; i > 5; i--)
    {
        if(Original_L_Line[i] == 255)
        {
            continue;
        }
        if(Original_L_Line[i] == 0)
        {
            break;
        }
        if(Original_L_Line[i] - Original_L_Line[i + 1] >= 0 &&
                Original_L_Line[i] - Original_L_Line[i + 2] >= 0 &&
                Original_L_Line[i] - Original_L_Line[i + 3] >= 0 &&
                Original_L_Line[i] - Original_L_Line[i + 4] >= 0 &&
                Original_L_Line[i] - Original_L_Line[i - 3] >= 20 &&
                Original_L_Line[i] - Original_L_Line[i - 4] >= 20 &&
                Original_L_Line[i] - Original_L_Line[i - 5] >= 20 &&
                Original_L_Line[i] - Original_L_Line[i - 6] >= 20 &&
                Original_L_Line[0] != 255 && abs(94 - Original_R_Line[0]) < 50)
        {
            return;
        }
    }
    for(uint8 i = MT9V03X_H - 12; i > 5; i--)
    {
        if(Original_R_Line[i] == 0)
        {
            continue;
        }
        if(Original_R_Line[i] == MT9V03X_W - 1)
        {
            break;
        }
        if(Original_R_Line[i] - Original_R_Line[i + 1] <= 0 &&
                Original_R_Line[i] - Original_R_Line[i + 2] <= 0 &&
                Original_R_Line[i] - Original_R_Line[i + 3] <= 0 &&
                Original_R_Line[i] - Original_R_Line[i + 4] <= 0 &&
                Original_R_Line[i] - Original_R_Line[i - 1] <= -20 &&
                Original_R_Line[i] - Original_R_Line[i - 2] <= -20 &&
                Original_R_Line[i] - Original_R_Line[i - 3] <= -20 &&
                Original_R_Line[i] - Original_R_Line[i - 4] <= -20 &&
                Original_L_Line[0] != 255 && abs(94 - Original_L_Line[0]) < 50)
        {
            return;
        }
    }*/
//    if(abs(AO_Count) > 10 && abs(AO_Count) < 30 && abs(AO_Count_Uppre) > 5 && abs(AO_Count_Uppre) < 15)
//    {
//        return;
//    }
//    if(L_Lost - L_Far_Lost - L_Near_Lost == 0 && R_Lost - R_Far_Lost - R_Near_Lost == 0)
//    {
//        PID_SetTarget(&Track_NULL_Speed_Pid, 230 + Key_Middle_NULL_Track_Data);//170
//    }
    /*if(abs(94 - Original_L_Line[0]) < 50 && abs(Original_R_Line[0] - 94) < 50)
    {
        PID_SetTarget(&Track_NULL_Speed_Pid, 230 + Key_Middle_NULL_Track_Data);//170
    }*/
    /*Break_Point_Number = 0;
    if(Original_L_Line[0] == 255)
    {
        PID_SetTarget(&Track_NULL_Speed_Pid, 230 + Key_Middle_NULL_Track_Data);
    }else
    {
        Break_Point_Number = Break_Point_NULL_Track();
        if(Break_Point_Number)
        {
            PID_SetTarget(&Track_NULL_Speed_Pid, 230 + Key_Middle_NULL_Track_Data + Break_Point_Number * 1);
        }else
        {
            if(abs(94 - Original_L_Line[0]) < 50 && abs(Original_R_Line[0] - 94) < 50)
            {
                PID_SetTarget(&Track_NULL_Speed_Pid, 230 + Key_Middle_NULL_Track_Data);//170
            }
        }
    }*/
    LARCMCLP_Number = Left_And_Right_Contact_Min_Coincidence_Line_Point();
    if(LARCMCLP_Number < 50)
    {
        PID_SetTarget(&Track_NULL_Speed_Pid, 200 + Key_Middle_NULL_Track_Data + LARCMCLP_Number * 0.45);
    }else if(LARCMCLP_Number < 80)
    {
        PID_SetTarget(&Track_NULL_Speed_Pid, 200 + Key_Middle_NULL_Track_Data + LARCMCLP_Number * 0.75);
    }else
    {
        PID_SetTarget(&Track_NULL_Speed_Pid, 200 + Key_Middle_NULL_Track_Data + LARCMCLP_Number * 1.05);
    }
    if(Left_Roundabout_Identify_Number == 0 && Right_Roundabout_Identify_Number == 0)
    {
        if(Left_Avoid_Obstacles_Identify_Number == 0 && Right_Avoid_Obstacles_Identify_Number == 0)
        {
            if(LARCMCLP_Number < 50)
            {
                PID_SetTarget(&Track_NULL_Speed_Pid, 200 + Key_Middle_NULL_Track_Data + LARCMCLP_Number * 0.45 + NULL_Track_Speed_Pro_End);
            }else if(LARCMCLP_Number < 80)
            {
                PID_SetTarget(&Track_NULL_Speed_Pid, 200 + Key_Middle_NULL_Track_Data + LARCMCLP_Number * 0.75 + NULL_Track_Speed_Pro_End);
            }else
            {
                PID_SetTarget(&Track_NULL_Speed_Pid, 200 + Key_Middle_NULL_Track_Data + LARCMCLP_Number * 1.05 + NULL_Track_Speed_Pro_End);
            }
        }
    }
}

void Dynamic_Condition_PID(void)
{
    if(Identify_Track_Selection == 4 && Average_Speed > 185)
    {
        if(Original_L_Line[0] == 255)
        {
            PID_SetParam(&Track_NULL_GDPC_Straightaway_Pid, 1 + (Average_Speed - 170) * 0.01, 0.5, 1);
            PID_SetTarget(&Track_NULL_GDPC_Straightaway_Pid, 0);
            PID_SetIntegral(&Track_NULL_GDPC_Straightaway_Pid, 20, -20);
            PID_SetThreshold(&Track_NULL_GDPC_Straightaway_Pid, 100, -100);

            PID_SetParam(&Track_NULL_GDPC_Bend_Pid, 1 + (Average_Speed - 170) * 0.01, 0.5, 1);
            PID_SetTarget(&Track_NULL_GDPC_Bend_Pid, 0);
            PID_SetIntegral(&Track_NULL_GDPC_Bend_Pid, 40, -40);
            PID_SetThreshold(&Track_NULL_GDPC_Bend_Pid, 100, -100);
        }else
        {
            PID_SetParam(&Track_NULL_GDPC_Straightaway_Pid, 1 + (Average_Speed - 170) * 0.015, 0.5, 1);
            PID_SetTarget(&Track_NULL_GDPC_Straightaway_Pid, 0);
            PID_SetIntegral(&Track_NULL_GDPC_Straightaway_Pid, 20, -20);
            PID_SetThreshold(&Track_NULL_GDPC_Straightaway_Pid, 100, -100);

            PID_SetParam(&Track_NULL_GDPC_Bend_Pid, 1 + (Average_Speed - 170) * 0.005, 0.5, 1);
            PID_SetTarget(&Track_NULL_GDPC_Bend_Pid, 0);
            PID_SetIntegral(&Track_NULL_GDPC_Bend_Pid, 40, -40);
            PID_SetThreshold(&Track_NULL_GDPC_Bend_Pid, 100, -100);
        }
    }
}

uint8 Break_Point_NULL_Track(void)
{
    uint8 Ans = 0;
    for(uint8 i = MT9V03X_H - 5; i > 5; i--)
    {
        if(abs(Midcourt_Line[i] - Midcourt_Line[i - 1]) > 5)
        {
            Ans = abs(Midcourt_Line[i] - Midcourt_Line[i - 1]);
            for(uint8 j = i + 15; j < MT9V03X_H - 15; j++)
            {
                if(Original_L_Line[j] - Original_L_Line[j + 1] < 0)
                {
                    return 0;
                }
            }
            for(uint8 k = i + 15; k < MT9V03X_H - 15; k++)
            {
                if(Original_R_Line[k] - Original_R_Line[k + 1] > 0)
                {
                    return 0;
                }
            }
        }
    }
    if(Ans == 0)
    {
        return 0;
    }
    return Ans;
}

uint8 Left_And_Right_Contact_Min_Coincidence_Line_Point(void)
{
    uint8 Count_Left = 0, Count_Right = 0;
    for(uint8 i = MT9V03X_H - 2; i > 10; i--)
    {
        if(Original_L_Line[i] == 255 || Original_L_Line[i] == 0)
        {
            break;
        }
        if(Original_L_Line[i] - Original_L_Line[i + 1] >= 0)
        {
            Count_Left++;
        }else
        {
            break;
        }
    }
    for(uint8 j = MT9V03X_H - 2; j > 10; j--)
    {
        if(Original_R_Line[j] == 0 || Original_R_Line[j] == MT9V03X_W - 1)
        {
            break;
        }
        if(Original_R_Line[j] - Original_R_Line[j + 1] <= 0)
        {
            Count_Right++;
        }else
        {
            break;
        }
    }
    if(Count_Left <= Count_Right)
    {
        return Count_Left;
    }
    return Count_Right;
}

void Limit_Difference_All_Track(void)
{

}



float Fuzzy_P(float E,float EC,uint8 choose)
{


    //ֻҪ�������⼸�в���
    //������ûʲô���ɣ�pԽ��ת��Խ�ã�ֱ�����ж�����pСת��������ƾ�о���
    //�������õ���pd����������������p�����ʲô��Χ�������p�ͻ��з���
    float EFF[7]={-55, -35, -25, 0, 25, 35, 55};//����ͷ������
//    /*������D����ֵ������*/
    float DFF[7]={-80, -60, -20, 0, 20, 60, 80};//���仯�ʷ���
//    /*�����U����ֵ������(������������ѡ��ͬ�����ֵ)*/
    float UFF[7]={0.855, 1.555, 1.75, 1.955, 2.35, 2.55, 3};//�޷�����

    if(Identify_Track_Selection == 4)
    {
        if(choose == 0)
        {
            EFF[0] = -30;
            EFF[1] = -20;
            EFF[2] = -10;
            EFF[3] = 0;
            EFF[4] = 10;
            EFF[5] = 20;
            EFF[6] = 30;

            DFF[0] = -60;
            DFF[1] = -40;
            DFF[2] = -20;
            DFF[3] = 0;
            DFF[4] = 20;
            DFF[5] = 40;
            DFF[6] = 60;

            UFF[0] = 0.142;
            UFF[1] = 0.259;
            UFF[2] = 0.291;
            UFF[3] = 0.325;
            UFF[4] = 0.391;
            UFF[5] = 0.425;
            UFF[6] = 0.5;
        }else if(choose == 1)
        {
            EFF[0] = -45;
            EFF[1] = -30;
            EFF[2] = -15;
            EFF[3] = 0;
            EFF[4] = 15;
            EFF[5] = 30;
            EFF[6] = 45;

            DFF[0] = -90;
            DFF[1] = -60;
            DFF[2] = -30;
            DFF[3] = 0;
            DFF[4] = 30;
            DFF[5] = 60;
            DFF[6] = 90;

            UFF[0] = 0.142;
            UFF[1] = 0.259;
            UFF[2] = 0.291;
            UFF[3] = 0.325;
            UFF[4] = 0.391;
            UFF[5] = 0.425;
            UFF[6] = 0.5;
        }else if(choose == 2)
        {
            EFF[0] = -30;
            EFF[1] = -20;
            EFF[2] = -10;
            EFF[3] = 0;
            EFF[4] = 10;
            EFF[5] = 20;
            EFF[6] = 30;

            DFF[0] = -60;
            DFF[1] = -40;
            DFF[2] = -20;
            DFF[3] = 0;
            DFF[4] = 20;
            DFF[5] = 40;
            DFF[6] = 60;

            UFF[0] = 0.142;
            UFF[1] = 0.259;
            UFF[2] = 0.291;
            UFF[3] = 0.325;
            UFF[4] = 0.391;
            UFF[5] = 0.425;
            UFF[6] = 0.5;
        }else if(choose == 3)
        {
            EFF[0] = -45;
            EFF[1] = -30;
            EFF[2] = -15;
            EFF[3] = 0;
            EFF[4] = 15;
            EFF[5] = 30;
            EFF[6] = 45;

            DFF[0] = -90;
            DFF[1] = -60;
            DFF[2] = -30;
            DFF[3] = 0;
            DFF[4] = 30;
            DFF[5] = 60;
            DFF[6] = 90;

            UFF[0] = 0.142;
            UFF[1] = 0.259;
            UFF[2] = 0.291;
            UFF[3] = 0.325;
            UFF[4] = 0.391;
            UFF[5] = 0.425;
            UFF[6] = 0.5;
        }
    }else if(Identify_Track_Selection == 3 || Identify_Track_Selection == 5)
    {
        if(choose == 0)
        {
            EFF[0] = -30;
            EFF[1] = -20;
            EFF[2] = -10;
            EFF[3] = 0;
            EFF[4] = 10;
            EFF[5] = 20;
            EFF[6] = 30;

            DFF[0] = -60;
            DFF[1] = -40;
            DFF[2] = -20;
            DFF[3] = 0;
            DFF[4] = 20;
            DFF[5] = 40;
            DFF[6] = 60;

            UFF[0] = 0.142;
            UFF[1] = 0.259;
            UFF[2] = 0.291;
            UFF[3] = 0.325;
            UFF[4] = 0.391;
            UFF[5] = 0.425;
            UFF[6] = 0.5;
        }else if(choose == 1)
        {
            EFF[0] = -30;
            EFF[1] = -20;
            EFF[2] = -10;
            EFF[3] = 0;
            EFF[4] = 10;
            EFF[5] = 20;
            EFF[6] = 30;

            DFF[0] = -60;
            DFF[1] = -40;
            DFF[2] = -20;
            DFF[3] = 0;
            DFF[4] = 20;
            DFF[5] = 40;
            DFF[6] = 60;

            UFF[0] = 0.142;
            UFF[1] = 0.259;
            UFF[2] = 0.291;
            UFF[3] = 0.325;
            UFF[4] = 0.391;
            UFF[5] = 0.425;
            UFF[6] = 0.5;
        }
    }



//ֻҪ�������⼸�в���


    int rule[7][7]={
    //    0   1   2   3   4   5   6
        { 6 , 5 , 4 , 3 , 2 , 1 , 0},//0
        { 5 , 4 , 3 , 2 , 1 , 0 , 1},//1
        { 4 , 3 , 2 , 1 , 0 , 1 , 2},//2
        { 3 , 2 , 1 , 0 , 1 , 2 , 3},//3
        { 2 , 1 , 0 , 1 , 2 , 3 , 4},//4
        { 1 , 0 , 1 , 2 , 3 , 4 , 5},//5
        { 0 , 1 , 2 , 3 , 4 , 5 , 6},//6
    };



    /*�����ȵ�ȷ��*/
    /*����PD��ָ������ֵ�����Ч������*/
    if((E>(*(EFF+0))) && (E<(*(EFF+6))))
    {
        if(E<=((*(EFF+1))))
        {
            Pn=-2;
            *(PF+0)=((*(EFF+1))-E)/((*(EFF+1))-((*(EFF+0))));
        }
        else if(E<=((*(EFF+2))))
        {
            Pn=-1;
            *(PF+0)=((*(EFF+2))-E)/((*(EFF+2))-(*(EFF+1)));
        }
        else if(E<=((*(EFF+3))))
        {
            Pn=0;
            *(PF+0)=((*(EFF+3))-E)/((*(EFF+3))-(*(EFF+2)));
        }
        else if(E<=((*(EFF+4))))
        {
            Pn=1;
            *(PF+0)=((*(EFF+4))-E)/((*(EFF+4))-(*(EFF+3)));
        }
        else if(E<=((*(EFF+5))))
        {
            Pn=2;
            *(PF+0)=((*(EFF+5))-E)/((*(EFF+5))-(*(EFF+4)));
        }
        else if(E<=((*(EFF+6))))
        {
            Pn=3;
            *(PF+0)=((*(EFF+6))-E)/((*(EFF+6))-(*(EFF+5)));
        }
    }

    else if(E<=((*(EFF+0))))
    {
        Pn=-2;
        *(PF+0)=1;
    }
    else if(E>=((*(EFF+6))))
    {
        Pn=3;
        *(PF+0)=0;
    }

   *(PF+1)=1-(*(PF+0));


    //�ж�D��������
    if(EC>(*(DFF+0))&&EC<(*(DFF+6)))
    {
        if(EC<=(*(DFF+1)))
        {
            Dn=-2;
            (*(DF+0))=((*(DFF+1))-EC)/((*(DFF+1))-(*(DFF+0)));
        }
        else if(EC<=(*(DFF+2)))
        {
            Dn=-1;
            (*(DF+0))=((*(DFF+2))-EC)/((*(DFF+2))-(*(DFF+1)));
        }
        else if(EC<=(*(DFF+3)))
        {
            Dn=0;
            (*(DF+0))=((*(DFF+3))-EC)/((*(DFF+3))-(*(DFF+2)));
        }
        else if(EC<=(*(DFF+4)))
        {
            Dn=1;
            (*(DF+0))=((*(DFF+4))-EC)/((*(DFF+4))-(*(DFF+3)));
        }
        else if(EC<=(*(DFF+5)))
        {
            Dn=2;
            (*(DF+0))=((*(DFF+5))-EC)/((*(DFF+5))-(*(DFF+4)));
        }
        else if(EC<=(*(DFF+6)))
        {
            Dn=3;
            (*(DF+0))=((*(DFF+6))-EC)/((*(DFF+6))-(*(DFF+5)));
        }
    }
    //���ڸ�����������
    else if (EC<=(*(DFF+0)))
    {
        Dn=-2;
        (*(DF+0))=1;
    }
    else if(EC>=(*(DFF+6)))
    {
        Dn=3;
        (*(DF+0))=0;
    }

    DF[1]=1-(*(DF+0));

    /*ʹ����Χ�Ż���Ĺ����rule[7][7]*/
    /*���ֵʹ��13����������,����ֵ��UFF[7]ָ��*/
    /*һ�㶼���ĸ�������Ч*/
    Un[0]=rule[Pn+2][Dn+2];
    Un[1]=rule[Pn+3][Dn+2];
    Un[2]=rule[Pn+2][Dn+3];
    Un[3]=rule[Pn+3][Dn+3];

    if((*(PF+0))<=(*(DF+0)))    //��С
        (*(UF+0))=*(PF+0);
    else
        (*(UF+0))=(*(DF+0));
    if((*(PF+1))<=(*(DF+0)))
        (*(UF+1))=*(PF+1);
    else
        (*(UF+1))=(*(DF+0));
    if((*(PF+0))<=DF[1])
        (*(UF+2))=*(PF+0);
    else
        (*(UF+2))=DF[1];
    if((*(PF+1))<=DF[1])
        (*(UF+3))=*(PF+1);
    else
        (*(UF+3))=DF[1];
    /*ͬ���������������ֵ���*/
    if(Un[0]==Un[1])
    {
        if(((*(UF+0)))>((*(UF+1))))
            (*(UF+1))=0;
        else
            (*(UF+0))=0;
    }
    if(Un[0]==Un[2])
    {
        if(((*(UF+0)))>((*(UF+2))))
            (*(UF+2))=0;
        else
            (*(UF+0))=0;
    }
    if(Un[0]==Un[3])
    {
        if((*(UF+0))>(*(UF+3)))
            (*(UF+3))=0;
        else
            (*(UF+0))=0;
    }
    if(Un[1]==Un[2])
    {
        if((*(UF+1))>(*(UF+2)))
            (*(UF+2))=0;
        else
            (*(UF+1))=0;
    }
    if(Un[1]==Un[3])
    {
        if((*(UF+1))>(*(UF+3)))
            (*(UF+3))=0;
        else
            (*(UF+1))=0;
    }
    if(Un[2]==Un[3])
    {
        if((*(UF+2))>(*(UF+3)))
            (*(UF+3))=0;
        else
            (*(UF+2))=0;
    }
    t1=((*(UF+0)))*(*(UFF+(*(Un+0))));
    t2=((*(UF+1)))*(*(UFF+(*(Un+1))));
    t3=((*(UF+2)))*(*(UFF+(*(Un+2))));
    t4=((*(UF+3)))*(*(UFF+(*(Un+3))));
    temp1=t1+t2+t3+t4;
    temp2=(*(UF+0))+(*(UF+1))+(*(UF+2))+(*(UF+3));//ģ�������
    U=temp1/temp2;
    return U;
}

void Show_Error_And_PrevError(void)
{
    Error = Track_NULL_GDPC_Straightaway_Pid.Error;
    PrevError = Track_NULL_GDPC_Bend_Pid.Error;
}

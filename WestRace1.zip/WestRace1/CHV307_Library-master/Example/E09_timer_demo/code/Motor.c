/*
 * Motor.c
 *
 *  Created on: Apr 1, 2024
 *      Author: guo
 */

#include "zf_common_headfile.h"
#include "PID.h"

void Motor_Brush(uint8 choose, int data);
void Motor_Not_Brush(uint8 choose, int data);

uint8 Motor_Protect_Download(void);
void Motor_Protect_Download_Duty(void);

int Test_L_R = 0, Test_B_L = 0, Test_B_R = 0;
int Test_N_L = 0, Test_N_R = 0;

void Motor_Init(void)
{
    gpio_init(E0, GPO, GPIO_LOW, GPO_PUSH_PULL);
    gpio_init(E1, GPO, GPIO_LOW, GPO_PUSH_PULL);
    gpio_init(E2, GPO, GPIO_LOW, GPO_PUSH_PULL);
    gpio_init(E3, GPO, GPIO_LOW, GPO_PUSH_PULL);
    //pwm_init(TIM4_PWM_MAP1_CH1_D12, 17000, 0);
    pwm_init(TIM4_PWM_MAP1_CH2_D13, 17000, 0);
    pwm_init(TIM4_PWM_MAP1_CH3_D14, 17000, 0);
    //pwm_init(TIM4_PWM_MAP1_CH4_D15, 17000, 0);

    pwm_init(TIM1_PWM_MAP3_CH2_E11, 300, 10);
    pwm_init(TIM1_PWM_MAP3_CH4_E14, 300, 10);
    pwm_init(TIM1_PWM_MAP3_CH3_E13, 300, 10);
    pwm_init(TIM10_PWM_MAP3_CH3_D5, 300, 10);
}

void Motor_Control(void)
{
    if(Motor_Protect_Download() == 1)
    {
        return;
    }
    Motor_Not_Brush(0, Duty_N_L);
    Motor_Not_Brush(1, Duty_N_R);
    Motor_Brush(0, Duty_L_R);
    Motor_Brush(3, Duty_L_R);
    Motor_Brush(1, Duty_B_L);
    Motor_Brush(2, Duty_B_R);
}

void Motor_Test_Control(void)
{
    Motor_Not_Brush(0, Test_N_L);
    Motor_Not_Brush(1, Test_N_R);
    Motor_Brush(0, Test_L_R);
    Motor_Brush(3, Test_L_R);
    Motor_Brush(1, Test_B_L);
    Motor_Brush(2, Test_B_R);
}

void Motor_Brush(uint8 choose, int data)
{
    if(choose == 0 || choose == 3)
    {
        if(data >= 100)
            data = 100;
        if(data <= -100)
            data = -100;
        int Duty = abs(data) * 25 + 3500;
        if(data > 0)
        {
            pwm_set_duty(TIM10_PWM_MAP3_CH3_D5, Duty);
            pwm_set_duty(TIM1_PWM_MAP3_CH3_E13, 3500);
        }else
        {
            pwm_set_duty(TIM10_PWM_MAP3_CH3_D5, 3500);
            pwm_set_duty(TIM1_PWM_MAP3_CH3_E13, Duty);
        }
    }else if(choose == 1 || choose == 2)
    {
        if(data >= 100)
            data = 100;
        if(data <= -100)
            data = -100;
        int Duty = 60 * data;
        if(choose == 1)
        {
            if(Duty >= 0)
            {
                gpio_set_level(E1, 0);
                pwm_set_duty(TIM4_PWM_MAP1_CH2_D13, Duty);
            }else
            {
                gpio_set_level(E1, 1);
                pwm_set_duty(TIM4_PWM_MAP1_CH2_D13, -Duty);
            }
        }else if(choose == 2)
        {
            if(Duty >= 0)
            {
                gpio_set_level(E2, 1);
                pwm_set_duty(TIM4_PWM_MAP1_CH3_D14, Duty);
            }else
            {
                gpio_set_level(E2, 0);
                pwm_set_duty(TIM4_PWM_MAP1_CH3_D14, -Duty);
            }
        }
    }
}

void Motor_Not_Brush(uint8 choose, int data)
{
    if(data >= 100)
        data = 100;
    if(data <= 0)
        data = 0;
    int Duty = data * 25 + 3500;
    if(choose == 0)
    {
        if(Duty >= 0)
        {
            pwm_set_duty(TIM1_PWM_MAP3_CH2_E11, Duty);
        }else
        {
            pwm_set_duty(TIM1_PWM_MAP3_CH2_E11, -Duty);
        }
    }else if(choose == 1)
    {
        if(Duty >= 0)
        {
            pwm_set_duty(TIM1_PWM_MAP3_CH4_E14, Duty);
        }else
        {
            pwm_set_duty(TIM1_PWM_MAP3_CH4_E14, -Duty);
        }
    }
}

void Motor_Start_Protect(void)
{
    Duty_N_L_R += 20;
    Motor_Not_Brush(0, Duty_N_L_R);
    Motor_Not_Brush(1, Duty_N_L_R);

    system_delay_ms(2000);
}

uint8 Motor_Protect_Download(void)
{
    if(gpio_get_level(B0) == 1)
    {
        return 0;
    }
    Motor_Protect_Download_Duty();
    return 1;
}

void Motor_Protect_Download_Duty(void)
{
    pwm_set_duty(TIM1_PWM_MAP3_CH2_E11, 0);
    pwm_set_duty(TIM1_PWM_MAP3_CH4_E14, 0);
    Motor_Brush(0, 0);
    Motor_Brush(3, 0);
    Motor_Brush(1, 0);
    Motor_Brush(2, 0);
}

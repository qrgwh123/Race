/*********************************************************************************************************************
* CH32V307VCT6 Opensourec Library ����CH32V307VCT6 ��Դ�⣩��һ�����ڹٷ� SDK �ӿڵĵ�������Դ��
* Copyright (c) 2022 SEEKFREE ��ɿƼ�
*
* ���ļ���CH32V307VCT6 ��Դ���һ����
*
* CH32V307VCT6 ��Դ�� ���������
* �����Ը���������������ᷢ���� GPL��GNU General Public License���� GNUͨ�ù�������֤��������
* �� GPL �ĵ�3�棨�� GPL3.0������ѡ��ģ��κκ����İ汾�����·�����/���޸���
*
* ����Դ��ķ�����ϣ�����ܷ������ã�����δ�������κεı�֤
* ����û�������������Ի��ʺ��ض���;�ı�֤
* ����ϸ����μ� GPL
*
* ��Ӧ�����յ�����Դ���ͬʱ�յ�һ�� GPL �ĸ���
* ���û�У������<https://www.gnu.org/licenses/>
*
* ����ע����
* ����Դ��ʹ�� GPL3.0 ��Դ����֤Э�� ������������Ϊ���İ汾
* ��������Ӣ�İ��� libraries/doc �ļ����µ� GPL3_permission_statement.txt �ļ���
* ����֤������ libraries �ļ����� �����ļ����µ� LICENSE �ļ�
* ��ӭ��λʹ�ò����������� ���޸�����ʱ���뱣����ɿƼ��İ�Ȩ����������������
*
* �ļ�����          main
* ��˾����          �ɶ���ɿƼ����޹�˾
* �汾��Ϣ          �鿴 libraries/doc �ļ����� version �ļ� �汾˵��
* ��������          MounRiver Studio V1.8.1
* ����ƽ̨          CH32V307VCT6
* ��������          https://seekfree.taobao.com/
*
* �޸ļ�¼
* ����                                      ����                             ��ע
* 2022-09-15        ��W            first version
********************************************************************************************************************/
#include "zf_common_headfile.h"
#include "Camera.h"
#include "Identify.h"
#include "PID.h"
#include "Motor.h"
#include "Speed.h"
#include "Acc_Gyro.h"
#include "Key.h"
#include "Roundabout.h"
#include "Buzzer.h"

uint8 Kernel_Variable = 0;
uint8 Motor_On_Flag = 0;

int main (void)
{
    clock_init(SYSTEM_CLOCK_120M);      // ��ʼ��оƬʱ�� ����Ƶ��Ϊ 120MHz
    debug_init();                       // ��ر��������������ڳ�ʼ��MPU ʱ�� ���Դ���

    Camera_Init();

    Identify_Track_Init();

    Speed_Init();

    Motor_Init();
//    Motor_Start_Protect();

    PID_Init();

    Acc_Gyro_Init();

    Key_Init();

    Buzzer_Init();

    interrupt_set_priority(TIM6_IRQn,0);
    pit_ms_init(TIM6_PIT, 10);

    /*while(gpio_get_level(B0) == 0)
    {
        ips114_show_int(188, 0, Original_L_Line[0], 5);
        ips114_show_int(188, 20, Original_R_Line[0], 5);
        ips114_show_int(188, 40, MT9V03X_H - 1 + 1, 5);
        ips114_show_int(188, 60, Starting_Point_Find_J, 5);
        ips114_show_int(188, 80, Frame_1, 5);
        ips114_show_int(188, 100, Frame_2, 5);

        ips114_show_int(188, 0, Duty_N_L, 5);
        ips114_show_int(188, 20, Duty_N_R, 5);
        ips114_show_int(188, 40, Duty_B_L, 5);
        ips114_show_int(188, 60, Duty_B_R, 5);
        ips114_show_int(188, 80, Duty_L_R, 5);
        ips114_show_int(188, 100, Identify_Track_Selection, 5);

        ips114_show_int(188, 100, Gyro_Z, 5);

        ips114_show_int(188, 0, L, 5);
        ips114_show_int(188, 20, L_L, 5);
        ips114_show_int(188, 40, L_R, 5);
        ips114_show_int(188, 60, R, 5);
        ips114_show_int(188, 80, R_L, 5);
        ips114_show_int(188, 100, R_R, 5);

        ips114_show_int(188, 0, Original_R_Line[119], 5);
        ips114_show_int(188, 20, Original_R_Line[118], 5);
        ips114_show_int(188, 40, R_L_Upper, 5);
        ips114_show_int(188, 60, R_L_Below, 5);
        ips114_show_int(188, 80, R_R_Upper, 5);
        ips114_show_int(188, 100, R_R_Below, 5);

        ips114_show_int(188, 0, L_Lost, 5);
        ips114_show_int(188, 20, L_Far_Lost, 5);
        ips114_show_int(188, 40, L_Near_Lost, 5);
        ips114_show_int(188, 60, R_Lost, 5);
        ips114_show_int(188, 80, R_Far_Lost, 5);
        ips114_show_int(188, 100, R_Near_Lost, 5);

        ips114_show_int(188, 0, Temp_L_L_CROS, 5);
        ips114_show_int(188, 20, Temp_L_R_CROS, 5);
        ips114_show_int(188, 40, Temp_R_L_CROS, 5);
        ips114_show_int(188, 60, Temp_R_R_CROS, 5);
        ips114_show_int(188, 80, Identify_Track_Selection, 5);

        ips114_show_int(188, 0, L_Lost_Point_Number_Min, 5);
        ips114_show_int(188, 20, L_Lost_Point_Number_Max, 5);
        ips114_show_int(188, 40, L_Lost, 5);
        ips114_show_int(188, 60, R_Lost_Point_Number_Min, 5);
        ips114_show_int(188, 80, R_Lost_Point_Number_Max, 5);
        ips114_show_int(188, 100, R_Lost, 5);


        ips114_show_int(188, 0, GDPC_Straightaway, 5);
        ips114_show_int(188, 20, GDPC_Bend, 5);
        ips114_show_int(188, 40, Gyro_Z, 5);
        ips114_show_int(188, 60, Duty_L_R, 5);
        ips114_show_int(188, 80, Duty_B_L, 5);
        ips114_show_int(188, 100, Duty_B_R, 5);


        ips114_show_int(188, 0, Original_L_Line[0], 5);
        ips114_show_int(188, 20, Original_R_Line[0], 5);
        ips114_show_int(188, 40, Equivalent_Corner_Point_Right[2], 5);
        ips114_show_int(188, 60, Equivalent_Corner_Point_Right[3], 5);
        ips114_show_int(188, 80, Equivalent_Corner_Point_Right[4], 5);
        ips114_show_int(188, 100, Equivalent_Corner_Point_Right[5], 5);


        ips114_show_int(188, 20, Speed, 5);

        ips114_show_int(188, 0, Identify_Track_Selection, 5);
        ips114_show_int(188, 20, Identify_Track_Status, 5);
        ips114_show_int(188, 40, DIFFERENCE_Value, 5);
        ips114_show_int(188, 60, LARCMCLP_Number, 5);
        ips114_show_int(188, 80, Duty_L_R, 5);
        ips114_show_int(188, 100, Kernel_Variable, 5);

        ips114_show_int(188, 0, L_R_Below, 5);
        ips114_show_int(188, 20, L_R_Upper, 5);
        ips114_show_int(188, 80, R_L_Below, 5);
        ips114_show_int(188, 100, R_L_Upper, 5);

        ips114_show_int(188, 0, R_L_Upper, 5);
        ips114_show_int(188, 20, R_L_Below, 5);
        ips114_show_int(188, 80, R_R_Below, 5);
        ips114_show_int(188, 100, R_R_Upper, 5);

        ips114_show_int(188, 0, L_L_Upper, 5);
        ips114_show_int(188, 20, L_L_Below, 5);
        ips114_show_int(188, 80, L_R_Upper, 5);
        ips114_show_int(188, 100, L_R_Below, 5);

        ips114_show_int(188, 0, R_L_Upper, 5);
        ips114_show_int(188, 20, R_L_Below, 5);
        ips114_show_int(188, 80, R_R_Upper, 5);
        ips114_show_int(188, 100, R_R_Below, 5);

        ips114_show_int(188, 0, L_L_Below, 5);
        ips114_show_int(188, 20, L_R_Below, 5);
        ips114_show_int(188, 80, R_L_Below, 5);
        ips114_show_int(188, 100, R_R_Below, 5);

        ips114_show_int(188, 0, L_L_Upper, 5);
        ips114_show_int(188, 20, L_R_Upper, 5);
        ips114_show_int(188, 80, R_L_Upper, 5);
        ips114_show_int(188, 100, R_R_Upper, 5);

        ips114_show_int(188, 0, Original_L_Line[112], 5);
        ips114_show_int(188, 20, Original_L_Line[113], 5);
        ips114_show_int(188, 40, Original_L_Line[114], 5);
        ips114_show_int(188, 60, Original_L_Line[115], 5);
        ips114_show_int(188, 80, Original_L_Line[116], 5);
        ips114_show_int(188, 100, Original_L_Line[117], 5);

        ips114_show_int(188, 0, Original_R_Line[40], 5);
        ips114_show_int(188, 20, Original_R_Line[41], 5);
        ips114_show_int(188, 40, Original_R_Line[42], 5);
        ips114_show_int(188, 60, Original_R_Line[43], 5);
        ips114_show_int(188, 80, Original_R_Line[44], 5);
        ips114_show_int(188, 100, Original_R_Line[45], 5);

        ips114_show_int(188, 40, AO_Count_Uppre, 5);
        ips114_show_int(188, 60, AO_Count, 5);

        ips114_show_int(188, 0, Original_L_Line[0] - Original_R_Line[0], 5);

        ips114_show_int(188, 0, GDPC_Straightaway, 5);
        ips114_show_int(188, 20, GDPC_Bend, 5);
        ips114_show_int(188, 40, Duty_L_R, 5);
        ips114_show_int(188, 60, Virtual_Midcourt_K, 5);
        ips114_show_int(188, 80, Virtual_Midcourt_B, 5);
        ips114_show_int(188, 100, Identify_Track_Selection, 5);

        ips114_show_int(188, 0, GDPC_Straightaway, 5);
        ips114_show_int(188, 20, GDPC_Bend, 5);
        ips114_show_int(188, 40, Duty_L_R, 5);
        ips114_show_int(188, 60, GDPC_Left_Avoid_Obstacles, 5);
        ips114_show_int(188, 80, GDPC_Right_Avoid_Obstacles, 5);
        ips114_show_int(188, 100, Identify_Track_Selection, 5);

        ips114_show_int(188, 20, Equivalent_Corner_Point_L_R[0], 5);
        ips114_show_int(188, 40, Equivalent_Corner_Point_L_R[1], 5);
        ips114_show_int(188, 60, Equivalent_Corner_Point_L_R[2], 5);
        ips114_show_int(188, 80, Equivalent_Corner_Point_L_R[3], 5);

        ips114_show_float(188, 0, 2.3533 + Key_Up_Straightaway_Data, 2, 2);
        ips114_show_float(188, 20, 1.7533 + Key_Down_Cross_Data, 2, 2);
        ips114_show_float(188, 40, 1.8633 + Key_Left_S_Bend_Data, 2, 2);
        ips114_show_float(188, 60, 1.6 + Key_Right_Roundabout_Data, 2, 2);
        ips114_show_float(188, 80, 1.6533 + Key_Middle_NULL_Track_Data, 2, 2);

        ips114_show_int(188, 0, 330 + Key_Up_Straightaway_Data, 5);
        ips114_show_int(188, 20, 280 + Key_Down_Cross_Data, 5);
        ips114_show_int(188, 40, 160 + Key_Left_S_Bend_Data, 5);
        ips114_show_int(188, 60, 160 + Key_Right_Roundabout_Data, 5);
        ips114_show_int(188, 80, 170 + Key_Middle_NULL_Track_Data, 5);
        ips114_show_int(188, 100, Duty_B_R, 5);

        Key_Test_Duty_Control();

        if(gpio_get_level(B1) == 1)
        {
            if(Key_Number == KEY_NUMBER_UP)
            {
                Key_Up_Straightaway_Data += 5;
                Key_Number = 0;
            }else if(Key_Number == KEY_NUMBER_DOWM)
            {
                Key_Down_Cross_Data += 5;
                Key_Number = 0;
            }else if(Key_Number == KEY_NUMBER_LEFT)
            {
                Key_Left_S_Bend_Data += 5;
                Key_Number = 0;
            }else if(Key_Number == KEY_NUMBER_RIGHT)
            {
                Key_Right_Roundabout_Data += 5;
                Key_Number = 0;
            }else if(Key_Number == KEY_NUMBER_MIDDLE)
            {
                Key_Middle_NULL_Track_Data += 5;
                Key_Number = 0;
            }
        }else
        {
            if(Key_Number == KEY_NUMBER_UP)
            {
                Key_Up_Straightaway_Data -= 5;
                Key_Number = 0;
            }else if(Key_Number == KEY_NUMBER_DOWM)
            {
                Key_Down_Cross_Data -= 5;
                Key_Number = 0;
            }else if(Key_Number == KEY_NUMBER_LEFT)
            {
                Key_Left_S_Bend_Data -= 5;
                Key_Number = 0;
            }else if(Key_Number == KEY_NUMBER_RIGHT)
            {
                Key_Right_Roundabout_Data -= 5;
                Key_Number = 0;
            }else if(Key_Number == KEY_NUMBER_MIDDLE)
            {
                Key_Middle_NULL_Track_Data -= 5;
                Key_Number = 0;
            }
        }
    }*/
    ips114_show_string(220, 0, "ZD");
    ips114_show_string(220, 20, "SZ");
    ips114_show_string(220, 40, "SW");
    ips114_show_string(220, 60, "HD");
    ips114_show_string(220, 80, "WF");
    while(gpio_get_level(B0) == 0 && gpio_get_level(B1) == 0)
    {
        Key_Test_Duty_Control();
        ips114_show_int(188, 0, Left_Roundabout_Identify_Number, 3);
        ips114_show_int(188, 20, Right_Roundabout_Identify_Number, 3);
        ips114_show_int(188, 40, Left_Avoid_Obstacles_Identify_Number, 3);
        ips114_show_int(188, 60, Right_Avoid_Obstacles_Identify_Number, 3);
        ips114_show_int(188, 80, Error, 3);
        ips114_show_int(188, 100, PrevError, 5);
        ips114_show_float(0, 118, MFPP, 1, 2);
        ips114_show_float(35, 118, MFPI, 1, 2);
        ips114_show_float(70, 118, MFLP, 1, 2);
        ips114_show_float(105, 118, MFLI, 1, 2);
        ips114_show_int(150, 118, Duty_L_R, 5);
        ips114_show_int(185, 118, Identify_Track_Selection, 5);
        if(gpio_get_level(E7) == 0)
        {
            if(gpio_get_level(E9) == 0)
            {
                if(Key_Number == KEY_NUMBER_LEFT)
                {
                    Left_Roundabout_Identify_Number++;
                    Key_Number = 0;
                }else if(Key_Number == KEY_NUMBER_RIGHT)
                {
                    Right_Roundabout_Identify_Number++;
                    Key_Number = 0;
                }else if(Key_Number == KEY_NUMBER_UP)
                {
                    Prevent_Left_Roundabout++;
                    Key_Number = 0;
                }else if(Key_Number == KEY_NUMBER_DOWM)
                {
                    Prevent_Left_Roundabout_Two++;
                    Key_Number = 0;
                }
            }else
            {
                if(Key_Number == KEY_NUMBER_LEFT)
                {
                    Left_Roundabout_Identify_Number--;
                    Key_Number = 0;
                }else if(Key_Number == KEY_NUMBER_RIGHT)
                {
                    Right_Roundabout_Identify_Number--;
                    Key_Number = 0;
                }else if(Key_Number == KEY_NUMBER_UP)
                {
                    Prevent_Left_Roundabout--;
                    Key_Number = 0;
                }else if(Key_Number == KEY_NUMBER_DOWM)
                {
                    Prevent_Left_Roundabout_Two--;
                    Key_Number = 0;
                }
            }
        }else
        {
            if(gpio_get_level(E9) == 0)
            {
                if(Key_Number == KEY_NUMBER_LEFT)
                {
                    Left_Avoid_Obstacles_Identify_Number++;
                    Key_Number = 0;
                }else if(Key_Number == KEY_NUMBER_RIGHT)
                {
                    Right_Avoid_Obstacles_Identify_Number++;
                    Key_Number = 0;
                }
            }else
            {
                if(Key_Number == KEY_NUMBER_LEFT)
                {
                    Left_Avoid_Obstacles_Identify_Number--;
                    Key_Number = 0;
                }else if(Key_Number == KEY_NUMBER_RIGHT)
                {
                    Right_Avoid_Obstacles_Identify_Number--;
                    Key_Number = 0;
                }
            }
        }
    }
    while(gpio_get_level(B0) == 0 && gpio_get_level(B1) == 1 && gpio_get_level(E7) == 0)
    {
        Key_Test_Duty_Control();
        ips114_show_int(188, 0, 300 + Key_Up_Straightaway_Data, 3);
        ips114_show_int(188, 20, 280 + Key_Down_Cross_Data, 3);
        ips114_show_int(188, 40, 280 + Key_Left_S_Bend_Data, 3);
        ips114_show_int(188, 60, 230 + Key_Right_Roundabout_Data, 3);
        ips114_show_int(188, 80, 200 + Key_Middle_NULL_Track_Data, 3);
        ips114_show_int(188, 100, 0, 5);
        ips114_show_string(0, 118, "old");
        if(gpio_get_level(E9) == 0)
        {
            if(Key_Number == KEY_NUMBER_UP)
            {
                Key_Up_Straightaway_Data += 10;
                Key_Number = 0;
            }else if(Key_Number == KEY_NUMBER_DOWM)
            {
                Key_Down_Cross_Data += 10;
                Key_Number = 0;
            }else if(Key_Number == KEY_NUMBER_LEFT)
            {
                Key_Left_S_Bend_Data += 10;
                Key_Number = 0;
            }else if(Key_Number == KEY_NUMBER_RIGHT)
            {
                Key_Right_Roundabout_Data += 10;
                Key_Number = 0;
            }else if(Key_Number == KEY_NUMBER_MIDDLE)
            {
                Key_Middle_NULL_Track_Data += 10;
                Key_Number = 0;
            }
        }else
        {
            if(Key_Number == KEY_NUMBER_UP)
            {
                Key_Up_Straightaway_Data -= 10;
                Key_Number = 0;
            }else if(Key_Number == KEY_NUMBER_DOWM)
            {
                Key_Down_Cross_Data -= 10;
                Key_Number = 0;
            }else if(Key_Number == KEY_NUMBER_LEFT)
            {
                Key_Left_S_Bend_Data -= 10;
                Key_Number = 0;
            }else if(Key_Number == KEY_NUMBER_RIGHT)
            {
                Key_Right_Roundabout_Data -= 10;
                Key_Number = 0;
            }else if(Key_Number == KEY_NUMBER_MIDDLE)
            {
                Key_Middle_NULL_Track_Data -= 10;
                Key_Number = 0;
            }
        }
    }
    while(gpio_get_level(B0) == 0 && gpio_get_level(B1) == 1 && gpio_get_level(E7) == 1)
    {
        Key_Test_Duty_Control();
        ips114_show_int(188, 0, 300 + Key_Up_Straightaway_Data + Straightaway_Speed_Pro_End, 3);
        ips114_show_int(188, 20, 280 + Key_Down_Cross_Data + Cross_Speed_Pro_End, 3);
        ips114_show_int(188, 40, 280 + Key_Left_S_Bend_Data + S_Bend_Speed_Pro_End, 3);
        ips114_show_int(188, 60, 230 + Key_Right_Roundabout_Data + Roundabout_Speed_Pro_End, 3);
        ips114_show_int(188, 80, 200 + Key_Middle_NULL_Track_Data + NULL_Track_Speed_Pro_End, 3);
        ips114_show_int(188, 100, 1, 5);
        ips114_show_string(0, 118, "old ACC");
        if(gpio_get_level(E9) == 0)
        {
            if(Key_Number == KEY_NUMBER_UP)
            {
                Straightaway_Speed_Pro_End += 10;
                Key_Number = 0;
            }else if(Key_Number == KEY_NUMBER_DOWM)
            {
                Cross_Speed_Pro_End += 10;
                Key_Number = 0;
            }else if(Key_Number == KEY_NUMBER_LEFT)
            {
                S_Bend_Speed_Pro_End += 10;
                Key_Number = 0;
            }else if(Key_Number == KEY_NUMBER_RIGHT)
            {
                Roundabout_Speed_Pro_End += 10;
                Key_Number = 0;
            }else if(Key_Number == KEY_NUMBER_MIDDLE)
            {
                NULL_Track_Speed_Pro_End += 10;
                Key_Number = 0;
            }
        }else
        {
            if(Key_Number == KEY_NUMBER_UP)
            {
                Straightaway_Speed_Pro_End -= 10;
                Key_Number = 0;
            }else if(Key_Number == KEY_NUMBER_DOWM)
            {
                Cross_Speed_Pro_End -= 10;
                Key_Number = 0;
            }else if(Key_Number == KEY_NUMBER_LEFT)
            {
                S_Bend_Speed_Pro_End -= 10;
                Key_Number = 0;
            }else if(Key_Number == KEY_NUMBER_RIGHT)
            {
                Roundabout_Speed_Pro_End -= 10;
                Key_Number = 0;
            }else if(Key_Number == KEY_NUMBER_MIDDLE)
            {
                NULL_Track_Speed_Pro_End -= 10;
                Key_Number = 0;
            }
        }
    }
    Motor_Start_Protect();
    ips114_show_string(188, 0, "     ");
    ips114_show_string(188, 20, "     ");
    ips114_show_string(188, 40, "     ");
    ips114_show_string(188, 60, "     ");
    ips114_show_string(188, 80, "     ");
    ips114_show_string(188, 100, "     ");
    Motor_On_Flag = 1;
    while(1)
    {
        ips114_show_int(188, 0, Identify_Track_Selection, 5);
        ips114_show_int(188, 20, Identify_Track_Status, 5);
        ips114_show_int(188, 40, Left_Roundabout_Flag, 5);
        ips114_show_int(188, 60, Roundabout_Flag, 5);
        ips114_show_int(188, 80, Duty_L_R, 5);
        ips114_show_int(188, 100, Kernel_Variable, 5);
    }
}

void pit_handler (void)
{
    Camera_Next_Image();
    Identify_Track_Update();
    Speed_Control();
    Acc_Gyro_Gain();
    PID_Control();
    if(Motor_On_Flag == 0)
    {
        return;
    }
    Motor_Control();
    //Motor_Test_Control();
}

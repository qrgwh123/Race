/*
 * V.h
 *
 *  Created on: Mar 20, 2024
 *      Author: guo
 */

#ifndef V_H_
#define V_H_

int x = 0;


#endif /* V_H_ */
